# Nyra Memory & Agent Architecture (Combo B+)

This is the privacy-first multi-agent architecture: Graph (Graphiti + FalkorDB/Neo4j),
Vector (Qdrant), Unified Memory Bus (OpenMemory MCP), LMCache + vLLM for speed,
with a RAG fallback path. Notion sync is optional for human editing.

```
[UI/User]
   ↕
[Agents (Letta/custom)]
   ↕
[Memory Interface / Router]
   ↕
┌─────────────────────────────┐
│ OpenMemory MCP (local-first)│
└─────────────────────────────┘
   ↕                     ↕
[Qdrant MCP]         [Graphiti MCP]
   ↕                     ↕
[Qdrant]             [FalkorDB / Neo4j]
```
- RAG fallback: vector → chunk → LLM answer
- LMCache sits between agents ↔ LLM runtime to reuse KV cache

See **docs/bootstrap_claude_memory_stack.md** for full “bring-up” instructions.
