# Claude Bootstrap — Nyra Memory & Agent Stack

Claude, you are the **Stack Builder**. Stand up this stack end-to-end, locally and repeatably.

## Objectives
- Qdrant (vector), Graphiti MCP + graph DB (FalkorDB/Neo4j), OpenMemory MCP (unified bus)
- LMCache + LLM runtime (vLLM or compatible)
- Memory Interface / Router with RAG fallback
- Optional Notion sync
- Secure + test

## Tasks
1. **Infra**: generate `docker-compose.yml`, `.env.sample`, and scripts to start/stop/status.
2. **Graph**: clone Graphiti, run MCP, connect to FalkorDB/Neo4j via env.
3. **OpenMemory**: run locally (Docker or desktop), expose MCP SSE endpoint.
4. **Agents**: scaffold MemoryRouter with path selection (graph vs vector vs rag).
5. **LMCache**: integrate with vLLM; measure TTFT and cache-hit metrics.
6. **RAG**: simple pipeline for coverage when graph path is unsuitable.
7. **Notion sync**: optional adapter (export/import graph to Notion pages/relations).
8. **Security**: tokens/ACLs, local-only networking, audit logs.
9. **Tests**: smoke tests hitting all paths.

## Prompts (examples)
- “Create docker-compose for Qdrant:6333, FalkorDB:6379/3000, OpenMemory:<PORT> with volumes & healthchecks.”
- “Scaffold a Python MemoryRouter with MCP clients for Graphiti, Qdrant, OpenMemory; then write 3 tests.”
- “Emit a RAG fallback pipeline and a quick benchmark script.”

## Deliverables
- Running stack
- Docs + scripts
- Passing smoke tests
