# Minimal scaffold for Notion <-> Graphiti sync
# Replace with real Notion SDK + Graphiti MCP calls.
def export_graph_to_notion():
    pass

def import_notion_to_graph():
    pass
