from typing import Any, Dict
from utils.logging_utils import get_logger

logger = get_logger("MemoryRouter")

class MemoryRouter:
    def __init__(self, config: Dict[str, Any] | None = None):
        self.config = config or {}

    def choose_path(self, query: str) -> str:
        # TODO: smarter classifier. For now, keyword heuristic.
        q = query.lower()
        if any(k in q for k in ["borrower", "loan", "property", "address", "rate", "term", "lender"]):
            return "graph"
        if len(q.split()) > 8:
            return "vector"
        return "rag"

    def query(self, query: str) -> Dict[str, Any]:
        path = self.choose_path(query)
        logger.info(f"Routing '{query}' via {path}")
        # TODO: call appropriate MCP client
        return {"path": path, "results": []}

    def write_memory(self, obj: Dict[str, Any]) -> Dict[str, Any]:
        # TODO: dispatch writes to OpenMemory and/or Graphiti based on type
        logger.info(f"Writing memory: {obj.get('type','unknown')}")
        return {"status": "ok"}
