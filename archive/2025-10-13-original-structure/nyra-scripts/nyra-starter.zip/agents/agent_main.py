from agents.memory_interface import MemoryRouter

def main():
    router = MemoryRouter()
    print("Nyra agent runtime (stub). Try a few queries:")
    for q in [
        "Which borrower has two mortgages?",
        "Summarize FHA loan guidelines for 2024",
        "Link borrower John Doe to property 123 Main St"
    ]:
        res = router.query(q)
        print(q, "=>", res["path"])

if __name__ == "__main__":
    main()
