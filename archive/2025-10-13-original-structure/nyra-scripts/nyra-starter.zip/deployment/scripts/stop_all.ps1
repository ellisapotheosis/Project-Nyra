$root = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
$root = Join-Path $root "..\.."
Set-Location $root
docker compose -f deployment\docker-compose.yml down
Write-Host "[OK] Stopped all containers."
