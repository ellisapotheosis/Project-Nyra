Write-Host "== Qdrant =="
try { Invoke-RestMethod -Uri http://localhost:6333/readyz -UseBasicParsing } catch {}
Write-Host "`n== FalkorDB Browser =="
try { Invoke-RestMethod -Uri http://localhost:3000 -UseBasicParsing } catch {}
