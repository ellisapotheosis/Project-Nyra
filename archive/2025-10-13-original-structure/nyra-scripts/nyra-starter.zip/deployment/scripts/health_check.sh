#!/usr/bin/env bash
set -e
echo "== Qdrant =="
curl -s http://localhost:6333/readyz || true
echo
echo "== FalkorDB Browser =="
curl -s http://localhost:3000 || true
echo
