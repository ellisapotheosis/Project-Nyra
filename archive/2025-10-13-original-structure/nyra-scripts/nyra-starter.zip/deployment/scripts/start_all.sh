#!/usr/bin/env bash
set -e
ROOT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
cd "$ROOT_DIR"
docker compose -f deployment/docker-compose.yml up -d
echo "[OK] Qdrant + FalkorDB started."
