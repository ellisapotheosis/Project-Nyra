def clean_text(text: str) -> str:
    # normalize whitespace, strip headers/footers, scrub PII tags if configured
    return " ".join(text.split())
