def chunk_text(text: str, max_tokens: int = 800, overlap: int = 100):
    # naive chunker; replace with token-aware implementation
    words = text.split()
    chunks = []
    i = 0
    step = max_tokens - overlap
    while i < len(words):
        chunk = " ".join(words[i:i+max_tokens])
        chunks.append(chunk)
        i += step
    return chunks
