def extract_triples(text: str):
    # placeholder; replace with LlamaIndex Graph extraction or custom NER+RE
    # returns [(subject, relation, object), ...]
    return []
