from ingestion_pipeline.cleaner import clean_text
from ingestion_pipeline.chunker import chunk_text
from ingestion_pipeline.kg_extractor import extract_triples
from mcp_clients.openmemory_mcp_client.openmemory_client import OpenMemoryClient
from mcp_clients.graphiti.graphiti_client import GraphitiClient

def ingest_document(doc_text: str, meta: dict):
    text = clean_text(doc_text)
    chunks = chunk_text(text)
    triples = extract_triples(text)

    om = OpenMemoryClient()
    for c in chunks:
        om.add_memory(text=c, embedding=None, metadata=meta)

    g = GraphitiClient()
    for (s, r, o) in triples:
        g.add_edge(s, r, o, metadata=meta)

    return {"chunks": len(chunks), "triples": len(triples)}
