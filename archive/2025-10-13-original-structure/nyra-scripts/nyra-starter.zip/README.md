# Nyra — Memory & Agent Stack (Combo B+)

**Purpose:** a privacy-first, multi-agent stack blending graph reasoning (Graphiti + FalkorDB/Neo4j),
vector recall (Qdrant), a unified memory bus (OpenMemory MCP), and speed via LMCache + vLLM.

## Quickstart (Unix/macOS)

```bash
# 0) clone & enter
git clone <YOUR_REPO_URL> nyra
cd nyra

# 1) spin up core infra (Qdrant, FalkorDB, optional OpenMemory if you add it)
make up          # or: ./deployment/scripts/start_all.sh

# 2) configure envs
cp deployment/.env.sample .env
cp configs/graphiti.env .graphiti.env
cp configs/openmemory.env .openmemory.env

# 3) run Graphiti MCP (requires Python + uv)
cd mcp_clients/graphiti && uv sync && uv run run_graphiti_mcp.py &

# 4) run agents (Letta/custom) + memory interface
cd agents && python agent_main.py
```

## Quickstart (Windows PowerShell)

```powershell
# 0) clone & enter
git clone <YOUR_REPO_URL> nyra
Set-Location nyra

# 1) spin up core infra
powershell -ExecutionPolicy Bypass -File .\deployment\scripts\start_all.ps1

# 2) configs
Copy-Item deployment\.env.sample .\.env
Copy-Item configs\graphiti.env .\.graphiti.env
Copy-Item configs\openmemory.env .\.openmemory.env

# 3) Graphiti MCP (Python + uv)
Set-Location mcp_clients\graphiti
uv sync
uv run run_graphiti_mcp.py

# 4) Agents
Set-Location ..\..\agents
python agent_main.py
```

> Replace `<YOUR_REPO_URL>` with your own URL.
> This template assumes **local-only** by default. Vault/secret manager is recommended for prod.

## What lives where?

- **agents/**: your agent logic + the MemoryRouter abstraction
- **mcp_clients/**: thin clients/wrappers for MCP servers (Graphiti/Qdrant/OpenMemory)
- **ingestion_pipeline/**: document cleaning, chunking, KG extraction, embeddings, ingestion
- **lmcache_integration/**: glue for LMCache + vLLM runtime
- **notion_sync/**: optional Notion ↔ Graphiti sync service (editing UI layer)
- **deployment/**: docker-compose, scripts, infra manifests (orchestration lives here)
- **configs/**: .env files, YAML configs
- **docs/**: architecture + Claude bootstrap instructions
- **tests/**: smoke/unit tests
- **utils/**: helpers (logging, metrics, etc.)

See **docs/architecture.md** and **docs/bootstrap_claude_memory_stack.md** for the full storyline.
