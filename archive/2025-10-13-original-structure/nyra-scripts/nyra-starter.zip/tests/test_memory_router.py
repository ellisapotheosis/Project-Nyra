from agents.memory_interface import MemoryRouter

def test_router_paths():
    r = MemoryRouter()
    assert r.choose_path("Which borrower has two mortgages?") == "graph"
    assert r.choose_path("Tell me about FHA loan guidelines for multifamily units") in {"vector","rag"}
