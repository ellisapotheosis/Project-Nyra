from ingestion_pipeline.ingest_to_memory import ingest_document

def test_ingest_returns_counts():
    res = ingest_document("Hello world. This is a test document.", {"source":"test"})
    assert "chunks" in res and "triples" in res
