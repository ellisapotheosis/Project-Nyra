# mcpo (MCP → OpenAPI proxy)
Start `mcpo` (via docker compose). Register MCP servers, then add the mcpo OpenAPI endpoint to Open WebUI Tools.
Docs: https://docs.openwebui.com/openapi-servers/mcp/
