# Open WebUI Pipelines Samples

- **Flowise**: call Prediction API from a Pipe.
- **n8n**: POST to a webhook, return text/JSON.
- **Dify**: proxy /v1/chat/completions OpenAI-compatible endpoint.
