# DesktopCommander Setup
Instructions to run and configure DesktopCommanderMCP.