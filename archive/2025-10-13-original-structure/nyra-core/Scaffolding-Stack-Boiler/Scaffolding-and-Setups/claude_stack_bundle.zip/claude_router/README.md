# Claude Router
Handles communication between Claude Desktop and MCP agents.