#!/bin/bash
open DesktopCommanderMCP &
npm run mcp-knowledge-graph &