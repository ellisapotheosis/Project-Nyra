# PowerShell script to launch Claude + MCP
Start-Process 'DesktopCommanderMCP.exe'
Start-Process 'npm run mcp-knowledge-graph'