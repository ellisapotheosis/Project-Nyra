# Nyra Env & Stack Audit Kit (v2)

This kit generates a *ground-truth* list of environment variables referenced across your repo,
compares them to existing `.env*` files, & produces:
- env_inventory.csv
- missing_env_report.md
- infisical_missing_secrets.json
- docker_status.md (optional, if docker is installed)

Why v2?
- v1 bash scanner could emit "ignored null byte" warnings on binary-ish files.
- v2 uses a Python scanner that safely reads files with `errors='ignore'`.

## Run (WSL/Linux/macOS)
```bash
cd /path/to/Project-Nyra
python3 tools/nyra_env_audit.py . ./_audit
# or:
bash tools/nyra-env-audit.sh . ./_audit
```

## Run (Windows PowerShell)
```powershell
cd C:\Dev\Projects\Repos\Project-Nyra
python tools\nyra_env_audit.py . .\_audit
```

## Outputs
- ./_audit/env_inventory.csv
- ./_audit/missing_env_report.md
- ./_audit/infisical_missing_secrets.json
- ./_audit/docker_status.md

## Notes
- Static scan: finds `${VAR}`, `process.env.VAR`, `ENV VAR=`, & common `$VAR` usages.
- Avoids scanning huge folders like node_modules, dist, build, .git.
