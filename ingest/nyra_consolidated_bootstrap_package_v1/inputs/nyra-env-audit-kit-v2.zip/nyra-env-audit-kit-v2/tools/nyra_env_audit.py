#!/usr/bin/env python3
import os, re, sys, json, csv, datetime, subprocess
from pathlib import Path
from typing import Dict, Set, List

RX_COMPOSE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::[^}]*)?\}")
RX_NODE = re.compile(r"process\.env\.([A-Za-z_][A-Za-z0-9_]*)")
RX_DOCKER_ENV = re.compile(r"^\s*ENV\s+([A-Za-z_][A-Za-z0-9_]*)\s*=", re.M)
RX_SHELL = re.compile(r"\$([A-Za-z_][A-Za-z0-9_]*)")
SECRET_RX = re.compile(r"(KEY|TOKEN|SECRET|PASS|PWD|PRIVATE|CERT|SIGNING|JWT|OAUTH|CLIENT_SECRET|API_KEY)", re.I)

DEFAULT_SCAN_DIRS = ["infra","apps","services","systems","bootstrap","scripts","tools"]
DEFAULT_EXCLUDE_DIRS = {".git","node_modules",".next","dist","build","out",".venv","venv",".pytest_cache",".cache","coverage","target"}

INCLUDE_EXT = {".yml",".yaml",".json",".md",".ts",".tsx",".js",".jsx",".mjs",".cjs",".env",".txt",".ini",".conf",".toml",".properties",".sh",".bash",".zsh",".ps1"}
INCLUDE_NAMES = {"Dockerfile"}

def safe_run(cmd):
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True)
        return out.strip()
    except Exception as e:
        return f"[command failed] {' '.join(cmd)}\\n{e}"

def load_env_keys(repo: Path) -> Dict[str, List[str]]:
    env_files = []
    for p in repo.rglob("*"):
        if not p.is_file():
            continue
        name = p.name
        if name == ".env" or name.startswith(".env.") or name.endswith(".env") or ".env." in name or name == "env" or name.startswith("env.") or name.endswith(".env.example"):
            env_files.append(p)

    env_map: Dict[str, List[str]] = {}
    for f in env_files:
        try:
            for line in f.read_text(errors="ignore").splitlines():
                if re.match(r"^\\s*#", line):
                    continue
                m = re.match(r"^\\s*([A-Za-z_][A-Za-z0-9_]*)\\s*=\\s*(.*)\\s*$", line)
                if m:
                    k = m.group(1)
                    env_map.setdefault(k, []).append(str(f))
        except Exception:
            continue
    return env_map

def scan_files(repo: Path, scan_dirs: List[str]) -> Dict[str, Set[str]]:
    refs: Dict[str, Set[str]] = {}
    roots = []
    for d in scan_dirs:
        p = repo / d
        if p.exists() and p.is_dir():
            roots.append(p)
    if not roots:
        roots = [repo]

    for root in roots:
        for path, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in DEFAULT_EXCLUDE_DIRS]
            for fn in filenames:
                p = Path(path) / fn
                if fn in INCLUDE_NAMES or fn.startswith("Dockerfile"):
                    pass
                else:
                    if p.suffix.lower() not in INCLUDE_EXT:
                        continue
                try:
                    text = p.read_text(errors="ignore")
                except Exception:
                    continue

                for m in RX_COMPOSE.finditer(text):
                    refs.setdefault(m.group(1), set()).add(str(p))
                for m in RX_NODE.finditer(text):
                    refs.setdefault(m.group(1), set()).add(str(p))
                for m in RX_DOCKER_ENV.finditer(text):
                    refs.setdefault(m.group(1), set()).add(str(p))

                if p.suffix.lower() in {".sh",".bash",".zsh",".ps1",".yml",".yaml",".env",".toml",".properties"}:
                    for m in RX_SHELL.finditer(text):
                        v = m.group(1)
                        if re.match(r"^(PATH|HOME|PWD|USER|SHELL|TERM|TMP|TEMP|USERNAME|OS|PROCESSOR_|PROGRAMFILES)", v):
                            continue
                        refs.setdefault(v, set()).add(str(p))
    return refs

def write_outputs(repo: Path, out: Path, env_map: Dict[str, List[str]], refs: Dict[str, Set[str]]):
    out.mkdir(parents=True, exist_ok=True)
    now = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    inv_csv = out / "env_inventory.csv"
    missing_md = out / "missing_env_report.md"
    inf_json = out / "infisical_missing_secrets.json"
    docker_md = out / "docker_status.md"

    rows = []
    for var in sorted(refs.keys()):
        locs = sorted(refs[var])
        is_secret = bool(SECRET_RX.search(var))
        is_set = var in env_map
        example_file = env_map[var][0] if is_set else ""
        rows.append({
            "var": var,
            "is_secret_guess": is_secret,
            "is_set_in_env_files": is_set,
            "example_env_file": example_file,
            "references": " | ".join(locs),
        })

    with inv_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["var","is_secret_guess","is_set_in_env_files","example_env_file","references"])
        w.writeheader()
        w.writerows(rows)

    missing = [r for r in rows if not r["is_set_in_env_files"]]
    md_lines = []
    md_lines.append(f"# Missing Env Vars Report ({now})")
    md_lines.append("")
    md_lines.append(f"RepoRoot: `{repo}`")
    md_lines.append(f"OutDir: `{out}`")
    md_lines.append("")
    md_lines.append("## Missing variables (referenced but not found in any .env files)")
    md_lines.append("")
    for r in missing:
        md_lines.append(f"- **{r['var']}** (secret_guess={r['is_secret_guess']})")
        md_lines.append(f"  - refs: {r['references']}")
    missing_md.write_text("\\n".join(md_lines), encoding="utf-8")

    missing_secrets = [{"key": r["var"], "value": "", "note": "missing (fill & import into Infisical)"} for r in missing if r["is_secret_guess"]]
    inf_obj = {"generated_at": now, "repo_root": str(repo), "missing_secrets": missing_secrets}
    inf_json.write_text(json.dumps(inf_obj, indent=2), encoding="utf-8")

    docker_lines = []
    docker_lines.append(f"# Docker Status ({now})")
    docker_lines.append("")
    docker_lines.append("## docker ps -a")
    docker_lines.append("```")
    docker_lines.append(safe_run(["docker","ps","-a"]))
    docker_lines.append("```")
    docker_lines.append("")
    docker_lines.append("## docker compose ls")
    docker_lines.append("```")
    docker_lines.append(safe_run(["docker","compose","ls"]))
    docker_lines.append("```")
    docker_md.write_text("\\n".join(docker_lines), encoding="utf-8")

def main():
    if len(sys.argv) < 3:
        print("Usage: nyra_env_audit.py <repo_root> <out_dir> [scan_dir,scan_dir,...]")
        sys.exit(2)
    repo = Path(sys.argv[1]).expanduser().resolve()
    out = (repo / sys.argv[2]).resolve()
    scan_dirs = DEFAULT_SCAN_DIRS
    if len(sys.argv) >= 4 and sys.argv[3].strip():
        scan_dirs = [s.strip() for s in sys.argv[3].split(",") if s.strip()]

    env_map = load_env_keys(repo)
    refs = scan_files(repo, scan_dirs)
    write_outputs(repo, out, env_map, refs)

    print("Wrote:")
    print(f" - {out/'env_inventory.csv'}")
    print(f" - {out/'missing_env_report.md'}")
    print(f" - {out/'infisical_missing_secrets.json'}")
    print(f" - {out/'docker_status.md'}")

if __name__ == "__main__":
    main()
