#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="${1:-.}"
OUT_DIR="${2:-./_audit}"
SCAN="${3:-infra,apps,services,systems,bootstrap,scripts,tools}"

if command -v python3 >/dev/null 2>&1; then
  python3 tools/nyra_env_audit.py "$REPO_ROOT" "$OUT_DIR" "$SCAN"
elif command -v python >/dev/null 2>&1; then
  python tools/nyra_env_audit.py "$REPO_ROOT" "$OUT_DIR" "$SCAN"
else
  echo "Python not found. Install python3 or run the PowerShell scanner on Windows."
  exit 1
fi
