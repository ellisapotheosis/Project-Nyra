
docker compose up -d
