# Windows quick-run helper for this kit.
# Edit the next two lines, then run:
#   powershell -ExecutionPolicy Bypass -File windows\run_create_issues.ps1

$env:LINEAR_API_KEY = "PASTE_YOUR_LINEAR_PERSONAL_API_KEY_HERE"
$env:LINEAR_TEAM_KEY = "NYRA"   # or set $env:LINEAR_TEAM_ID = "uuid-here"

python -m pip install -r requirements.txt
python scripts\list_teams.py
python scripts\create_issues.py backlog.yaml
