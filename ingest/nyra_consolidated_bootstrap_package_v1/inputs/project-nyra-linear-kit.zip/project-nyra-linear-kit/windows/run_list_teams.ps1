$env:LINEAR_API_KEY = "PASTE_YOUR_LINEAR_PERSONAL_API_KEY_HERE"
python scripts\list_teams.py
