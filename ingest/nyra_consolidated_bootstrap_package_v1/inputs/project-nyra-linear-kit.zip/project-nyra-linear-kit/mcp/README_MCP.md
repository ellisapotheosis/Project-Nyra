# Linear MCP (Model Context Protocol) cheat sheet

Linear provides a **hosted remote MCP server**. That means compatible AI clients can read/write your Linear issues and projects via OAuth.

## The endpoints (remote MCP)
- Streamable HTTP: https://mcp.linear.app/mcp
- SSE: https://mcp.linear.app/sse

## What you get
Tools to find/create/update things like:
- issues
- projects
- comments

## How to use it (common patterns)
Ask your AI client things like:
- “Look at my open NYRA issues and propose a 1-week plan with priorities.”
- “Create Linear issues for each TODO in this markdown list.”
- “Turn this bug report into a crisp issue with acceptance criteria.”
- “Generate a release note draft from all Done issues in the last cycle.”

## If your client doesn't support remote MCP
Linear’s docs recommend using `mcp-remote` as a shim:
- npx mcp-remote https://mcp.linear.app/mcp

(Exact setup steps differ by client. See Linear’s docs page.)
