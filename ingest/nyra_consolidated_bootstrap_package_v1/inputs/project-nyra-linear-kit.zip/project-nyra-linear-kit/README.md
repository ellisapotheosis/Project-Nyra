# Project-Nyra → Linear Starter Kit

This kit bootstraps a clean Linear workflow for a new project and includes scripts to **list teams** and **bulk-create issues** from a YAML backlog.

It also includes a short **Linear MCP cheat sheet** (so your AI tools can read/write Linear directly).

---

## 0) Prereqs

- Python 3.10+
- A Linear workspace + a Team for your project (ex: `NYRA`)

Install deps:

```bash
python -m pip install -r requirements.txt
```

---

## 1) Create a Linear Personal API Key (for the scripts)

In Linear:
- Settings → **Security & access**
- **Personal API keys** → New API key

Export it as an environment variable:

### Windows (PowerShell)
```powershell
$env:LINEAR_API_KEY="YOUR_KEY_HERE"
```

### macOS/Linux (bash/zsh)
```bash
export LINEAR_API_KEY="YOUR_KEY_HERE"
```

> The scripts use Linear’s GraphQL endpoint `https://api.linear.app/graphql`.

---

## 2) Find your Team key / id

Run:

```bash
python scripts/list_teams.py
```

You’ll see something like:

- `key` (short code like `NYRA`)
- `id` (UUID)

Set one of these:

### Windows (PowerShell)
```powershell
$env:LINEAR_TEAM_KEY="NYRA"
# or
$env:LINEAR_TEAM_ID="uuid-here"
```

### macOS/Linux
```bash
export LINEAR_TEAM_KEY="NYRA"
# or
export LINEAR_TEAM_ID="uuid-here"
```

---

## 3) Create issues from a YAML backlog

Edit `backlog.yaml`, then run:

```bash
python scripts/create_issues.py backlog.yaml
```

---

## 4) (Optional) Quick start on Windows

```powershell
# sets env vars (edit inside the file), then runs create_issues
powershell -ExecutionPolicy Bypass -File windows\run_create_issues.ps1
```

---

## Notes

- If the script returns a GraphQL error, it prints the error payload so you can fix field names quickly.
- If you prefer OAuth (for an app), use OAuth 2.0 instead of a personal key.

