from __future__ import annotations

import os
import sys
from typing import Any, Dict, List

import yaml

from scripts._linear import gql, LinearError

QUERY_TEAMS = """
query Teams {
  teams {
    nodes { id key name }
  }
}
"""

MUTATION_CREATE = """
mutation IssueCreate($input: IssueCreateInput!) {
  issueCreate(input: $input) {
    success
    issue {
      id
      title
    }
  }
}
"""

def resolve_team_id() -> str:
    # Prefer explicit ID, otherwise resolve from key
    team_id = os.environ.get("LINEAR_TEAM_ID", "").strip()
    if team_id:
        return team_id

    team_key = os.environ.get("LINEAR_TEAM_KEY", "").strip()
    if not team_key:
        raise LinearError("Set LINEAR_TEAM_ID or LINEAR_TEAM_KEY.")

    out = gql(QUERY_TEAMS)
    teams = out["data"]["teams"]["nodes"]
    for t in teams:
        if (t.get("key") or "").lower() == team_key.lower():
            return t["id"]
    raise LinearError(f"Could not find a team with key={team_key}. Run scripts/list_teams.py to confirm.")

def load_backlog(path: str) -> List[Dict[str, Any]]:
    with open(path, "r", encoding="utf-8") as f:
        doc = yaml.safe_load(f) or {}
    issues = doc.get("issues", [])
    if not isinstance(issues, list) or not issues:
        raise LinearError("backlog.yaml must contain a top-level list: issues: [ ... ]")
    for i, item in enumerate(issues):
        if "title" not in item or not str(item["title"]).strip():
            raise LinearError(f"Issue #{i+1} is missing a non-empty 'title'.")
    return issues

def main(argv: List[str]) -> int:
    if len(argv) != 2:
        print("Usage: python scripts/create_issues.py backlog.yaml")
        return 2

    path = argv[1]
    try:
        team_id = resolve_team_id()
        issues = load_backlog(path)

        print(f"Creating {len(issues)} issue(s) in teamId={team_id} ...")
        created = 0
        for item in issues:
            title = str(item["title"]).strip()
            description = str(item.get("description", "") or "")
            variables = {
                "input": {
                    "teamId": team_id,
                    "title": title,
                    "description": description,
                }
            }
            out = gql(MUTATION_CREATE, variables=variables)
            payload = out["data"]["issueCreate"]
            if payload.get("success"):
                issue = payload["issue"]
                created += 1
                print(f"✓ {created}/{len(issues)} created: {issue['title']} (id={issue['id']})")
            else:
                print(f"✗ failed to create: {title}")

        print("Done.")
        return 0
    except LinearError as e:
        print("ERROR:", e)
        return 1

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
