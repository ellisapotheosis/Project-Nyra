"""
Minimal Linear GraphQL client (personal API key).

Env:
  LINEAR_API_KEY   (required)
"""

from __future__ import annotations
import os
import time
import json
from typing import Any, Dict, Optional

import requests

LINEAR_ENDPOINT = "https://api.linear.app/graphql"

class LinearError(RuntimeError):
    pass

def _headers() -> Dict[str, str]:
    api_key = os.environ.get("LINEAR_API_KEY", "").strip()
    if not api_key:
        raise LinearError("Missing env var LINEAR_API_KEY.")
    return {
        "Content-Type": "application/json",
        # Personal API key auth uses `Authorization: <API_KEY>`
        "Authorization": api_key,
    }

def gql(query: str, variables: Optional[Dict[str, Any]] = None, retries: int = 3) -> Dict[str, Any]:
    payload: Dict[str, Any] = {"query": query}
    if variables:
        payload["variables"] = variables

    last_err: Optional[Exception] = None
    for attempt in range(1, retries + 1):
        try:
            resp = requests.post(LINEAR_ENDPOINT, headers=_headers(), json=payload, timeout=30)
            # Linear returns 200 even for GraphQL errors; we still parse and surface them.
            data = resp.json()
            if resp.status_code >= 500:
                raise LinearError(f"Server error {resp.status_code}: {resp.text[:500]}")
            if "errors" in data and data["errors"]:
                raise LinearError(json.dumps(data["errors"], indent=2))
            return data
        except (requests.RequestException, ValueError, LinearError) as e:
            last_err = e
            # basic backoff
            time.sleep(0.6 * attempt)
    raise LinearError(f"Linear request failed after {retries} tries. Last error: {last_err}")
