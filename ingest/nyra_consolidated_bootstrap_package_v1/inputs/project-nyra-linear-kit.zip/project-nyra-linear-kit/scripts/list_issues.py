from __future__ import annotations
import os
from scripts._linear import gql, LinearError

QUERY = """
query TeamIssues($teamId: String!) {
  team(id: $teamId) {
    id
    name
    issues(first: 50) {
      nodes {
        id
        title
        createdAt
      }
    }
  }
}
"""

def main() -> int:
    team_id = os.environ.get("LINEAR_TEAM_ID", "").strip()
    if not team_id:
        print("Set LINEAR_TEAM_ID (UUID) to list issues.")
        return 2
    try:
        out = gql(QUERY, {"teamId": team_id})
        team = out["data"]["team"]
        print(f"Issues (first 50) for team: {team['name']} ({team['id']})")
        for i, it in enumerate(team["issues"]["nodes"], 1):
            print(f"{i:02d}. {it['title']}  (id={it['id']})  createdAt={it['createdAt']}")
        return 0
    except LinearError as e:
        print("ERROR:", e)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
