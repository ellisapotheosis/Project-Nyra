from __future__ import annotations
from scripts._linear import gql, LinearError

QUERY = """
query Teams {
  teams {
    nodes {
      id
      key
      name
    }
  }
}
"""

def main() -> int:
    try:
        out = gql(QUERY)
        teams = out["data"]["teams"]["nodes"]
        print("Teams:")
        for t in teams:
            print(f"- {t['name']}  key={t.get('key')}  id={t['id']}")
        return 0
    except LinearError as e:
        print("ERROR:", e)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
