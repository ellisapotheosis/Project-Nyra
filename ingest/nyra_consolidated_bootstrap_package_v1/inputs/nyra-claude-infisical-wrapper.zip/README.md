# Nyra — Claude Code wrapper with Infisical secrets injection

This package gives you a wrapper executable you can point other tools at (ex: "chat cli wrapper"),
so every `claude ...` invocation runs through:

    infisical run ... -- claude ...

Why: you get **zero hard-coded secrets**, same behavior on dev/prod, and one place to control which
Infisical environment/path gets injected.

## Requirements
- Claude Code installed (native or npm/volta)
- Infisical CLI installed + authenticated (or INFISICAL_TOKEN set)

## Windows install (recommended)

1) Copy wrapper into your user bin:

Destination: `%USERPROFILE%\.local\bin\nyra-claude.cmd`

Auto-install:

```powershell
powershell -ExecutionPolicy Bypass -File windows\install_wrapper.ps1
```

2) Configure environment variables:

```powershell
setx INFISICAL_ENV "dev"
setx INFISICAL_PATH "/nyra"

# Optional (machine identity / service token flow)
# setx INFISICAL_PROJECT_ID "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
# setx INFISICAL_TOKEN "your_service_token_or_universal_auth_token"
```

3) Use this path in any "CLI wrapper" setting:

`%USERPROFILE%\.local\bin\nyra-claude.cmd`

## Notes
- The wrapper tries to locate the **Volta** shim first (\Volta\bin\claude.cmd) to avoid recursion.
- If you migrate to the Claude Code native installer later, the wrapper will still work because it falls back to `where.exe claude`.
