@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM ------------------------------------------------------------
REM Nyra Claude wrapper (Windows CMD)
REM Runs Claude Code with secrets injected via Infisical.
REM
REM ENV you can set:
REM   INFISICAL_ENV          (default: dev)
REM   INFISICAL_PATH         (default: /)
REM   INFISICAL_PROJECT_ID   (optional; needed for machine identity)
REM   INFISICAL_CONFIG_DIR   (optional; monorepo support)
REM   INFISICAL_TOKEN        (optional; machine identity/service token)
REM ------------------------------------------------------------

where infisical >nul 2>nul
if errorlevel 1 (
  echo ERROR: Infisical CLI not found in PATH. Install Infisical CLI first.
  exit /b 1
)

REM Prefer Volta's claude.cmd if present (prevents calling ourselves)
set "CLAUDE_REAL="
for /f "usebackq delims=" %%i in (`where.exe claude ^| findstr /i "\\Volta\\bin\\claude\.cmd$"`) do (
  set "CLAUDE_REAL=%%i"
  goto :found
)

REM Fallback to first `where` result
for /f "usebackq delims=" %%i in (`where.exe claude`) do (
  set "CLAUDE_REAL=%%i"
  goto :found
)

:found
if "%CLAUDE_REAL%"=="" (
  echo ERROR: Could not locate claude in PATH. Install Claude Code first.
  exit /b 1
)

set "INF_ENV=%INFISICAL_ENV%"
if "%INF_ENV%"=="" set "INF_ENV=dev"

set "INF_PATH=%INFISICAL_PATH%"
if "%INF_PATH%"=="" set "INF_PATH=/"

set "EXTRA="
if not "%INFISICAL_PROJECT_ID%"=="" set "EXTRA=%EXTRA% --projectId=%INFISICAL_PROJECT_ID%"
if not "%INFISICAL_CONFIG_DIR%"=="" set "EXTRA=%EXTRA% --project-config-dir=%INFISICAL_CONFIG_DIR%"

REM Run: infisical run [options] -- <command>
infisical run %EXTRA% --env=%INF_ENV% --path=%INF_PATH% -- "%CLAUDE_REAL%" %*
exit /b %errorlevel%
