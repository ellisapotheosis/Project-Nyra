\
$ErrorActionPreference = "Stop"
$destDir = Join-Path $env:USERPROFILE ".local\bin"
New-Item -ItemType Directory -Force -Path $destDir | Out-Null

Copy-Item -Force -Path (Join-Path $PSScriptRoot "nyra-claude.cmd") -Destination (Join-Path $destDir "nyra-claude.cmd")
Copy-Item -Force -Path (Join-Path $PSScriptRoot "nyra-claude.ps1") -Destination (Join-Path $destDir "nyra-claude.ps1")

Write-Host "Installed:"
Write-Host "  $destDir\nyra-claude.cmd"
Write-Host "  $destDir\nyra-claude.ps1"
Write-Host ""
Write-Host "If '$destDir' is not on PATH, add it (User PATH) then open a new terminal."
