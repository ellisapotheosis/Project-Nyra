\
# Nyra Claude wrapper (PowerShell)
# Runs Claude Code with secrets injected via Infisical.
$ErrorActionPreference = "Stop"

if (-not (Get-Command infisical -ErrorAction SilentlyContinue)) {
  throw "Infisical CLI not found in PATH. Install Infisical CLI first."
}

# Find the real Claude binary/shim (prefer Volta's shim to avoid recursion)
$claudes = & where.exe claude 2>$null
if (-not $claudes) { throw "Could not locate 'claude' in PATH. Install Claude Code first." }

$claudeReal = $claudes | Where-Object { $_ -match '\\Volta\\bin\\claude\.cmd$' } | Select-Object -First 1
if (-not $claudeReal) { $claudeReal = $claudes[0] }

$infEnv = $Env:INFISICAL_ENV
if ([string]::IsNullOrWhiteSpace($infEnv)) { $infEnv = "dev" }

$infPath = $Env:INFISICAL_PATH
if ([string]::IsNullOrWhiteSpace($infPath)) { $infPath = "/" }

$infArgs = @("run", "--env=$infEnv", "--path=$infPath")
if ($Env:INFISICAL_PROJECT_ID) { $infArgs += "--projectId=$($Env:INFISICAL_PROJECT_ID)" }
if ($Env:INFISICAL_CONFIG_DIR) { $infArgs += "--project-config-dir=$($Env:INFISICAL_CONFIG_DIR)" }

# Use --command to keep arg passing predictable on Windows
$escapedArgs = $args | ForEach-Object { '"' + ($_ -replace '"','\"') + '"' }
$cmd = '"' + $claudeReal + '" ' + ($escapedArgs -join ' ')

& infisical @infArgs --command $cmd
