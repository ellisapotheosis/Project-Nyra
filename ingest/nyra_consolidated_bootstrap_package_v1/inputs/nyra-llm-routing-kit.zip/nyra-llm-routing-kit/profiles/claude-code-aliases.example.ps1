\
# Claude Code model-alias overrides (PowerShell)
# Run in the same PowerShell session BEFORE launching `claude`.
# Replace CHANGE_ME values.

$env:OPENROUTER_API_KEY="sk-or-v1-CHANGE_ME"

# Point Claude Code to OpenRouter directly (no LiteLLM)
$env:ANTHROPIC_BASE_URL="https://openrouter.ai/api"
$env:ANTHROPIC_AUTH_TOKEN=$env:OPENROUTER_API_KEY
$env:ANTHROPIC_API_KEY=""  # Important: keep empty to avoid conflicts

# Override aliases to your preferred OpenRouter models
$env:ANTHROPIC_DEFAULT_SONNET_MODEL="anthropic/claude-sonnet-4.5"
$env:ANTHROPIC_DEFAULT_OPUS_MODEL="anthropic/claude-opus-4.5"

Write-Host "Claude Code configured. Launch with: claude --model sonnet"
