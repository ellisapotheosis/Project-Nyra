#!/usr/bin/env bash
# Claude Code model-alias overrides (bash/zsh)

export OPENROUTER_API_KEY="sk-or-v1-CHANGE_ME"
export ANTHROPIC_BASE_URL="https://openrouter.ai/api"
export ANTHROPIC_AUTH_TOKEN="$OPENROUTER_API_KEY"
export ANTHROPIC_API_KEY=""

export ANTHROPIC_DEFAULT_SONNET_MODEL="anthropic/claude-sonnet-4.5"
export ANTHROPIC_DEFAULT_OPUS_MODEL="anthropic/claude-opus-4.5"

echo "Claude Code configured. Launch with: claude --model sonnet"
