# Agentic-Flow run examples

## Explicit model (OpenRouter)
```bash
export OPENROUTER_API_KEY=sk-or-v1-...
npx agentic-flow --agent coder --task "Build a REST API" --model "deepseek/deepseek-r1"
```

## Let the optimizer choose
```bash
npx agentic-flow --agent coder --task "Build a REST API" --optimize
```

## Force cheaper
```bash
npx agentic-flow --agent coder --task "Rename a variable in 3 files" --optimize --priority cost
```

## Force higher quality
```bash
npx agentic-flow --agent system-architect --task "Design multi-tenant auth + rate-limits" --optimize --priority quality
```
