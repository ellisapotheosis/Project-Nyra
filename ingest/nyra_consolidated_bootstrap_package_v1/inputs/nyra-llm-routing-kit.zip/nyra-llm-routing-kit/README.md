# Nyra LLM Routing Kit (Claude-Flow + Agentic-Flow + OpenRouter + LiteLLM)

This kit gives you a **single LLM gateway** (LiteLLM) that both **Claude Code / Claude-Flow** and **Agentic-Flow** can use.
It also includes **profile system-prompts** you can reuse as “default system prompts” per agent.

> Replace all values in `.env.example` and the scripts marked with `CHANGE_ME`.

## Folder contents

- `llm-gateway/`
  - `docker-compose.yml` - runs LiteLLM proxy
  - `litellm-config.yaml` - model definitions & aliases
  - `.env.example` - secrets + keys
- `profiles/`
  - `openrouter-system-prompts.md` - 4 profile prompts (fast/balanced/reasoning/security)
  - `claude-code-aliases.example.ps1` - Windows PowerShell env vars for Claude Code aliases
  - `claude-code-aliases.example.sh` - bash/zsh equivalent
  - `agentic-flow-run-examples.md` - example commands

## Quick start (local)

1) Copy env file and set secrets

```bash
cd llm-gateway
cp .env.example .env
# edit .env
```

2) Start LiteLLM

```bash
docker compose up -d
```

3) Point Claude Code at LiteLLM

Set these environment variables **before** launching `claude`:

```bash
export ANTHROPIC_BASE_URL="http://localhost:4000"
export ANTHROPIC_AUTH_TOKEN="$LITELLM_MASTER_KEY"
export ANTHROPIC_API_KEY=""  # IMPORTANT: keep empty when proxying
```

4) Use Claude Code normally

```bash
claude --model sonnet "hello"
```

## Notes

- Claude Code can also be pointed directly to OpenRouter, but LiteLLM lets you do policy routing and share one gateway across tools.
