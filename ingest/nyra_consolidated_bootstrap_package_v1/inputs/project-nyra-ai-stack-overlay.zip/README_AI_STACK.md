# Project Nyra — AI Tooling + MCP Stack Overlay

This overlay adds a clean folder structure + containerization pattern for:
- **Claude Code Development Kit** (project-local `.claude/` + `docs/`)
- **mcp-gemini-assistant** (Python MCP server for Claude Code)

It also sets you up for *future* MCP services (serena, nexus router, etc.) without turning your repo into spaghetti.

---

## Folder structure (recommended)

This overlay assumes your `project-nyra` repo root looks like:

```
project-nyra/
  (your app code...)
  .claude/                 # created by Claude Code Dev Kit
  docs/                    # created by Claude Code Dev Kit
  ops/
    agentbox/              # containerized "AI workstation"
    mcp/                   # local MCP servers you run with Claude Code
```

Why:
- `.claude/` is **project-specific Claude Code config**. The Dev Kit *expects* to install here.  
- `ops/` holds infra + operational tooling that you don't want mixed into your app runtime.

---

## 1) Install Claude Code (host machine)

Claude Code official install options (native script / npm / etc):
- https://code.claude.com/docs/en/setup

---

## 2) Install Claude Code Development Kit INTO YOUR REPO ROOT

Run this from the **project-nyra repo root**.

Linux/macOS/WSL:
```bash
bash scripts/install_claude_dev_kit.sh
```

Windows (PowerShell, using WSL is recommended):
```powershell
powershell -ExecutionPolicy Bypass -File scripts\install_claude_dev_kit.ps1
```

What the kit installs (per its README):
- `.claude/commands`, `.claude/hooks`, `.claude/settings.local.json`
- `docs/ai-context`, `docs/specs`, etc.
- `logs/` at runtime

---

## 3) Add mcp-gemini-assistant (repo-local)

From repo root:

```bash
bash scripts/add_gemini_mcp_submodule.sh
```

Then configure your Gemini API key:

- copy `ops/mcp/mcp-gemini-assistant/.env.example` → `.env`
- set `GEMINI_API_KEY=...`

Finally add it to Claude Code (project-scoped):

```bash
claude mcp add gemini-coding -s project -- ops/mcp/mcp-gemini-assistant/start_server.sh
```

---

## 4) Containerized dev/prod-ish: "agentbox"

`agentbox` is a container that includes:
- Node + Claude Code (npm install)
- Python runtime (so MCP servers can run)
- a persistent volume for Claude auth state

Start it:

```bash
docker compose -f ops/agentbox/compose.ai.yml up -d --build
docker exec -it nyra-agentbox bash
```

Inside the container:

```bash
cd /workspace
claude
```

To register the Gemini MCP inside the container (one-time):

```bash
bash ops/agentbox/scripts/configure_mcp.sh
```

---

## Secrets

Put secrets in:
- `.env.ai` (for docker compose)
- `ops/mcp/*/.env` (per MCP server)

Never commit real keys.
