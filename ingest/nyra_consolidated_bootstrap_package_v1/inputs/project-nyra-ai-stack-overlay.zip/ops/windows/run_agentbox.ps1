\
# Quick start for Windows (PowerShell) from repo root:
# 1) copy .env.ai.example to .env.ai and fill GEMINI_API_KEY
# 2) docker compose -f ops\agentbox\compose.ai.yml up -d --build
# 3) docker exec -it nyra-agentbox bash
# 4) inside container: bash ops/agentbox/scripts/configure_mcp.sh ; then `claude`

Write-Host "1) Ensure you have Docker Desktop + WSL2 enabled."
Write-Host "2) Copy .env.ai.example -> .env.ai and set GEMINI_API_KEY."
Write-Host "3) Starting agentbox..."

docker compose -f ops\agentbox\compose.ai.yml up -d --build

Write-Host "Entering container..."
docker exec -it nyra-agentbox bash
