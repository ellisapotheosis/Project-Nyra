#!/usr/bin/env bash
set -euo pipefail

cd /workspace

if ! command -v claude >/dev/null 2>&1; then
  echo "ERROR: claude not found in PATH"
  exit 1
fi

if [ ! -d "ops/mcp/mcp-gemini-assistant" ]; then
  echo "ERROR: ops/mcp/mcp-gemini-assistant not found."
  echo "Run: bash scripts/add_gemini_mcp_submodule.sh"
  exit 1
fi

# Ensure GEMINI_API_KEY is present (for the MCP server .env)
if [ -z "${GEMINI_API_KEY:-}" ]; then
  echo "ERROR: GEMINI_API_KEY not set. Put it in .env.ai (compose env_file) and re-up."
  exit 1
fi

# Create MCP server .env if it doesn't exist
if [ ! -f "ops/mcp/mcp-gemini-assistant/.env" ]; then
  if [ -f "ops/mcp/mcp-gemini-assistant/.env.example" ]; then
    cp ops/mcp/mcp-gemini-assistant/.env.example ops/mcp/mcp-gemini-assistant/.env
  else
    touch ops/mcp/mcp-gemini-assistant/.env
  fi
  # Append/replace GEMINI_API_KEY
  grep -v '^GEMINI_API_KEY=' ops/mcp/mcp-gemini-assistant/.env > /tmp/gemini_env || true
  echo "GEMINI_API_KEY=${GEMINI_API_KEY}" >> /tmp/gemini_env
  mv /tmp/gemini_env ops/mcp/mcp-gemini-assistant/.env
fi

echo "Registering gemini-coding MCP server for this project..."
# Project-scoped MCP registration (safe to commit .mcp.json if created by claude)
claude mcp add gemini-coding -s project -- ops/mcp/mcp-gemini-assistant/start_server.sh || true

echo "Done."
echo "Tip: run 'claude mcp list' to verify."
