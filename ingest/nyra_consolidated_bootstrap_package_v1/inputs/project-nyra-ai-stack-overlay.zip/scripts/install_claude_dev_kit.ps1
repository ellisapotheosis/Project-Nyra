\
# Run from your project-nyra repo root:
#   powershell -ExecutionPolicy Bypass -File scripts\install_claude_dev_kit.ps1
# Note: The Dev Kit repo warns Windows has reported bugs; WSL is recommended.

$ErrorActionPreference = "Stop"

Write-Host "Installing Claude Code Development Kit into this repo root: $PWD"
$installUrl = "https://raw.githubusercontent.com/peterkrueck/Claude-Code-Development-Kit/main/install.sh"

# Requires WSL or Git Bash; easiest path is WSL:
if (Get-Command wsl -ErrorAction SilentlyContinue) {
  Write-Host "Using WSL to run the installer..."
  wsl bash -lc "cd `"$PWD`" && curl -fsSL $installUrl | bash"
} else {
  throw "WSL not found. Install WSL (recommended) or run the installer from Git Bash."
}
