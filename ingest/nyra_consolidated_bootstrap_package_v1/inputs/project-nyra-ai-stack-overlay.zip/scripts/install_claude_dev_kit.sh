#!/usr/bin/env bash
set -euo pipefail

echo "Installing Claude Code Development Kit into THIS project directory: $(pwd)"
echo "This will create .claude/ and docs/ in the repo root."

# Preferred: quick install (interactive)
curl -fsSL https://raw.githubusercontent.com/peterkrueck/Claude-Code-Development-Kit/main/install.sh | bash
