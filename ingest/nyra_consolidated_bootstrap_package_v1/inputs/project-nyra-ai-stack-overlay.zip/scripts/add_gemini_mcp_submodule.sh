#!/usr/bin/env bash
set -euo pipefail

mkdir -p ops/mcp

if [ -d "ops/mcp/mcp-gemini-assistant" ]; then
  echo "ops/mcp/mcp-gemini-assistant already exists."
  exit 0
fi

echo "Adding mcp-gemini-assistant as a git submodule..."
git submodule add https://github.com/peterkrueck/mcp-gemini-assistant ops/mcp/mcp-gemini-assistant
git submodule update --init --recursive

echo "Submodule added at ops/mcp/mcp-gemini-assistant"
