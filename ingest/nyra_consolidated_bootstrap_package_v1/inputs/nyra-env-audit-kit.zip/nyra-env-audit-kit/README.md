# Nyra Env & Stack Audit Kit

This kit helps you:
- Inventory all environment variables referenced across /infra, /apps, /services, & worker stacks
- Detect missing env vars compared to your current .env files
- Collect Docker container status + failing logs into a bundle you can share with agents
- Produce an Infisical import template (JSON) for missing secrets

## Quick start (Windows PowerShell)
1) Copy this folder anywhere (or unzip)
2) From your Project-Nyra repo root:
   ```powershell
   Set-Location C:\Dev\Projects\Repos\Project-Nyra
   .\tools\nyra-env-audit.ps1 -RepoRoot . -OutDir .\_audit
   ```
3) Review outputs in `./_audit/`

## Quick start (WSL/Linux/macOS)
```bash
cd /path/to/Project-Nyra
bash tools/nyra-env-audit.sh . ./_audit
```

## Outputs
- env_inventory.csv            # all referenced vars + where used
- missing_env_report.md        # vars referenced but not set in your .env files
- docker_status.md             # docker ps + compose ls + summaries
- docker_logs/                 # last 300 lines for failing containers (if names provided)
- infisical_missing_secrets.json  # template you can import or use to create secrets

## Notes
- This is a best-effort static scan. It won't catch vars built dynamically at runtime.
- It flags likely secrets by name patterns: KEY, TOKEN, SECRET, PASS, PWD, PRIVATE, CERT.
