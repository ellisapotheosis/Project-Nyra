param(
  [string]$CudaTestImage = "nvidia/cuda:12.8.0-base-ubuntu24.04"
)
$ErrorActionPreference = "Stop"

Write-Host "== Docker Desktop / WSL2 / GPU sanity checks =="
docker version
docker context ls
wsl.exe -l -v

Write-Host "`n== GPU in Docker test =="
docker run --rm --gpus all $CudaTestImage nvidia-smi

Write-Host "`n== Tailscale status =="
tailscale status | Select-Object -First 40
