#!/usr/bin/env bash
set -euo pipefail
docker version
docker context ls || true
docker run --rm --gpus all nvidia/cuda:12.8.0-base-ubuntu24.04 nvidia-smi
