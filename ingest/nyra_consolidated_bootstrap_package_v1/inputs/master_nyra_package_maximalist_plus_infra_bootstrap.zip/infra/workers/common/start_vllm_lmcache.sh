#!/usr/bin/env bash
set -euo pipefail

MODEL="${VLLM_MODEL:?VLLM_MODEL is required}"
PORT="${VLLM_PORT:-8000}"
GPU_MEM="${VLLM_GPU_MEM_UTIL:-0.92}"
TP="${VLLM_TENSOR_PARALLEL_SIZE:-1}"
MAX_LEN="${VLLM_MAX_MODEL_LEN:-16384}"
DTYPE="${VLLM_DTYPE:-auto}"
TRUST="${VLLM_TRUST_REMOTE_CODE:-false}"

KV_JSON='{"kv_connector":"LMCacheConnectorV1","kv_role":"kv_both"}'

echo "[nyra-vllm] starting model=${MODEL} port=${PORT} tp=${TP} max_len=${MAX_LEN}"
exec python -m vllm.entrypoints.openai.api_server \
  --host 0.0.0.0 \
  --port "${PORT}" \
  --model "${MODEL}" \
  --dtype "${DTYPE}" \
  --tensor-parallel-size "${TP}" \
  --gpu-memory-utilization "${GPU_MEM}" \
  --max-model-len "${MAX_LEN}" \
  --kv-transfer-config "${KV_JSON}" \
  $( [[ "${TRUST}" == "true" ]] && echo "--trust-remote-code" )
