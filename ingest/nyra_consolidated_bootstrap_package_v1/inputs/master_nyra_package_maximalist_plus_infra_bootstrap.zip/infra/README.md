# Project Nyra Infra Bootstrap (Maximalist + consolidated)

This package is a consolidated `infra/` bootstrap meant to be dropped into your repo and iterated from.
It is built on top of `master_nyra_package_maximalist.zip` and incorporates additional uploaded compose/config fragments plus new modular files.

## Key directories
- `infra/orchestrator/` — main stack (Nexus + LiteLLM + apps + workflows + memory + observability)
- `infra/worker-rtx5090/` — vLLM + LMCache + Redis (Blackwell source-build)
- `infra/worker-rtx3090ti/` — vLLM + LMCache + Redis (official/pinned image variants)
- `infra/worker-rtx3060/` — Ollama worker
- `infra/workers/common/` — shared LMCache configs / scripts
- `infra/configs/env/` — env templates
- `infra/_ingested_uploads/` — raw uploaded files/zips copied for audit/reference
- `infra/docs/` — ports/env/architecture docs

## Use Nexus as the single entrypoint
Point agent frameworks and tools at:
- MCP: `http://orchestrator.tail-net.ts.net:6000/mcp`
- OpenAI-compatible LLM: `http://orchestrator.tail-net.ts.net:6000/llm/openai/v1`
- Anthropic-compatible LLM: `http://orchestrator.tail-net.ts.net:6000/llm/anthropic`
