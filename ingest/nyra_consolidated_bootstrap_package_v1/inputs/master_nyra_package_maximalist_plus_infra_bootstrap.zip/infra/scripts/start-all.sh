#!/usr/bin/env bash
set -euo pipefail
(
  cd "$(dirname "$0")/../worker-rtx5090"
  docker compose --env-file ../configs/env/.env.worker-rtx5090.example up -d --build
)
(
  cd "$(dirname "$0")/../worker-rtx3090ti"
  docker compose --env-file ../configs/env/.env.worker-rtx3090ti.example up -d --build
)
(
  cd "$(dirname "$0")/../worker-rtx3060"
  docker compose --env-file ../configs/env/.env.worker-rtx3060.example up -d
)
(
  cd "$(dirname "$0")/../orchestrator"
  docker compose --env-file ../configs/env/.env.orchestrator.example up -d --build
)
