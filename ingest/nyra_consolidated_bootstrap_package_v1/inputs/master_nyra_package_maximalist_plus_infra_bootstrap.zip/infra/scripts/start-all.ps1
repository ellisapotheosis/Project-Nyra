$ErrorActionPreference = "Stop"

Write-Host "Start GPU workers first..."
Push-Location "$PSScriptRoot\..\worker-rtx5090"
docker compose --env-file ..\configs\env\.env.worker-rtx5090.example up -d --build
Pop-Location

Push-Location "$PSScriptRoot\..\worker-rtx3090ti"
docker compose --env-file ..\configs\env\.env.worker-rtx3090ti.example up -d --build
Pop-Location

Push-Location "$PSScriptRoot\..\worker-rtx3060"
docker compose --env-file ..\configs\env\.env.worker-rtx3060.example up -d
Pop-Location

Write-Host "Start orchestrator..."
Push-Location "$PSScriptRoot\..\orchestrator"
docker compose --env-file ..\configs\env\.env.orchestrator.example up -d --build
Pop-Location
