#!/usr/bin/env bash
set -euo pipefail
mkdir -p /app/.swarm /app/logs /app/.claude-flow
# Best-effort startup sequence. Adjust command to upstream cli syntax.
if command -v claude-flow >/dev/null 2>&1; then
  exec claude-flow mcp serve --host 0.0.0.0 --port 8080
elif command -v cf >/dev/null 2>&1; then
  exec cf mcp serve --host 0.0.0.0 --port 8080
else
  exec node -e 'require("http").createServer((_,r)=>r.end("claude-flow placeholder")).listen(8080,"0.0.0.0")'
fi
