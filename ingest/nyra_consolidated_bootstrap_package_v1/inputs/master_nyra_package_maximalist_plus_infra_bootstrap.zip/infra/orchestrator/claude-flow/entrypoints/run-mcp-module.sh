#!/usr/bin/env bash
set -euo pipefail
MODULE="${1:-}"
PORT="${2:-8080}"
if [[ -z "${MODULE}" ]]; then
  echo "Usage: run-mcp-module.sh <module-binary> [port]" >&2
  exit 1
fi
exec bash -lc "${MODULE} --host 0.0.0.0 --port ${PORT}"
