#!/usr/bin/env bash
set -euo pipefail
pkgs=(
  claude-flow
  @ruvnet/claude-flow-cli
  @ruvnet/claude-flow-mcp
  @ruvnet/claude-flow-providers
  @ruvnet/claude-flow-memory
  @ruvnet/agentdb
  @ruvnet/agentic-flow
  @ruvnet/epic-sdk
  @ruvnet/agent-booster
  @ruvnet/ruv-swarm
  @ruvnet/ruvector
  @ruvnet/ruvector-cli
  onnxruntime-node
)
npm config set fund false
npm config set update-notifier false
for p in "${pkgs[@]}"; do
  echo "Installing $p"
  npm i -g "$p" || true
done
