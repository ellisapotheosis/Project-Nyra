#!/usr/bin/env sh
set -eu
sleep 3
IFS=','; for model in ${OLLAMA_MODELS:-qwen2.5:7b-instruct}; do
  echo "Pulling $model"
  ollama pull "$model" || true
done
wait
