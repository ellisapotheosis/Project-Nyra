# Upload Audit / Integration Notes

Generated: 2026-02-25T04:46:52.676937Z

## What was used directly
- `master_nyra_package_maximalist.zip` as base extraction
- `ports.txt` (treated as most recent source-of-truth for ports + Tailscale IPs, per request)
- `envs-accum.txt`
- `02-MASTER-ARCHITECTURE.md`
- `docker-compose.archon.yml`, `docker-compose.claude-flow.yml`, `docker-compose.claude-flow-cicd.yml`
- `docker-compose.services.yml`, `docker-compose.dashboard.yml`, `docker-compose.orchestrator-cf-tunnel.yml`
- `nexus-complete.toml`, `nexus-complete.yaml`, `intelligent-routing-config.json`
- `Dockerfile.txt` (copied into `infra/orchestrator/mcp/graphiti-mcp/Dockerfile`)
- `prometheus.yml`, `loki.yml`, `datasource.yml`, `pg_hba.conf`, `postgresql.conf`

## Provenance
Raw uploaded files and uploaded ZIP archives are copied to:
- `infra/_ingested_uploads/`

## Conflict resolution (explicit)
You previously sent a newer-looking Tailscale mapping in chat, but then requested that the **ports document is the most recent**.
This package therefore uses the IP/host mapping from `ports.txt`:
- orchestrator → `100.64.0.1`
- worker-rtx5090 → `100.64.0.10`
- worker-rtx3060 → `100.64.0.11`
- worker-rtx3090ti → `100.64.0.12`

## Removed services (per request)
This package intentionally excludes/removes:
- Dify
- Open WebUI
- LobeChat
- Mem0 / OpenMemory MCP
- OpenRouter
