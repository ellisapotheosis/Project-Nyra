# Claude-Flow via Docker (Windows Wrapper Kit)

This avoids global `npm` installs entirely — **no more `MODULE_NOT_FOUND` shims**.
Instead, every `claude-flow ...` command runs inside the Docker image documented by the project wiki.

The wiki shows:
- `docker pull ruvnet/claude-flow:v2-alpha`
- `docker run ... -v $(pwd):/workspace ... ruvnet/claude-flow:v2-alpha`
- then `claude-flow init --docker` inside the container

## 0) Prereqs
- Docker Desktop installed + running
- Make sure your drive (C:) is shared in Docker Desktop settings
- Set your API key in the shell before running:

PowerShell:
```powershell
$env:ANTHROPIC_API_KEY="YOUR_KEY_HERE"
```

## 1) One-shot usage (recommended)
From your repo:
```powershell
cd C:\Dev\Projects\Repos\GOAL-GOAP
.\claude-flow.cmd project init --template full-stack
```

Under the hood it runs:
```powershell
docker run --rm -it -v ${PWD}:/workspace -w /workspace `
  -e ANTHROPIC_API_KEY=$env:ANTHROPIC_API_KEY `
  ruvnet/claude-flow:v2-alpha claude-flow <args>
```

## 2) Persistent container (optional)
If you want a named container you can re-enter:
```powershell
docker pull ruvnet/claude-flow:v2-alpha
docker run -it --name claude-flow -v ${PWD}:/workspace -e ANTHROPIC_API_KEY=$env:ANTHROPIC_API_KEY ruvnet/claude-flow:v2-alpha
# inside:
claude-flow init --docker
```

## Notes
- If you previously installed claude-flow globally, **it can stay broken** — this wrapper bypasses it.
- If you use Git Bash, swap `${PWD}` for `$(pwd)` in the docker command.
