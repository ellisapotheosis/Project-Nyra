<# 
claude-flow.ps1
Runs claude-flow inside Docker.

Usage:
  .\claude-flow.ps1 project init --template full-stack
#>
[CmdletBinding(PositionalBinding=$false)]
param(
  [Parameter(ValueFromRemainingArguments=$true)]
  [string[]]$Args
)

$ErrorActionPreference = "Stop"

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
  throw "docker not found on PATH. Install Docker Desktop and restart your terminal."
}

$img = if ($env:CLAUDE_FLOW_IMAGE) { $env:CLAUDE_FLOW_IMAGE } else { "ruvnet/claude-flow:v2-alpha" }

if (-not $env:ANTHROPIC_API_KEY) {
  Write-Host "⚠️  ANTHROPIC_API_KEY not set in environment." -ForegroundColor Yellow
  Write-Host "   Set it like:  `$env:ANTHROPIC_API_KEY = 'YOUR_KEY_HERE'" -ForegroundColor Yellow
}

# Ensure image exists (best-effort pull; non-fatal if offline)
try {
  docker image inspect $img *> $null
} catch {
  Write-Host "Pulling image: $img"
  docker pull $img
}

$pwdPath = (Get-Location).Path

docker run --rm -it `
  -v "${pwdPath}:/workspace" `
  -w /workspace `
  -e "ANTHROPIC_API_KEY=$env:ANTHROPIC_API_KEY" `
  $img claude-flow @Args
