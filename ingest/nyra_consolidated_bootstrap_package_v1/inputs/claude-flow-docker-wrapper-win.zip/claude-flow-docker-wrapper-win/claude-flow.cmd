@echo off
REM claude-flow.cmd - calls the PowerShell wrapper
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0claude-flow.ps1" %*
