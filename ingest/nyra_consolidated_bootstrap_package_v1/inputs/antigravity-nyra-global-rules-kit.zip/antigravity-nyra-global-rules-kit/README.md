# Antigravity Global Rules Kit (Maximalist) — Project Nyra Edition

This kit gives you:
- **Global rules** for Google Antigravity (safe, rigorous, artifact-driven)
- **Workspace rules** tailored to Project Nyra
- **Workflows** you can invoke via `/sparc-mvp`, `/compose-up`, etc.

## What Antigravity expects
- Global rules file: `~/.gemini/GEMINI.md`
- Workspace rules/workflows can be stored under `.agent/` (created by Antigravity Customizations UI)
- Individual rule/workflow files should stay under ~12k characters.

## Install (recommended)
### Option A — Use Antigravity UI
1) Open Antigravity → Customizations → Rules → **+ Global**
2) Paste contents of `GLOBAL_GEMINI.md`
3) For Project Nyra workspace: Customizations → Rules → **+ Workspace**
4) Paste contents of `workspace/.agent/rules/nyra.md`
5) Customizations → Workflows → **+ Workspace**
6) Create workflows named:
   - `sparc-mvp` (paste `workspace/.agent/workflows/sparc-mvp.md`)
   - `compose-up` (paste `workspace/.agent/workflows/compose-up.md`)
   - `pr-factory` (paste `workspace/.agent/workflows/pr-factory.md`)
   - `lead-ingest` (paste `workspace/.agent/workflows/lead-ingest.md`)

### Option B — Copy files manually
1) Copy `GLOBAL_GEMINI.md` → `~/.gemini/GEMINI.md`
2) Copy `workspace/.agent` → your Project Nyra repo root.

## Git note
If you do NOT want `.agent` committed, avoid putting it in `.gitignore` if Antigravity fails to auto-load it.
A common approach is to use `.git/info/exclude` for local ignores.

## Usage
- In an agent chat, run workflows via slash commands:
  - `/sparc-mvp` (end-to-end SPARC)
  - `/compose-up` (safe compose boot)
  - `/pr-factory` (PR discipline)
  - `/lead-ingest` (n8n ingestion)

