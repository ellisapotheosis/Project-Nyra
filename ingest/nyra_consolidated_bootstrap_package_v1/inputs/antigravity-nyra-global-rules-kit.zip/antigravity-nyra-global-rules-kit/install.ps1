param(
  [string]$RepoDir = (Get-Location).Path
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$GeminiDir = Join-Path $HOME ".gemini"
$GlobalDest = Join-Path $GeminiDir "GEMINI.md"

New-Item -ItemType Directory -Force -Path $GeminiDir | Out-Null
Copy-Item -Force (Join-Path $ScriptDir "GLOBAL_GEMINI.md") $GlobalDest

# Copy workspace customizations
$AgentDest = Join-Path $RepoDir ".agent"
New-Item -ItemType Directory -Force -Path $AgentDest | Out-Null
Copy-Item -Recurse -Force (Join-Path $ScriptDir "workspace/.agent/*") $AgentDest

Write-Host "✅ Installed global rules to: $GlobalDest"
Write-Host "✅ Installed workspace rules/workflows to: $AgentDest"
Write-Host "Tip: start a NEW chat in Antigravity for rules to apply."
