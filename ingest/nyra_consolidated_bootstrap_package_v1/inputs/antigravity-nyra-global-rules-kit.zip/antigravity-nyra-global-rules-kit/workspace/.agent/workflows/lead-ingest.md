# /lead-ingest — Build WF_LEAD_INGEST (n8n)

## Intent
Implement a lead-ingestion workflow that normalizes, dedupes, writes to TwentyCRM, & logs to nyra_ai.

## Steps
1) Define input adapters:
   - email parsed payload
   - webhook/API payload
   - leadmailbox payload
2) Create a normalization function (map fields to canonical schema).
3) Compute idempotency key (email/phone + source + timestamp bucket).
4) Dedupe check:
   - search Twenty by email/phone
   - if exists, update; else create
5) Persist message trace in nyra_ai (MessageEvent).
6) Emit event "LeadCreatedOrUpdated" to trigger campaign assign.
7) Add structured error handling + retry-safe behavior.

## Output
- n8n workflow JSON export OR node-by-node build sheet
- sample payloads
- env vars required

## Success criteria
- Posting same lead twice does not create duplicates
- Writes visible in TwentyCRM
