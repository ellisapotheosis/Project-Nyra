#!/usr/bin/env bash
set -euo pipefail

# Install Antigravity global + workspace rules.
# Usage:
#   ./install.sh /path/to/project-nyra
# If repo path omitted, uses current directory.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="${1:-$(pwd)}"

GEMINI_DIR="${HOME}/.gemini"
mkdir -p "${GEMINI_DIR}"

cp -f "${SCRIPT_DIR}/GLOBAL_GEMINI.md" "${GEMINI_DIR}/GEMINI.md"

# Copy workspace customizations
mkdir -p "${REPO_DIR}/.agent"
cp -R "${SCRIPT_DIR}/workspace/.agent/"* "${REPO_DIR}/.agent/"

echo "✅ Installed global rules to: ${GEMINI_DIR}/GEMINI.md"
echo "✅ Installed workspace rules/workflows to: ${REPO_DIR}/.agent"
echo "Tip: restart Antigravity chats to ensure rules load."
