# NYRA-Orch (Archon-style Orchestrator + AgentZero + DeepCode + FastMCP + Chroma)

## TL;DR
1. Edit `.env` with your keys (optional to run basic).
2. Double-click `bootstrap.bat` (or run `./bootstrap.ps1`).
3. Watch the console: FastMCP starts, demo tasks seed, and the orchestrator spawns per-task DeepCode instances on ports 8601, 8602, ...

## Why this combo?
- **Archon-style orchestrator**: spawns *one DeepCode per task* for clean isolation and parallelism.
- **AgentZero**: Computer-Use + Browser-Use + Voice; the overseer that wires tools and validates outputs.
- **FastMCP**: minimal but extensible stdio MCP server (filesystem, fetch, git_clone).
- **ChromaDB**: dead-simple local memory scratchpad to start; later upgrade to memOS/Graphiti/FalkorDB as needed.

## Commands (via Rye)
- `rye run mcp` — start FastMCP stdio server
- `rye run deepcode-seed` — write sample tasks.json
- `rye run archon` — run orchestrator (spawns DeepCode per task)
- `rye run memory-check` — basic write+query memory test

## Next steps
- Point AgentZero at `agentzero/prompts/profiles/nyra-a0-archon.md` and use `prompts/AGENTZERO_FIRST_TASK.txt` as the opening brief.
- Replace `orchestrator/tasks.json` with real tasks.
- Expand `fastmcp/server.py` with your Docker MCP servers or proxy to them.
