from fastmcp import FastMCP
import subprocess, os, urllib.request

mcp = FastMCP("NYRA-FastMCP")

@mcp.tool
def fs_list(path: str = ".") -> list[str]:
    "List directory contents"
    return os.listdir(path)

@mcp.tool
def fetch_url(url: str) -> str:
    "Fetch content via stdlib"
    with urllib.request.urlopen(url) as r:
        return r.read().decode("utf-8", errors="ignore")

@mcp.tool
def git_clone(repo_url: str, dest: str = "repos") -> str:
    "Clone a git repo into ./repos (relative)"
    os.makedirs(dest, exist_ok=True)
    subprocess.check_call(["git", "clone", repo_url], cwd=dest)
    return os.path.abspath(os.path.join(dest, os.path.basename(repo_url).replace(".git","")))

if __name__ == "__main__":
    mcp.run()  # stdio server
