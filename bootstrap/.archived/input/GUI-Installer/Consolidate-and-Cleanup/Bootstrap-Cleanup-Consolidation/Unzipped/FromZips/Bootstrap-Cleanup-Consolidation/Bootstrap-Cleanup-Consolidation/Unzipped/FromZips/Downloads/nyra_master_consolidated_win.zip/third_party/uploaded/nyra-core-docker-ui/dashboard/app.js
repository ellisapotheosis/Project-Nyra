async function callEndpoint(path){
  const text = document.getElementById('prompt').value || '';
  const model = document.getElementById('model').value || null;
  const res = await fetch(path, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({text, model})
  });
  const data = await res.json();
  document.getElementById('output').textContent = JSON.stringify(data, null, 2);
}
