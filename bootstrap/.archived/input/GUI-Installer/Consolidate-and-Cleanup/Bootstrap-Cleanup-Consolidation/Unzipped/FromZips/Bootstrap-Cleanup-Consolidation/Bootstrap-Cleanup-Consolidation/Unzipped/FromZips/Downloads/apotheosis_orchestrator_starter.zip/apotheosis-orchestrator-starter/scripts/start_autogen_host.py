import argparse
import asyncio
from autogen_ext.runtimes.grpc import GrpcWorkerAgentRuntimeHost

async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="0.0.0.0:50051", help="host:port to bind gRPC host")
    args = parser.parse_args()
    host = GrpcWorkerAgentRuntimeHost(address=args.host)
    print(f"[host] starting GrpcWorkerAgentRuntimeHost on {args.host}")
    await host.start()
    print("[host] running; Ctrl+C to stop")
    try:
        await host.stop_when_signal()
    except KeyboardInterrupt:
        pass
    finally:
        print("[host] stopping")
        await host.stop()

if __name__ == "__main__":
    asyncio.run(main())
