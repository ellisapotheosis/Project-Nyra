@echo off
REM Start NYRA local stack (Windows)

REM Launch local Ollama agent (ensure it is installed and on PATH)
start /B ollama serve

REM Optional: Launch AnythingLLM or LM Studio here if used

REM Start the FastAPI control center
start /B uvicorn app:app --host 0.0.0.0 --port 7860

REM Start Cloudflare tunnel
cloudflared tunnel run gpu-agent

pause