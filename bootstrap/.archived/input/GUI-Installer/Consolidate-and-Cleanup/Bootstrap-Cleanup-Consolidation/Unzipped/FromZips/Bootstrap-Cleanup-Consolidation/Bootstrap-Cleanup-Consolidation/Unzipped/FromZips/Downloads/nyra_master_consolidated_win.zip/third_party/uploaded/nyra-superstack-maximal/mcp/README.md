MCP mesh via **MetaMCP** (group servers into channels). Expose to UIs via **MCPO** if needed.
Servers: GitHub, Notion, Filesystem, Activepieces, Infisical, Qdrant, Graphiti, FalkorDB, Zep, Gemini-Assistant, Flow‑Nexus/Claude‑Flow, Archon, Roo/Ruv, FastMCP, Claude‑router.
