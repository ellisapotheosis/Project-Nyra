#!/usr/bin/env bash
set -euo pipefail
# Dump LibreChat MongoDB (container name from docker compose service: mongodb)
OUT_DIR="${OUT_DIR:-./backups/mongo}"
mkdir -p "$OUT_DIR"
TS=$(date +%Y%m%d_%H%M%S)
docker exec mongodb mongodump --archive --gzip --db=librechat > "$OUT_DIR/mongo_librechat_$TS.archive.gz"
echo "[mongo] dump saved to $OUT_DIR/mongo_librechat_$TS.archive.gz"
