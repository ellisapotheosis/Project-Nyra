# Security

- Keep `.env` out of git. Prefer GitHub OIDC or Infisical MCP for secrets.
- Put dev UIs behind Cloudflare Tunnel/CNAME and optional Basic Auth (Caddy/NGINX).
- Enforce budgets/rate limits at LiteLLM; per-agent keys and policies.
- Limit MCP tools available to public agents via **metamcp channels**.
- Rotate keys regularly; audit logs via Loki; alert in Grafana.
