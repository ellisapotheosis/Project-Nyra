# CI for Prompts (Promptfoo)

- GitHub Actions workflow at `.github/workflows/prompt-eval.yml` runs evals on PRs.
- View richer CI/CD options in Promptfoo docs if you add GitLab/Jenkins later.
