AgentZero runner. Integrate with LiteLLM router and MCP tools for code + research loops.
