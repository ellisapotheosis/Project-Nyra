Codanna indexing — wire as MCP for codebase search and embeddings for coding agents.
