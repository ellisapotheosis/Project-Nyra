\
  Param(
    [string]$RepoDir = "$HOME\Documents\DevProjects\ApotheosisPromptStack",
    [switch]$StartContainers
  )
  Write-Host "Creating $RepoDir"
  New-Item -ItemType Directory -Force -Path $RepoDir | Out-Null
  $zip = "$PSScriptRoot\..\apotheosis-promptstack.zip"
  if (Test-Path $zip) { Expand-Archive -Path $zip -DestinationPath $RepoDir -Force }
  Copy-Item -Recurse -Force "$PSScriptRoot\..\apotheosis_promptstack\*" $RepoDir
  Copy-Item -Recurse -Force "$PSScriptRoot\..\apotheosis_promptstack_pro\*" $RepoDir
  Set-Location $RepoDir
  if (-Not (Test-Path ".env")) { Copy-Item ".env.example" ".env" }
  if ($StartContainers) {
    docker compose --env-file .\.env up -d
  }
  Write-Host "Done."
