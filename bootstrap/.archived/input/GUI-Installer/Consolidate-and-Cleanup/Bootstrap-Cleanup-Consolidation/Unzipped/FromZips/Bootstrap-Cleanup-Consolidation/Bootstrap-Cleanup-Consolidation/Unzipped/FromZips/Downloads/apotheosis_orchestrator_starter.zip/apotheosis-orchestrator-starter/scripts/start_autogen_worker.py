import argparse
import asyncio
from dataclasses import dataclass
from autogen_core import DefaultTopicId, MessageContext, RoutedAgent, default_subscription, message_handler
from autogen_ext.runtimes.grpc import GrpcWorkerAgentRuntime

@dataclass
class Ping:
    content: str

@default_subscription
class EchoAgent(RoutedAgent):
    def __init__(self, name: str) -> None:
        super().__init__(name)

    @message_handler
    async def on_ping(self, msg: Ping, ctx: MessageContext):
        print(f"[{self.name}] received: {msg.content}")
        await self.publish_message(Ping(content=f"ack from {self.name}"), DefaultTopicId())

async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", required=True, help="host:port of the gRPC host service")
    parser.add_argument("--name", required=True, help="agent/worker name")
    args = parser.parse_args()

    worker = GrpcWorkerAgentRuntime(host_address=args.host)
    print(f"[worker:{args.name}] connecting to {args.host}")
    await worker.start()
    await EchoAgent.register(worker, args.name, lambda: EchoAgent(args.name))
    print(f"[worker:{args.name}] registered; Ctrl+C to stop")
    try:
        await worker.stop_when_signal()
    except KeyboardInterrupt:
        pass
    finally:
        print(f"[worker:{args.name}] stopping")
        await worker.stop()

if __name__ == "__main__":
    asyncio.run(main())
