# Roadmap

- v0: Profiles for base/ui/rag/obs; core endpoints; LiteLLM; Qdrant; Open WebUI/LobeChat
- v1: MCP packs (GitHub/Notion/Filesystem/Activepieces/Qdrant/Graphiti/FalkorDB/Zep) + MCPO
- v2: Koyeb deploy flows + GHCR CI/CD + Cloudflare/caddy/nginx presets
- v3: Swarm orchestrators (Flow‑Nexus/Claude‑Flow) + ArchGW edge policies + eval loops
- v4: memOS graft; GraphRAG pipelines; Codanna indexing; autoscaling
