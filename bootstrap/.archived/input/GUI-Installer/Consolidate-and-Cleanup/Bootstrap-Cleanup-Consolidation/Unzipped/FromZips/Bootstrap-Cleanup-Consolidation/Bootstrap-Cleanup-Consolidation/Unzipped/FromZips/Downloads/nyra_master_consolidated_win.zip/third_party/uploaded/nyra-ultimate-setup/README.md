# Nyra Ultimate Setup Kit

This kit includes:
- **secrets_infisical_init.ps1** — write multiple secrets to Infisical (`-Pairs key=value ...`) and optionally set User env.
- **secrets_bitwarden_mirror.ps1** — mirror secrets (pairs) into Bitwarden Secure Notes.
- **secrets_sync_infisical_to_bw.ps1** — pull keys from Infisical env -> Bitwarden Secure Notes.
- **Fix-PSModulePath.ps1** — repair your User PSModulePath.
- **fixpath.ps1** — normalize PATH (User; optional Machine with `-UpdateMachine`).
- **.mcp.json** — MCP clients/servers template with Desktop Commander + Flow Nexus, etc.
- **SourceGit/GitExtensions/RepoZ .reg** — add right‑click context menu entries.
- **gitomatic_schedule.ps1** — create a Scheduled Task to run `gitomatic` at logon.

## 0) Open a clean PowerShell (no profile)
Press `Win+R` then run:
```
pwsh -NoProfile
```

## 1) Infisical + Bitwarden
Login:
```
infisical login
bw login
$env:BW_SESSION = bw unlock --raw
```

Write secrets to Infisical and set User env (example):
```
.\secrets_infisical_init.ps1 -Env dev -Pairs `
  FLOW_NEXUS_TOKEN=xxxxx `
  FLOW_NEXUS_URL=https://api.flow-nexus.io `
  NOTION_TOKEN=ntn_xxx `
  -SetUserEnv
```

Mirror secrets into Bitwarden (as Secure Notes):
```
.\secrets_bitwarden_mirror.ps1 -Pairs `
  FLOW_NEXUS_TOKEN=$env:FLOW_NEXUS_TOKEN `
  FLOW_NEXUS_URL=$env:FLOW_NEXUS_URL `
  NOTION_TOKEN=$env:NOTION_TOKEN
```

Sync from Infisical env -> Bitwarden (pulls values on demand):
```
.\secrets_sync_infisical_to_bw.ps1 -Env prod -Keys FLOW_NEXUS_TOKEN FLOW_NEXUS_URL NOTION_TOKEN
```

## 2) Fix module path / PATH
```
.\Fix-PSModulePath.ps1          # user-scope PSModulePath
.ixpath.ps1                   # user PATH
.ixpath.ps1 -UpdateMachine    # system PATH (run elevated)
```

## 3) MCP config
Copy `.mcp.json` into the repo root you open in Claude Code.
Set NOTION_TOKEN in your environment (or Infisical).

## 4) Context menus
Double‑click the `.reg` files to add Explorer right‑click entries. Adjust EXE paths if your apps live elsewhere.

## 5) Gitomatic
Install gitomatic, then schedule:
```
.\gitomatic_schedule.ps1 -RepoPath "C:\path\to\repo" -Interval "15m"
```

## Notes
- Bitwarden templates & create/edit flows follow CLI docs: use `bw get template item`, then `bw create item`/`bw edit item`.
- PSReadLine predictions require a recent PSReadLine (2.1+); set with:
  `Set-PSReadLineOption -PredictionSource HistoryAndPlugin -PredictionViewStyle ListView`
