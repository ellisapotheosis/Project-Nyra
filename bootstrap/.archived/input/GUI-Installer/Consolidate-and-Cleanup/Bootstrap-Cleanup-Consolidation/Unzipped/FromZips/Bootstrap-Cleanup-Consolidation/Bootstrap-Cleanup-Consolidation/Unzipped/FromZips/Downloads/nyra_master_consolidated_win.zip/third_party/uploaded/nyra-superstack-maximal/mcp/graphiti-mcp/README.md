# graphiti-mcp MCP

Stub docs: configure credentials & endpoints for `graphiti-mcp` server.
