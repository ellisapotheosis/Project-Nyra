import os, json
from pathlib import Path

INPUT_DIR = Path("notion")
OUTPUT_DIR = Path("memory/cleaned")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def clean_and_chunk(text, max_chunk=1600):
    chunks = [text[i:i+max_chunk] for i in range(0, len(text), max_chunk)]
    return [{"chunk": i+1, "text": c.strip()} for i, c in enumerate(chunks) if c.strip()]

def process_file(fp: Path):
    raw = fp.read_text(encoding="utf-8", errors="ignore")
    chunks = clean_and_chunk(raw)
    out = OUTPUT_DIR / f"{fp.stem}.jsonl"
    with out.open("w", encoding="utf-8") as f:
        for ch in chunks:
            f.write(json.dumps(ch) + "\n")
    print(f"Saved: {out} ({len(chunks)} chunks)")

def main():
    for ext in ("*.md", "*.txt"):
        for fp in INPUT_DIR.glob(ext):
            process_file(fp)

if __name__ == "__main__":
    main()
