from fastapi import FastAPI, Depends, Header, HTTPException
from pydantic import BaseModel
import os

API_KEY = os.getenv("NYRA_API_KEY", os.getenv("LITELLM_MASTER_KEY","dev-key"))
app = FastAPI(title="Nyra Core (Secure)")

def require_key(x_nyra_key: str | None = Header(default=None)):
    if not API_KEY:
        return True
    if x_nyra_key != API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return True

class Prompt(BaseModel):
    text: str
    model: str | None = None

@app.get("/health")
async def health():
    return {"ok": True}

@app.post("/echo", dependencies=[Depends(require_key)])
async def echo(p: Prompt):
    return {"echo": p.text, "model": p.model}
