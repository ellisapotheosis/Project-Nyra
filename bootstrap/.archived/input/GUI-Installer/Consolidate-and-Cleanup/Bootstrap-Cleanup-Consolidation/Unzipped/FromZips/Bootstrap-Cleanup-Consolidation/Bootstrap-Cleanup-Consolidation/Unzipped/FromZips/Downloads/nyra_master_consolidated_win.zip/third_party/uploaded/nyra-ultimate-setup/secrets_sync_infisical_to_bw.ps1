param(
  [Parameter(Mandatory)][ValidateSet('dev','staging','prod')][string]$Env,
  [Parameter(Mandatory)][string[]]$Keys
)
$ErrorActionPreference = 'Stop'

if (-not (Get-Command infisical -ErrorAction SilentlyContinue)) { throw "Infisical CLI not found." }
if (-not (Get-Command bw -ErrorAction SilentlyContinue)) { throw "Bitwarden CLI (bw) not found." }

# Ensure BW session
if (-not $env:BW_SESSION) {
  Write-Host "Bitwarden session missing. Prompting unlock..." -ForegroundColor Yellow
  $env:BW_SESSION = & bw unlock --raw
}

function Upsert-BWSecureNote {
  param([string]$Name, [string]$Notes)
  $tmpl = bw get template item | ConvertFrom-Json
  $tmpl.type = 2
  $tmpl.name = $Name
  $tmpl.notes = $Notes
  $json = $tmpl | ConvertTo-Json -Depth 6 | bw encode

  $existing = bw list items --search $Name | ConvertFrom-Json | Where-Object { $_.name -eq $Name } | Select-Object -First 1
  if ($existing) {
    bw edit item $existing.id $json | Out-Null
    Write-Host "✓ Updated Bitwarden note: $Name"
  } else {
    bw create item $json | Out-Null
    Write-Host "✓ Created Bitwarden note: $Name"
  }
}

foreach ($k in $Keys) {
  $val = (& infisical secrets get $k --env=$Env --plain)
  if ($LASTEXITCODE -ne 0 -or -not $val) {
    Write-Host "⚠ Skipping $k (not found in Infisical $Env)" -ForegroundColor Yellow
    continue
  }
  Upsert-BWSecureNote -Name $k -Notes $val
}
Write-Host "✓ Sync complete from Infisical:$Env -> Bitwarden secure notes."
