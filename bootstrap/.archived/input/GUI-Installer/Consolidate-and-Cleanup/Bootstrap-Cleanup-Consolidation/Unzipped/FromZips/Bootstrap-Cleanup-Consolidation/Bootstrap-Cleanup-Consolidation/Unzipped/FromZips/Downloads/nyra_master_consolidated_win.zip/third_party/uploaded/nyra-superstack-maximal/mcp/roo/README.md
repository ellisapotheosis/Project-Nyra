# roo MCP

Stub docs: configure credentials & endpoints for `roo` server.
