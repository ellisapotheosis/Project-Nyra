#!/usr/bin/env bash
set -euo pipefail
: "${MEILI_HOST:?Set MEILI_HOST, e.g. http://localhost:7700}"
: "${MEILI_API_KEY:?Set MEILI_API_KEY}"
INDEX_NAME="${1:-history}"
curl -sS -X POST "$MEILI_HOST/indexes/$INDEX_NAME/settings"   -H "Authorization: Bearer $MEILI_API_KEY"   -H "Content-Type: application/json"   --data-binary @"$(dirname "$0")/index_settings.json"
echo
