import httpx
import os

OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")

async def query_ollama(prompt: str, model: str = "llama2"):
    """Send a prompt to a local Ollama model."""
    async with httpx.AsyncClient() as client:
        payload = {"model": model, "prompt": prompt}
        res = await client.post(f"{OLLAMA_BASE_URL}/api/generate", json=payload)
        return res.json()

if __name__ == "__main__":
    import asyncio
    out = asyncio.run(query_ollama("Hello, world from NYRA!"))
    print(out)