from langgraph.graph import Graph

def build_agent_graph():
    g = Graph()
    # Example placeholder nodes
    g.add_node("input")
    g.add_node("ollama")
    g.add_node("openai")
    g.add_node("anthropic")
    g.add_edge("input", "ollama")
    g.add_edge("input", "openai")
    g.add_edge("input", "anthropic")
    return g

if __name__ == "__main__":
    graph = build_agent_graph()
    print("LangGraph nodes:", graph.nodes)