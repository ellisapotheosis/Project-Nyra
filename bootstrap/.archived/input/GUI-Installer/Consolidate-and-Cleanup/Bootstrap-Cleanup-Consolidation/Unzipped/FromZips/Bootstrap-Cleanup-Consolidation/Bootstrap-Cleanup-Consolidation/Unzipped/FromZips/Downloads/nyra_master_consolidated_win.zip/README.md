# NYRA Master Consolidated (Windows Edition)

**Built:** 2025-10-13 06:01 UTC

This is your **master mono-repo**: orchestrators (Claude-Flow ⇄ Archon ⇄ ArchGW ⇄ LangGraph ⇄ AG2 ⇄ PraisonAI), UIs (Open WebUI, LobeChat, Dify, Flowise, n8n), MCP channels (MCPO + Claude Desktop + VS Code), memory mesh (Qdrant, Neo4j/Graphiti, Mem0), and **all uploaded bundles extracted under** `third_party/uploaded/`.

Start here:
- `SETUP_GUIDE_WINDOWS.md` — step-by-step
- `INSTALL_AGENT_PROMPT.md` — drop into Claude-Flow/Claude-Code to auto-wire
- `CONSOLIDATION_REPORT.md` — list of imported zip files & status
- `diagrams/architecture.md` — mermaid maps

## Repo Layout
```
apps/                 # UIs & web apps (Open WebUI pipelines, etc.)
config/               # .env example, MCPO, channels, policies
infra/                # docker-compose.*.yml
mcp/
  channels/           # channel bundles (dev, memory, research, secrets, ops, scaffold, inception)
orchestration/
  a2a/                # minimal A2A host shim
  archon/             # archon-facing configs/hooks
  langgraph/          # graph app skeletons
  ag2/                # AG2 runtime stubs
  praisonai/          # praison config stubs
services/
  agents/             # DeepCode, SWE-Agent, RepoAgent, PocketFlow, Codanna (stubs)
  runners/            # OpenHands (stubs)
third_party/
  uploaded/           # all your uploaded zips extracted (immutable source of truth)
scripts/              # PowerShell helpers (bootstrap/up/down/install/start-mcpo)
diagrams/             # mermaid
```

**Rule of thumb:** treat `third_party/uploaded/*` as **read-only source material**; copy only what you need into `services/` or `apps/`, and let Claude-Flow clean/refactor.
