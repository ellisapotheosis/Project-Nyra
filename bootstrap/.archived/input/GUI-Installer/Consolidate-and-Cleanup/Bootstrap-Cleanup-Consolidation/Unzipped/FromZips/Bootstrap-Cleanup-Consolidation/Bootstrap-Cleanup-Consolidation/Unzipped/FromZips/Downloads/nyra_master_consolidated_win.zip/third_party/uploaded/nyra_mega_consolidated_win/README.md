# NYRA Mega Consolidated (Windows Edition)

This Windows bundle provides PowerShell scripts to boot the full stack with Docker Desktop + Compose v2.
See `WINDOWS_SETUP.md` for a step-by-step guide.
