# archon MCP

Stub docs: configure credentials & endpoints for `archon` server.
