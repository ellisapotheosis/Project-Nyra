# MCP Usage Notes

- AutoGen integration: `pip install -U "autogen-ext[mcp]"`.
- Prefer **SSE/HTTP** MCP servers for isolation; use **STDIO** only for trusted local tools.
- Candidate servers:
  - Archon (coding command center) — connect via SSE URL from its docs.
  - Agent Zero (can act as MCP server and client).
- If you front multiple MCP servers, consider an MCP gateway to unify auth and routing.

Security: assume tools can write to disk or run code; require human approval for risky operations.
