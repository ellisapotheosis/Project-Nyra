#!/usr/bin/env bash
set -euo pipefail
# Restore LibreChat MongoDB from an archive
: "${ARCHIVE:?ARCHIVE not set, pass like ARCHIVE=backups/mongo/xyz.archive.gz}"
docker exec -i mongodb mongorestore --archive --gzip --drop < "$ARCHIVE"
echo "[mongo] restore completed"
