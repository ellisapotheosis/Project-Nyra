param()
$ErrorActionPreference='Stop'
docker compose -f .\infra\docker-compose.core.yml down
docker compose -f .\infra\docker-compose.orchestrators.yml down
docker compose -f .\infra\docker-compose.observability.yml down
