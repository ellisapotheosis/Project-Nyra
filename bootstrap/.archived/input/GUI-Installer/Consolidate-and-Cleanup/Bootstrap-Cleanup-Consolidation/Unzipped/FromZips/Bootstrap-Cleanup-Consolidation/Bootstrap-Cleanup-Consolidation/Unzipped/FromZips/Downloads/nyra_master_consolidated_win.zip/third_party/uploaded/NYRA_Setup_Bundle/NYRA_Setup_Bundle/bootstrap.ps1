\
    Write-Host "🌌 [NYRA BOOTSTRAP] Preparing AgentZero & Claude Desktop..."

    if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
      Write-Host "❌ Python not found. Please install Python 3.11+ and re-run." -ForegroundColor Red
      exit 1
    }

    python -m venv venv
    .\venv\Scripts\Activate.ps1

    Write-Host "📦 Installing requirements..."
    pip install --upgrade pip
    pip install -r requirements.txt

    Write-Host "🔗 Starting AgentZero Orchestrator..."
    python launch_orchestrator.py --agent configs/agentzero_config.json
