See README for priority rules. Promote any service by copying from deprecated/ or _collected/ into top-level compose.
