
param([switch]$MinimalOnly, [switch]$AllUsersStub)
$ErrorActionPreference = 'Stop'
$nyraRoot = Join-Path $env:USERPROFILE ".config\nyra"
$pwshDir  = Join-Path $nyraRoot "pwsh"
$ompDir   = Join-Path $nyraRoot "omp"
$secDir   = Join-Path $nyraRoot "secrets"
New-Item -ItemType Directory -Force -Path $nyraRoot,$pwshDir,$ompDir,$secDir | Out-Null
Copy-Item -Force "$PSScriptRoot\..\pwsh\Nyra.Profile.Central.ps1" $pwshDir
Copy-Item -Force "$PSScriptRoot\..\omp\nyra-neon.omp.yaml" $ompDir
Copy-Item -Force "$PSScriptRoot\..\omp\nyra-minimal.omp.yaml" $ompDir
$secretsEx = "$PSScriptRoot\..\secrets\nyra.secrets.example.ps1"
if (-not (Test-Path (Join-Path $secDir "nyra.secrets.ps1"))) {
  Copy-Item -Force $secretsEx (Join-Path $secDir "nyra.secrets.example.ps1")
}
$starDst = Join-Path $env:USERPROFILE ".config\starship.toml"
if (-not $MinimalOnly) {
  New-Item -ItemType Directory -Force -Path (Split-Path $starDst) | Out-Null
  if (-not (Test-Path $starDst)) { Copy-Item -Force "$PSScriptRoot\..\starship\starship.toml" $starDst }
}
$elvishDst = Join-Path $env:APPDATA "elvish\rc.elv"
New-Item -ItemType Directory -Force -Path (Split-Path $elvishDst) | Out-Null
Copy-Item -Force "$PSScriptRoot\..\elvish\rc.elv" $elvishDst
$bashDst = Join-Path $env:USERPROFILE ".bashrc"
if (-not (Test-Path $bashDst)) { Copy-Item -Force "$PSScriptRoot\..\bash\.bashrc" $bashDst }
$fragUser = Join-Path $env:LOCALAPPDATA "Microsoft\Windows Terminal\Fragments\Nyra"
New-Item -ItemType Directory -Force -Path $fragUser | Out-Null
Copy-Item -Force "$PSScriptRoot\..\windows-terminal\Fragments\Nyra\nyra.json" $fragUser
try {
  $warpLC = Join-Path $env:USERPROFILE ".warp\launch_configurations"
  New-Item -ItemType Directory -Force -Path $warpLC | Out-Null
  Copy-Item -Force "$PSScriptRoot\..\warp\launch_configurations\Nyra-PowerShell.yaml" $warpLC
} catch { Write-Warning "Warp not detected. Add later to %USERPROFILE%\.warp\launch_configurations" }
$cuAllHosts = Join-Path $HOME "Documents\PowerShell\profile.ps1"
$cuCurHost  = Join-Path $HOME "Documents\PowerShell\Microsoft.PowerShell_profile.ps1"
$stub = @'
$central = Join-Path $env:USERPROFILE '.config\nyra\pwsh\Nyra.Profile.Central.ps1'
if (Test-Path $central) { . $central }
'@
New-Item -ItemType Directory -Force -Path (Split-Path $cuAllHosts) | Out-Null
$stub | Out-File -Encoding utf8 -Force $cuAllHosts
$stub | Out-File -Encoding utf8 -Force $cuCurHost
if ($AllUsersStub) {
  try {
    $target = Join-Path $PSHOME "profile.ps1"
    Copy-Item $target "$target.bak" -Force -ErrorAction SilentlyContinue
    '. "$HOME\.config\nyra\pwsh\Nyra.Profile.Central.ps1"' | Out-File -Encoding utf8 -Force $target
    Write-Host "AllUsersAllHosts stub written to $target" -ForegroundColor Green
  } catch {
    Write-Warning "Couldn't write AllUsersAllHosts. Run setup\Set-AllUsersStub.ps1 AS ADMIN later."
  }
}
[Environment]::SetEnvironmentVariable('NYRA_OMP_CONFIG', (Join-Path $ompDir 'nyra-neon.omp.yaml'), 'User')
if (Get-Command starship -ErrorAction SilentlyContinue) {
  [Environment]::SetEnvironmentVariable('STARSHIP_CONFIG', $starDst, 'User')
}
Write-Host "Nyra OnePack v5 setup complete." -ForegroundColor Green
Write-Host "Restart Windows Terminal for profiles to appear." -ForegroundColor Yellow
