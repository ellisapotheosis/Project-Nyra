#!/bin/bash
# Start NYRA local stack (Linux/macOS)

# Start local Ollama server (background)
ollama serve &

# Optional: Start AnythingLLM or LM Studio here

# Start FastAPI backend
uvicorn app:app --host 0.0.0.0 --port 7860 &

# Run Cloudflare tunnel
cloudflared tunnel run gpu-agent &

wait