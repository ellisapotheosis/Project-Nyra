param()
$ErrorActionPreference = 'Stop'
if (-not (Test-Path ".\.env")) {
  Copy-Item .\config\.env.example .\.env -Force
  Write-Host "Created .env from example."
}
$dirs = @(
  ".\.data\open-webui",".\.data\qdrant",".\.data\neo4j",
  ".\.data\langfuse",".\.data\metamcp",".\.data\archon",".\.data\archgw"
)
foreach ($d in $dirs) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
Write-Host "Bootstrap complete."
