UIs:
- **Open WebUI** (+MCPO for MCP→OpenAPI)
- **LobeChat** for marketplace/agent GUI
- Minimal dashboard below
