Docker Compose uses **profiles**: base/ui/rag/obs/mcp. Bring up subsets with `make` targets.
