# NYRA Orchestrator v1.4 — Forge PRs + Bind Letta
_Last updated: 2025-09-19_

Adds:
- **Forge PRs**: OpenHands → create patch, git branch, commit, push, **open GitHub PR**.
- **Edge extraction**: build GraphRAG edges from plan/artifacts (uses simple heuristics).
- **Letta persona hooks**: local persona JSON + optional Letta API stub to persist episodic/semantic memory.
- **End-to-end demo**: `scripts/forge_pr.py` + `scripts/run_full_demo.sh`.

Set in `.env`:
- `GITHUB_TOKEN` (repo scope), `GITHUB_REPO` (e.g. `ellisapotheosis/Project-Nyra`), `GITHUB_DEFAULT_BRANCH` (`main` or `master`).
- `OPENAI_API_KEY` (optional, for embeddings); Qdrant/Zep URLs as before.
