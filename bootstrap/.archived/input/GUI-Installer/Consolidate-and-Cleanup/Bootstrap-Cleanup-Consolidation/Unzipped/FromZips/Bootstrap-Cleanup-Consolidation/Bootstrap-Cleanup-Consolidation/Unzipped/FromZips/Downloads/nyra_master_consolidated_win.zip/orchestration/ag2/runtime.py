print('AG2 runtime placeholder')
