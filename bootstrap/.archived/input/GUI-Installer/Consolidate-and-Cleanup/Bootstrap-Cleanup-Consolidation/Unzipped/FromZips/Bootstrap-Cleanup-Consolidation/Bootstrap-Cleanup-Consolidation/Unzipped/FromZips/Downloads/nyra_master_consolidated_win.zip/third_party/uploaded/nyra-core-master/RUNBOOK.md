# NYRA Runbook

## Starting Locally
```bash
ollama serve &
cloudflared tunnel run gpu-agent &
uvicorn app:app --reload --host 0.0.0.0 --port 7860
```

## Deploying to Koyeb
- Push to main branch → GitHub Actions triggers deploy
- Ensure secrets set in GitHub repo: OPENAI_API_KEY, ANTHROPIC_API_KEY, KOYEB_API_KEY
- Koyeb auto-builds with Procfile

## Verifying GPU Tunnel
Check `https://gpu.ratehunter.net/wake`

## Extending
- Add agents to `agents/`
- Add orchestrators to `orchestrator/`
- Add memory flows in `langgraph_mesh.py`
