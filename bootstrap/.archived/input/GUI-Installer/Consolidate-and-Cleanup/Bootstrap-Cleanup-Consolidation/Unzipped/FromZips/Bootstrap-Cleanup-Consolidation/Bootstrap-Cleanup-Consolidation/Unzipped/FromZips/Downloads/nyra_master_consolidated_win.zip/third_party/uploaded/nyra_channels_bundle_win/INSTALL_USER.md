# Step-by-step (Windows)

1. **Install prerequisites**
   - **Docker Desktop** (for Qdrant / Neo4j containers) – optional but recommended
   - **Python 3.11+**
   - **uv** (`pipx install uv`) or via `scripts/start-mcpo.ps1` which auto-installs

2. **Export environment variables**
   - Copy `scripts/env.template.ps1` to `env.ps1`, edit values, then:
     ```powershell
     Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
     . .\scripts\env.ps1
     ```

3. **Install config files**
   ```powershell
   .\scripts\install-mcp-config.ps1 -Target all
   # Writes:
   #   %APPDATA%\Claude\claude_desktop_config.json
   #   %USERPROFILE%\.vscode\mcp.json
   #   config\mcpo\config.json
   ```

4. **Start dependencies (optional)**
   - Qdrant:
     ```powershell
     docker run -d --name qdrant -p 6333:6333 -v qdrant:/qdrant/storage qdrant/qdrant
     ```
   - Neo4j:
     ```powershell
     docker run -d --name neo4j -p 7474:7474 -p 7687:7687 `
       -e NEO4J_AUTH=neo4j/password neo4j:5.26
     ```

5. **Launch MCPO** (for Open WebUI tool servers)
   ```powershell
   .\scripts\start-mcpo.ps1 -Port 8000 -ApiKey "top-secret"
   ```
   - In **Open WebUI** → Settings → Tools → **Add** tool servers:
     - `http://localhost:8000/time`
     - `http://localhost:8000/fetch`
     - `http://localhost:8000/browser-use`
     - `http://localhost:8000/qdrant`
     - `http://localhost:8000/graphiti`
     - `http://localhost:8000/context7`
     - …each MCPO-mounted tool has its own `/docs` page.

6. **Restart clients**
   - Quit & reopen **Claude Desktop** (loads `%APPDATA%\Claude\claude_desktop_config.json`)
   - In **VS Code** run **“MCP: Open User Configuration”** to verify `mcp.json` is loaded.

7. **Sanity checks**
   - In Claude Desktop compose: “Use tool `time` to show the current local time.”
   - In Open WebUI, click the tool icon and invoke a MCPO tool (e.g. `time`).

> Tip: Keep MCPO running with `--hot-reload` and tweak `config\mcpo\config.json` freely.
