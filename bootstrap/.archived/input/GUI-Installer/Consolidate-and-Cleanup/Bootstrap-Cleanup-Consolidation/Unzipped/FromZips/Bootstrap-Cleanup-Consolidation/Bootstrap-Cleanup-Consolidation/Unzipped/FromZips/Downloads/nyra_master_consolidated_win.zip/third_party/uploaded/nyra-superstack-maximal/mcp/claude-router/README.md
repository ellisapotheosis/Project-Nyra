# claude-router MCP

Stub docs: configure credentials & endpoints for `claude-router` server.
