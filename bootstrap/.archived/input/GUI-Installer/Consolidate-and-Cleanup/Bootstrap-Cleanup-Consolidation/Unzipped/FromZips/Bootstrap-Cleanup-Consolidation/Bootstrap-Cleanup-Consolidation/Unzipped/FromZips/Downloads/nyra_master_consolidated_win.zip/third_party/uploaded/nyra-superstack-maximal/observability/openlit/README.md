Add OpenLIT to your Python apps for OTEL exports: https://github.com/openlit/openlit
