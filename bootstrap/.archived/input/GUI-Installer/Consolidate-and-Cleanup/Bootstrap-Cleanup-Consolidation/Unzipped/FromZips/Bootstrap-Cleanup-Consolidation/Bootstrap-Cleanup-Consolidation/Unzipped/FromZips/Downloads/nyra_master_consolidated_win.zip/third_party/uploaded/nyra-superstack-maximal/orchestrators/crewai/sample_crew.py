from crewai import Agent, Task, Crew

def run():
    researcher = Agent(role="Researcher", goal="find useful links", backstory="web scout")
    writer = Agent(role="Writer", goal="summarize", backstory="sharp quill")
    t1 = Task(description="Find 3 credible sources on LangGraph", agent=researcher)
    t2 = Task(description="Summarize the sources", agent=writer, context=[t1])
    return Crew(agents=[researcher, writer], tasks=[t1, t2]).kickoff()
