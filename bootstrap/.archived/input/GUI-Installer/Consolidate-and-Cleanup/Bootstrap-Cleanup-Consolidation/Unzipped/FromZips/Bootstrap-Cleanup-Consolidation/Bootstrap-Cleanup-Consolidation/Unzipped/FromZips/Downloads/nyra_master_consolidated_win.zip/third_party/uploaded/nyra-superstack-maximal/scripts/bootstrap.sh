#!/usr/bin/env bash
set -euo pipefail
cp -n .env.example .env || true
echo "Bootstrapped .env. Next: make base ui rag obs"
