# Infra
Use docker compose profiles.
