# ADR (Highlights)

- **ADR‑001**: Multi‑orchestrator core (AG2 + LangGraph + CrewAI + PraisonAI + AgentZero)
- **ADR‑002**: Memory split (Letta for episodic/stateful; Zep for context assembly; memOS later)
- **ADR‑003**: RAG split (Qdrant vector + Graphiti/FalkorDB graph)
- **ADR‑004**: Observability via OTEL → Prometheus/Loki → Grafana
- **ADR‑005**: MCP mesh (MetaMCP channels; MCPO to expose to UIs)
