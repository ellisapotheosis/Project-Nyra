# filesystem MCP

Stub docs: configure credentials & endpoints for `filesystem` server.
