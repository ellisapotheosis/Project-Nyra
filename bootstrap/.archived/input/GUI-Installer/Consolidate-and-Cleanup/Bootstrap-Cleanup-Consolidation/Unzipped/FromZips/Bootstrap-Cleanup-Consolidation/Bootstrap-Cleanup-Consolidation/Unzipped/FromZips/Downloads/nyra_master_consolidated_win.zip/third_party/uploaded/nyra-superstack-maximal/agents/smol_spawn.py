def run_smol(task:str):
    return f"[smol] executed: {task}"
