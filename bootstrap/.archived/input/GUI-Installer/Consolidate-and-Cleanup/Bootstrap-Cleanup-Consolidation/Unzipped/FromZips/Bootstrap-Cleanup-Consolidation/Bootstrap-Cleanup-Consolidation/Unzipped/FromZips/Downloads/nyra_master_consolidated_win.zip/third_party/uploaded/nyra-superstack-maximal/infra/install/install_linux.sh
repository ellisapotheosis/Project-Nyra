#!/usr/bin/env bash
set -e
sudo apt update
sudo apt install -y python3.11 python3.11-venv python3-pip curl
pip3 install --upgrade pip
pip3 install fastapi uvicorn litellm
echo "Install cloudflared via Cloudflare docs."
