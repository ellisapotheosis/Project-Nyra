# Apotheosis MEGA Stack
Date: 2025-08-20T07:05:30.474484Z

## Structure
- all_in_one/  → Docker Compose bringing up LibreChat + Open WebUI + LiteLLM + Langfuse (web+worker+PG+CH+Redis) + Meilisearch + Ollama
- powerups/    → Meili ranking settings + Langfuse S3 backup job + Mongo/Meili local backups + Notion CSV + Open WebUI prompt pack
- promptfoo/   → Prompt evaluation harness using LiteLLM's OpenAI-compatible endpoint

## First Run (TL;DR)
cd all_in_one
cp .env.example .env && docker compose --env-file ./.env up -d
docker exec -it $(docker ps -qf name=ollama) ollama pull llama3.1:8b
docker exec -it $(docker ps -qf name=ollama) ollama pull qwen2.5:7b
docker exec -it $(docker ps -qf name=ollama) ollama pull deepseek-r1:8b

## Tune Search (optional)
cd ../powerups
export MEILI_HOST=http://localhost:7700
export MEILI_API_KEY=REPLACE_ME
./meili/apply_settings.sh history

## Backups (Langfuse → S3)
export PGHOST=localhost PGUSER=langfuse PGDATABASE=langfuse PGPASSWORD=changeme
export CLICKHOUSE_URL=http://localhost:8123 CLICKHOUSE_USER=default CLICKHOUSE_PASSWORD=changeme
export S3_URL=https://s3.amazonaws.com/YOUR_BUCKET/langfuse/$(date +%F)
export AWS_ACCESS_KEY_ID=AKIA... AWS_SECRET_ACCESS_KEY=...
./langfuse/backup_to_s3.sh
