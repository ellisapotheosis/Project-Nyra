import subprocess, shlex, tempfile, os
def run_openhands(command: str, workdir: str='.'):
    cmd = f"openhands {command}"
    proc = subprocess.run(shlex.split(cmd), cwd=workdir, capture_output=True, text=True)
    return {"ok": proc.returncode==0, "stdout": proc.stdout, "stderr": proc.stderr}

def generate_patch(task: str, workdir: str='.'):
    # Example: run openhands to scaffold or refactor, then git diff
    _ = run_openhands(f'--task "{task}"', workdir=workdir)
    proc = subprocess.run(["git","diff"], cwd=workdir, capture_output=True, text=True)
    return proc.stdout
