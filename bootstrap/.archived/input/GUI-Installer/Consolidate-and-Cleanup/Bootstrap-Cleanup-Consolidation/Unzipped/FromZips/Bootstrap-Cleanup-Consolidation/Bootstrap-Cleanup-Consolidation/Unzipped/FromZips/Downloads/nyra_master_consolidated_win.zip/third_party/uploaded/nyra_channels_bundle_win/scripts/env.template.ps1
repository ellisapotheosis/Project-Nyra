# Copy to env.ps1 and fill in real values; then 'Set-ExecutionPolicy -Scope CurrentUser RemoteSigned'
# and run:  . .\env.ps1  (dot-source to load into current session)
$env:NYRA_DEV_ROOTS = "C:\Dev;D:\Repos"
$env:NYRA_REPO_ROOT = "C:\Dev\nyra"

# Timezone for mcp-server-time
$env:NYRA_TIMEZONE = "America/Los_Angeles"

# GitHub
$env:GITHUB_TOKEN = "ghp_xxx"

# Qdrant vector store
$env:QDRANT_URL = "http://localhost:6333"
$env:QDRANT_COLLECTION = "nyra-memory"

# Graphiti (Neo4j-backed)
$env:GRAPHITI_MCP_DIR = "C:\Dev\graphiti\mcp_server"
$env:OPENAI_API_KEY = "sk-..."  # or GATEWAY key via ArchGW
$env:NEO4J_URI = "bolt://localhost:7687"
$env:NEO4J_USER = "neo4j"
$env:NEO4J_PASSWORD = "password"

# Mem0 (optional)
$env:MEM0_API_KEY = ""

# Context7 (optional)
$env:CONTEXT7_API_KEY = ""

# Bitwarden (optional)
$env:BW_SESSION = ""
$env:BW_CLIENT_ID = ""
$env:BW_CLIENT_SECRET = ""

# Infisical (optional)
$env:INFISICAL_UNIVERSAL_AUTH_CLIENT_ID = ""
$env:INFISICAL_UNIVERSAL_AUTH_CLIENT_SECRET = ""
$env:INFISICAL_HOST_URL = "https://app.infisical.com"
