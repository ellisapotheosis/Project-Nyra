from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
import os

API_KEY = os.getenv("LITELLM_MASTER_KEY", "dev-key")
app = FastAPI(title="Nyra Core", version="0.1.0")

class ChatRequest(BaseModel):
    model: str
    messages: list

@app.get("/healthz")
def healthz():
    return {"ok": True}

@app.post("/chat")
def chat(req: ChatRequest, x_api_key: str | None = Header(None)):
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="invalid api key")
    return {"model": req.model, "choices": [{"message": {"role": "assistant", "content": "hello from nyra core"}}]}
