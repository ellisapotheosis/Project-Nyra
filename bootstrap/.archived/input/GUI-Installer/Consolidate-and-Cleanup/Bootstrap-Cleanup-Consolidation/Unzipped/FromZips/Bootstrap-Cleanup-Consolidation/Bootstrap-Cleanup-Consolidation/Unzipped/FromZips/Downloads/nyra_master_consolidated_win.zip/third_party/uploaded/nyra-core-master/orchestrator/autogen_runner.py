from autogen import AssistantAgent, UserProxyAgent

# Simple AutoGen runner for testing agent interactions

def run_autogen(prompt: str):
    user = UserProxyAgent("user")
    assistant = AssistantAgent("assistant", llm="gpt-4")

    user.initiate_chat(assistant, message=prompt)


if __name__ == "__main__":
    run_autogen("Summarize the benefits of hybrid cloud + local GPU orchestration.")