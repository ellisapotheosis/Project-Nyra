TensorZero gateway/evals (optional): https://github.com/tensorzero/tensorzero
