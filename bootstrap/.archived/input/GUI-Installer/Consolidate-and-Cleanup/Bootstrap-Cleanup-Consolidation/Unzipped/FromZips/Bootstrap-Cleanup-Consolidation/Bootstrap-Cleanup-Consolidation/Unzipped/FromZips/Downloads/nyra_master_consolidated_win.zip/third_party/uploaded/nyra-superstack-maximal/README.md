# Nyra Superstack — MAXIMAL EDITION (2025-09-19)

A **monorepo** for multi-orchestrator, multi-memory, multi-MCP, multi-UI agent ops.
Start in `docs/MASTER_GUIDE.md`. Use `Makefile` for docker profiles: `make base ui rag obs`.
