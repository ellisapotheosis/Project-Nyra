import csv, os, time, json
from .edge_extractor import infer_edges

def export_graphrag(state, outdir='runs/graphrag'):
    os.makedirs(outdir, exist_ok=True)
    ts = int(time.time())
    nodes_path = os.path.join(outdir, f"nodes_{ts}.csv")
    edges_path = os.path.join(outdir, f"edges_{ts}.csv")
    with open(nodes_path, 'w', newline='', encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['id','type','title','summary','text','tags','source'])
        # plan node (if any)
        for j, d in enumerate([x for x in state.decisions if x.lower().startswith("plan:")]):
            w.writerow([f"plan_0", 'plan', 'plan', d, d, '#NYRA|#Plan', 'orchestrator'])
        # artifact nodes
        for i,a in enumerate(state.artifacts):
            w.writerow([f"artifact_{i}", 'artifact', a.get('type'), a.get('by',''), a.get('content',''), '#NYRA|#Artifact', 'orchestrator'])
    with open(edges_path, 'w', newline='', encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['src_id','dst_id','rel_type','weight','evidence_ids'])
        for e in infer_edges(state):
            w.writerow([e["src"], e["dst"], e["type"], e["weight"], "|".join(e["evidence"])])
    # Graphiti JSON
    json_nodes=[]
    for j, d in enumerate([x for x in state.decisions if x.lower().startswith("plan:")]):
        json_nodes.append({"id":"plan_0","labels":["Plan"],"properties":{"text":d}})
    for i,a in enumerate(state.artifacts):
        json_nodes.append({"id":f"artifact_{i}","labels":["Entity","Artifact"],"properties":{"type":a.get("type"),"by":a.get("by",""),"text":a.get("content","")}})
    json_edges=[{"src":e["src"],"dst":e["dst"],"type":e["type"],"properties":{"weight":e["weight"]}} for e in infer_edges(state)]
    json.dump({"nodes":json_nodes,"edges":json_edges}, open(os.path.join(outdir,f"graphiti_{ts}.json"),"w",encoding="utf-8"), ensure_ascii=False, indent=2)
    return nodes_path, edges_path
