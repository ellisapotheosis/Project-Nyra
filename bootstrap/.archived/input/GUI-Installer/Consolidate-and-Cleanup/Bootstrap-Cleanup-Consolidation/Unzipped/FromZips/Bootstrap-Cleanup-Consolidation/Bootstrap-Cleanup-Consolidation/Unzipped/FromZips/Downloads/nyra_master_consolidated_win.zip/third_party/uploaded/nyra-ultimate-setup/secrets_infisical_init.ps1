param(
  [Parameter(Mandatory)][ValidateSet('dev','staging','prod')][string]$Env,
  [Parameter()][string[]]$Pairs,
  [switch]$SetUserEnv
)
$ErrorActionPreference = 'Stop'

if (-not (Get-Command infisical -ErrorAction SilentlyContinue)) {
  throw "Infisical CLI not found in PATH."
}

if (-not $Pairs -or $Pairs.Count -eq 0) {
  throw "Provide -Pairs like: -Pairs KEY1=VALUE1 KEY2=VALUE2"
}

# Validate & build one-shot 'secrets set' command
$bad = @()
$kvlist = @()
foreach ($p in $Pairs) {
  if ($p -notmatch '^[^=]+=.+' ) { $bad += $p; continue }
  $kvlist += $p
}
if ($bad.Count) {
  throw "Malformed pairs: $($bad -join ', ')"
}

# Write to Infisical (single call)
& infisical secrets set --env=$Env @kvlist | Out-Host

if ($SetUserEnv) {
  foreach ($p in $kvlist) {
    $k,$v = $p.Split('=',2)
    [Environment]::SetEnvironmentVariable($k, $v, 'User')
    Write-Host "✓ Set User env $k"
  }
  Write-Host "Restart your terminal to pick up new env vars."
}
