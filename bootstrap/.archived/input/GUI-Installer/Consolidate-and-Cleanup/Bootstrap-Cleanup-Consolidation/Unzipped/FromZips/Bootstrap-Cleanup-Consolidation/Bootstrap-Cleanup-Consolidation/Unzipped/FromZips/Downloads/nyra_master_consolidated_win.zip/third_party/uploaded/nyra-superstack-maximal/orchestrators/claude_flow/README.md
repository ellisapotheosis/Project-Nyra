Claude‑Flow / Flow‑Nexus provides MCP tool swarms and orchestration flows. Connect via Claude Code or MCPO to surface tools to UIs.
