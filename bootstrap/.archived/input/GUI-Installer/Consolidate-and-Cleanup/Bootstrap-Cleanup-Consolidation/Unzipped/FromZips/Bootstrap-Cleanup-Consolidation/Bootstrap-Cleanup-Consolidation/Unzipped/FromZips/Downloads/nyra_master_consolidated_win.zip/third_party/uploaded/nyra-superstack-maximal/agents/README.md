# Agents

- **OpenHands** for setup/scaffolding/devops
- **HKUD/DeepCode** (placeholder) — external coding assistant
- **Spawnables**: SmolAgents / PocketFlow micro-agents
- **Clients** for local/hosted LLMs
- **Codanna** indexing (MCP)
