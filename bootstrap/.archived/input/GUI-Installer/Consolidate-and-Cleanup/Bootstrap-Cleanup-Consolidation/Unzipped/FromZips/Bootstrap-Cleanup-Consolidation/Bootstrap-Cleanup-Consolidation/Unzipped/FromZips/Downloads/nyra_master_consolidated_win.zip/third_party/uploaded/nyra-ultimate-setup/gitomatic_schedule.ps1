param(
  [Parameter(Mandatory)][string]$RepoPath,
  [string]$Interval = '10m',
  [string]$Author = $env:USERNAME,
  [string]$Email = "$($env:USERNAME)@local"
)
$ErrorActionPreference='Stop'

if (-not (Get-Command gitomatic -ErrorAction SilentlyContinue)) {
  throw "gitomatic not found in PATH. Install from https://github.com/muesli/gitomatic/releases"
}
$action = New-ScheduledTaskAction -Execute 'gitomatic.exe' -Argument "-interval $Interval -author `"$Author`" -email `"$Email`" `"$RepoPath`""
$trigger = New-ScheduledTaskTrigger -AtLogOn
Register-ScheduledTask -TaskName "gitomatic-$($Author)" -Action $action -Trigger $trigger -Description "Auto pull/push $RepoPath" -Force
Write-Host "✓ Registered scheduled task 'gitomatic-$Author'"
