# ruv-swarm MCP

Stub docs: configure credentials & endpoints for `ruv-swarm` server.
