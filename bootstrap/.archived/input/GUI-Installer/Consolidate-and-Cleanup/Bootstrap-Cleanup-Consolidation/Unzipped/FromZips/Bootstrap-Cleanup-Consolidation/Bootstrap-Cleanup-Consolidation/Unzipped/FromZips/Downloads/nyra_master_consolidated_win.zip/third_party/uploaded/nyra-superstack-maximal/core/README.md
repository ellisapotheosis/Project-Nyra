# Core API

- `/healthz` basic health
- `/chat` OpenAI-style proxy (secured via `X-API-Key` = `LITELLM_MASTER_KEY`)
- `app_secure.py` adds header auth `x-nyra-key` for private endpoints
