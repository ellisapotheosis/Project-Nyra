# Backups & Restore

## Meilisearch
- API snapshot route `/snapshots` creates quick backups. Use `scripts/backup_meili.sh` or Meilisearch docs for cron/snapshots. 
- To migrate versions, prefer **dumps** over snapshots.

## MongoDB (LibreChat)
- Use `scripts/backup_mongo.sh` to create a gzipped archive.
- Restore: `scripts/restore_mongo.sh`.

## Cron
See `scripts/cron.examples.txt` for nightly backup examples.
