from pydantic import BaseModel, Field
from typing import Any, Dict, List
from nyra_orchestrator.agents.memory_steward import fetch_context, memory_update
from nyra_orchestrator.agents.planner_praison import plan_with_praison
from nyra_orchestrator.agents.agentzero_tools import propose_tools
from nyra_orchestrator.agents.scaffolder_openhands import openhands_scaffold, openhands_debug
from nyra_orchestrator.agents.autogen_loops import hot_potato_loop
from nyra_orchestrator.agents.coder_deepcode import deepcode_one_shot
from nyra_orchestrator.agents.letta_persona import letta_upsert
from nyra_orchestrator.exporters.graph_exporter import export_graphrag

class State(BaseModel):
    task: str
    context_hints: List[str] = Field(default_factory=list)
    artifacts: List[Dict[str, Any]] = Field(default_factory=list)
    decisions: List[str] = Field(default_factory=list)
    errors: List[str] = Field(default_factory=list)
    next_actions: List[str] = Field(default_factory=list)

def run(state: State) -> State:
    state.context_hints.extend(fetch_context(state.task))
    plan = plan_with_praison(state.task, state.context_hints)
    state.decisions.append(f"Plan: {plan.get('summary','n/a')}")
    tools = propose_tools(plan)
    state.decisions.append("Tools: " + ", ".join([t['name'] for t in tools]))
    t = state.task.lower()
    if "scaffold" in t or "setup" in t:
        state.artifacts.append(openhands_scaffold(plan, state.context_hints))
    elif "debug" in t or "fix" in t:
        state.artifacts.append(openhands_debug(plan, state.context_hints))
    elif "code" in t or "implement" in t:
        state.artifacts.extend(hot_potato_loop(state.task, primary='deepcode', secondary='openhands'))
    else:
        state.artifacts.append(deepcode_one_shot(state.task, state.context_hints))
    memory_update(state)
    export_graphrag(state)
    letta_upsert({"summary": f"Completed task: {state.task} with {len(state.artifacts)} artifacts"})
    state.next_actions.append("Review artifacts; open PR; schedule follow-ups")
    return state
