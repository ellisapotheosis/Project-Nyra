HKUD/DeepCode placeholder — configure external coding agent tooling here.
