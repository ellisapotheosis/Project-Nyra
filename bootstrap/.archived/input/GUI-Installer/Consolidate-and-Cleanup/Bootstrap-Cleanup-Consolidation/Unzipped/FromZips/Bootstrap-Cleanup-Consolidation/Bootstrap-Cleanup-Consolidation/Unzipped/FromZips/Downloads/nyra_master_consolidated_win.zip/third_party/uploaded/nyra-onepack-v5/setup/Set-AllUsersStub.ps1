
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { Write-Warning "Run elevated"; exit 1 }
$target = Join-Path $PSHOME "profile.ps1"
Copy-Item $target "$target.bak" -Force -ErrorAction SilentlyContinue
Set-Content -Path $target -Value '. "$HOME\.config\nyra\pwsh\Nyra.Profile.Central.ps1"' -Encoding utf8
Write-Host "AllUsersAllHosts stub written to $target" -ForegroundColor Green
