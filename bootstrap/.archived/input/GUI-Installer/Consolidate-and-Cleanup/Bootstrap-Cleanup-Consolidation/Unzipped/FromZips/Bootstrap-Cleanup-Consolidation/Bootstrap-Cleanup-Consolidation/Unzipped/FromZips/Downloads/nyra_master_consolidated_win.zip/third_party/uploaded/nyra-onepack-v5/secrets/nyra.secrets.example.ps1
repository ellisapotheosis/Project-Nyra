
# Rename to nyra.secrets.ps1, then:
#  $env:NYRA_GH_USER = "ellisapotheosis"
#  $env:NYRA_GH_PAT  = "<YOUR_PAT_HERE>"
#  $env:NYRA_GH_REPO_OWNER = "ellisapotheosis"
#  $env:NYRA_GH_REPO_NAME  = "Project-Nyra"
