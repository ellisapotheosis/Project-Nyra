#!/usr/bin/env bash
set -euo pipefail
OUT_DIR="${OUT_DIR:-./backups/mongo}"
mkdir -p "$OUT_DIR"
TS=$(date +%Y%m%d_%H%M%S)
docker exec mongodb mongodump --archive --gzip --db=librechat > "$OUT_DIR/mongo_librechat_$TS.archive.gz"
echo "[mongo] dump saved to $OUT_DIR/mongo_librechat_$TS.archive.gz"
