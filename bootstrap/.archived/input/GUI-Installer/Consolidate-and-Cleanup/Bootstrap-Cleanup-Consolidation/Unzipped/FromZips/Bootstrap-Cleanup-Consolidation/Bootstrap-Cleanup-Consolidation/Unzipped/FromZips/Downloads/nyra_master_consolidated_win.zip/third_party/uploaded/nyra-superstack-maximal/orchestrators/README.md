# Orchestrators

- **AutoGen v2 (AG2)** — `orchestrators/ag2/example_duo.py`
- **LangGraph** — `orchestrators/langgraph/minimal_graph.py`
- **CrewAI** — `orchestrators/crewai/sample_crew.py`
- **PraisonAI** — YAML-style multi-agent recipes
- **AgentZero** — bring-your-own flows
- **Claude‑Flow / Flow‑Nexus** — swarm & MCP tooling harness
- **Archon (MCP)** — code/task hub with MCP
