def infer_edges(state):
    """Simple heuristics: 
    - If a plan exists → edges from 'plan' to each artifact 'implements'
    - If artifacts mention 'test' or 'fix' → 'verifies'/'fixes'
    """
    edges = []
    plan_nodes = [d for d in state.decisions if d.lower().startswith("plan:")]
    if plan_nodes:
        plan_id = "plan_0"
        for i, a in enumerate(state.artifacts):
            edges.append({"src": plan_id, "dst": f"artifact_{i}", "type":"implements", "weight":1.0, "evidence": []})
            text = (a.get("content") or "").lower()
            if "test" in text: edges.append({"src": f"artifact_{i}", "dst": plan_id, "type":"verifies", "weight":0.6, "evidence": []})
            if "fix" in text or "debug" in text: edges.append({"src": f"artifact_{i}", "dst": plan_id, "type":"fixes", "weight":0.6, "evidence": []})
    return edges
