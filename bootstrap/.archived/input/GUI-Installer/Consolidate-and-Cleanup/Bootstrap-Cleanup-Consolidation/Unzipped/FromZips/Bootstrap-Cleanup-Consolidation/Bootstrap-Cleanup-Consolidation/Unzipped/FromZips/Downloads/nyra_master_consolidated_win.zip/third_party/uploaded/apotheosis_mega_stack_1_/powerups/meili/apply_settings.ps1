param([string]$IndexName = "history")
if (-not $env:MEILI_HOST) { throw "Set MEILI_HOST (e.g. http://localhost:7700)" }
if (-not $env:MEILI_API_KEY) { throw "Set MEILI_API_KEY" }
$settingsPath = Join-Path $PSScriptRoot "index_settings.json"
$headers = @{
  "Authorization" = $env:MEILI_API_KEY
  "Content-Type"  = "application/json"
}
Invoke-RestMethod -Method Post -Uri "$($env:MEILI_HOST)/indexes/$IndexName/settings" -Headers $headers -InFile $settingsPath
