#!/usr/bin/env bash
set -euo pipefail
: "${PGHOST:?}"
: "${PGUSER:?}"
: "${PGDATABASE:?}"
: "${CLICKHOUSE_URL:?E.g. http://localhost:8123}"
: "${CLICKHOUSE_USER:?}"
: "${CLICKHOUSE_PASSWORD:?}"
: "${S3_URL:?E.g. https://s3.amazonaws.com/mybucket/langfuse/$(date +%F)}"
: "${AWS_ACCESS_KEY_ID:?}"
: "${AWS_SECRET_ACCESS_KEY:?}"

TS="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${OUT_DIR:-/tmp/langfuse-backups/$TS}"
mkdir -p "$OUT_DIR"

echo "[*] Dumping Postgres via pg_dump..."
PGPASSWORD="${PGPASSWORD:?Set PGPASSWORD}" pg_dump -Fc -Z9 -f "$OUT_DIR/postgres.dump"

echo "[*] Backing up ClickHouse with BACKUP DATABASE to S3..."
CLICKHOUSE_DB="${CLICKHOUSE_DB:-default}"
CH_S3_URL="S3('$S3_URL', '${AWS_ACCESS_KEY_ID}', '${AWS_SECRET_ACCESS_KEY}')"
CLICKHOUSE_CLIENT="${CLICKHOUSE_CLIENT:-clickhouse-client}"
$CLICKHOUSE_CLIENT --host "$(echo $CLICKHOUSE_URL | sed -E 's#https?://([^:/]+).*#\1#')"   --port "$(echo $CLICKHOUSE_URL | sed -E 's#https?://[^:/]+:([0-9]+).*#\1#')"   --user "$CLICKHOUSE_USER" --password "$CLICKHOUSE_PASSWORD"   --query "BACKUP DATABASE ${CLICKHOUSE_DB} TO ${CH_S3_URL} SETTINGS s3_truncate_on_insert=1, base_backup_interval='1d';"

echo "[*] Uploading Postgres dump to S3 path..."
aws s3 cp "$OUT_DIR/postgres.dump" "$S3_URL/postgres.dump"

echo '[✔] Backup complete.'
