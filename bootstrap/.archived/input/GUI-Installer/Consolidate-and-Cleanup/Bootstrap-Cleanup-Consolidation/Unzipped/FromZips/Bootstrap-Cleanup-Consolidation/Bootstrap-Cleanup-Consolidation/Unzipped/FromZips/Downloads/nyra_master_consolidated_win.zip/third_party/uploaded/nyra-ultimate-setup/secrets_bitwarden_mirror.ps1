param(
  [Parameter(Mandatory)][string[]]$Pairs,
  [switch]$RequireSession
)
$ErrorActionPreference = 'Stop'

if (-not (Get-Command bw -ErrorAction SilentlyContinue)) { throw "Bitwarden CLI (bw) not found in PATH." }

# Ensure session
if ($RequireSession) {
  if (-not $env:BW_SESSION) { throw "BW_SESSION is not set. Run: $env:BW_SESSION = bw unlock --raw" }
}

function Upsert-BWSecureNote {
  param([string]$Name, [string]$Notes)
  $tmpl = bw get template item | ConvertFrom-Json
  $tmpl.type = 2  # Secure Note
  $tmpl.name = $Name
  $tmpl.notes = $Notes
  $json = $tmpl | ConvertTo-Json -Depth 6 | bw encode

  # Try to find existing
  $existing = bw list items --search $Name | ConvertFrom-Json | Where-Object { $_.name -eq $Name } | Select-Object -First 1

  if ($existing) {
    $id = $existing.id
    bw edit item $id $json | Out-Null
    Write-Host "✓ Updated Bitwarden note: $Name"
  } else {
    bw create item $json | Out-Null
    Write-Host "✓ Created Bitwarden note: $Name"
  }
}

$bad = @()
foreach ($p in $Pairs) {
  if ($p -notmatch '^[^=]+=.+' ) { $bad += $p }
}
if ($bad.Count) { throw "Malformed pairs: $($bad -join ', ')" }

foreach ($p in $Pairs) {
  $k,$v = $p.Split('=',2)
  Upsert-BWSecureNote -Name $k -Notes $v
}
