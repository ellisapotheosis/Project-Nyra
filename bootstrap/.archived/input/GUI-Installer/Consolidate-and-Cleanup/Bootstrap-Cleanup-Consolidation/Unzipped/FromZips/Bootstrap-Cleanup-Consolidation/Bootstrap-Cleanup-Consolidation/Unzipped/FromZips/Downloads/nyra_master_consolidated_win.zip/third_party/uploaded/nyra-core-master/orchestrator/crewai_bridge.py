from crewai import Agent, Task, Crew

# Define base agents for orchestration

def build_crewai_agents():
    coder = Agent(
        role="Lead Coder",
        goal="Implement new features and refactor code.",
        backstory="Expert software engineer with mastery of Python and JS."
    )

    reviewer = Agent(
        role="External Reviewer",
        goal="Check code for style, performance, and security issues.",
        backstory="Critical eye for detail and best practices."
    )

    return [coder, reviewer]


def run_crewai_task(prompt: str):
    agents = build_crewai_agents()
    task = Task(
        description=prompt,
        expected_output="Reviewed and refined code snippet",
        agent=agents[0]
    )
    crew = Crew(agents=agents, tasks=[task])
    return crew.kickoff()


if __name__ == "__main__":
    result = run_crewai_task("Write a Python function to reverse a string.")
    print(result)