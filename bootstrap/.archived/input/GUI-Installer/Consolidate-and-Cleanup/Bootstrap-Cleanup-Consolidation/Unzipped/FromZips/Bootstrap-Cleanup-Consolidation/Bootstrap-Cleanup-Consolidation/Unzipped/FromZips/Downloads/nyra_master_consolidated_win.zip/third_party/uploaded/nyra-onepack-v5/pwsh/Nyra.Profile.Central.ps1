
$ErrorActionPreference = 'Stop'
$PSStyle.OutputRendering = 'Ansi'
$modules = @('PSReadLine','Terminal-Icons','PSFzf')
foreach ($m in $modules) { try { Import-Module $m -ErrorAction SilentlyContinue } catch {} }
if (Get-Module -ListAvailable -Name PSReadLine) {
  Set-PSReadLineOption -EditMode Windows -ErrorAction SilentlyContinue
  try { Set-PSReadLineOption -PredictionViewStyle ListView } catch {}
  try { Set-PSReadLineOption -PredictionSource History } catch {}
}
function azhelp {
  Write-Host "★ Apotheosis — quick keys & commands" -ForegroundColor Yellow
  Write-Host "Alt+← / Alt+↑ : parent (cd ..)" -ForegroundColor Cyan
  Write-Host "Alt+→         : pick child dir (fzf/OGV)" -ForegroundColor Cyan
  Write-Host "Ctrl+t / Ctrl+r: PSFzf files / reverse history" -ForegroundColor Cyan
  Write-Host "spp / sps      : switch prompt (Oh My Posh / Starship)"
  Write-Host "Use-OhMyPoshTheme -Name neon|minimal"
  Write-Host "ryeup | Set-GitHubPAT | Set-GitRemoteToken | Set-GitRemoteTokenFixed"
}
$pyUser313 = Join-Path $env:APPDATA 'Python\Python313\Scripts'
if ((Test-Path $pyUser313) -and ($env:PATH -notlike "*$pyUser313*")) { $env:PATH += ";$pyUser313" }
function __nyra_cd_parent { Set-Location .. }
function __nyra_cd_child {
  $dirs = Get-ChildItem -Directory -Force -ErrorAction SilentlyContinue
  if (-not $dirs) { return }
  $choice = $null
  if (Get-Command fzf -ErrorAction SilentlyContinue) { $choice = ($dirs | % FullName) | fzf }
  elseif (Get-Command Invoke-Fzf -ErrorAction SilentlyContinue) { $choice = ($dirs | % FullName) | Invoke-Fzf }
  else {
    $i=0; $dirs | % { "{0,2}: {1}" -f $i,$_.Name | Write-Host; $i++ }
    $idx = Read-Host "Pick dir index"
    if ($idx -match '^\d+$' -and [int]$idx -lt $dirs.Count) { $choice = $dirs[[int]$idx].FullName }
  }
  if ($choice) { Set-Location $choice }
}
if (Get-Module -ListAvailable -Name PSReadLine) {
  Set-PSReadLineKeyHandler -Chord 'Alt+LeftArrow'  -ScriptBlock { __nyra_cd_parent }
  Set-PSReadLineKeyHandler -Chord 'Alt+UpArrow'    -ScriptBlock { __nyra_cd_parent }
  Set-PSReadLineKeyHandler -Chord 'Alt+RightArrow' -ScriptBlock { __nyra_cd_child }
}
$global:NYRA_OMP_NEON = Join-Path $env:USERPROFILE '.config\nyra\omp\nyra-neon.omp.yaml'
$global:NYRA_OMP_MINI = Join-Path $env:USERPROFILE '.config\nyra\omp\nyra-minimal.omp.yaml'
$global:NYRA_STAR_CFG = Join-Path $env:USERPROFILE '.config\starship.toml'
function Set-OhMyPosh {
  if (Get-Command oh-my-posh -ErrorAction SilentlyContinue) {
    Remove-Item "$env:LOCALAPPDATA\oh-my-posh\init*.ps1" -Force -ErrorAction SilentlyContinue
    $cfg = if (Test-Path $env:NYRA_OMP_CONFIG) { $env:NYRA_OMP_CONFIG } elseif (Test-Path $global:NYRA_OMP_NEON) { $global:NYRA_OMP_NEON } else { $null }
    if ($cfg) { oh-my-posh init pwsh --config "$cfg" | Invoke-Expression } else { oh-my-posh init pwsh | Invoke-Expression }
    Write-Host "Prompt: Oh My Posh" -ForegroundColor Cyan
  } else { Write-Warning "oh-my-posh not installed." }
}
Set-Alias spp Set-OhMyPosh
function Set-Starship {
  if (Get-Command starship -ErrorAction SilentlyContinue) {
    if (Test-Path $global:NYRA_STAR_CFG) { $env:STARSHIP_CONFIG = $global:NYRA_STAR_CFG }
    Invoke-Expression (&starship init powershell)
    Write-Host "Prompt: Starship" -ForegroundColor Cyan
  } else { Write-Warning "starship not installed." }
}
Set-Alias sps Set-Starship
function Use-OhMyPoshTheme { param([ValidateSet('neon','minimal')][string]$Name='neon')
  $path = if ($Name -eq 'minimal') { $global:NYRA_OMP_MINI } else { $global:NYRA_OMP_NEON }
  if (Test-Path $path) { $env:NYRA_OMP_CONFIG = $path; Set-OhMyPosh } else { Write-Warning "Theme not found at $path" }
}
if (Get-Command oh-my-posh -ErrorAction SilentlyContinue) { Set-OhMyPosh } elseif (Get-Command starship -ErrorAction SilentlyContinue) { Set-Starship }
Write-Host ("→ Using {0}" -f (if (Get-Command oh-my-posh -ErrorAction SilentlyContinue) {'Oh My Posh'} elseif (Get-Command starship -ErrorAction SilentlyContinue) {'Starship'} else {'stock prompt'}))
Write-Host "★ Apotheosis shell ready. Type 'azhelp' for tips." -ForegroundColor Yellow
function ryeup { if (Get-Command rye -ErrorAction SilentlyContinue) { rye sync; return } if (Get-Command uv -ErrorAction SilentlyContinue) { uv sync; return } Write-Warning "Install Rye or uv to use 'ryeup'." }
function Add-GitRemote { param([Parameter(Mandatory)][string]$Name,[Parameter(Mandatory)][string]$Url) git remote remove $Name 2>$null; git remote add $Name $Url; git remote -v }
function Set-GitHubPAT { param([Parameter(Mandatory)][string]$Token,[string]$User = "ellisapotheosis")
  git config --global credential.helper manager
  $creds = @"
protocol=https
host=github.com
username=$User
password=$Token
"@
  $creds | git credential-manager store
  Write-Host "Stored PAT for $User in Windows Credential Manager (GCM)." -ForegroundColor Green
}
function Set-GitRemoteToken { param([Parameter(Mandatory)][string]$Token,[Parameter(Mandatory)][string]$Owner,[Parameter(Mandatory)][string]$Repo,[string]$User = "ellisapotheosis")
  $url = "https://${User}:${Token}@github.com/${Owner}/${Repo}.git"
  git remote set-url origin $url
  Write-Warning "Token embedded in .git/config. Prefer Set-GitHubPAT."
}
function Set-GitRemoteTokenFixed {
  $secrets = Join-Path $env:USERPROFILE '.config\nyra\secrets\nyra.secrets.ps1'
  if (Test-Path $secrets) { . $secrets }
  if (-not $env:NYRA_GH_USER -or -not $env:NYRA_GH_PAT -or -not $env:NYRA_GH_REPO_OWNER -or -not $env:NYRA_GH_REPO_NAME) {
    Write-Error "Missing env vars: NYRA_GH_USER / NYRA_GH_PAT / NYRA_GH_REPO_OWNER / NYRA_GH_REPO_NAME"; return
  }
  $url = "https://${env:NYRA_GH_USER}:${env:NYRA_GH_PAT}@github.com/${env:NYRA_GH_REPO_OWNER}/${env:NYRA_GH_REPO_NAME}.git"
  git remote set-url origin $url
  Write-Warning "Token embedded in .git/config (fixed variant)."
}
Set-Alias ll Get-ChildItem
