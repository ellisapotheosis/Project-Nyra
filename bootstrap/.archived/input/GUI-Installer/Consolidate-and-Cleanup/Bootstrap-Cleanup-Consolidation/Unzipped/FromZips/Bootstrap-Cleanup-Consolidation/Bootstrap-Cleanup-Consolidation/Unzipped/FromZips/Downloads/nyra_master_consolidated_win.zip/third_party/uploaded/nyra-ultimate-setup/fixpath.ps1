param([switch]$UpdateMachine)
$ErrorActionPreference='Stop'

$backup = Join-Path ([Environment]::GetFolderPath('Desktop')) ("Path-Backups-" + (Get-Date -Format 'yyyyMMdd-HHmmss'))
mkdir $backup | Out-Null

$u = [Environment]::GetEnvironmentVariable('Path','User')
$m = [Environment]::GetEnvironmentVariable('Path','Machine')

Set-Content -Path (Join-Path $backup 'UserPATH.txt') -Value $u
Set-Content -Path (Join-Path $backup 'MachinePATH.txt') -Value $m

function Normalize([string[]]$parts){
  $parts | Where-Object { $_ } | ForEach-Object { $_.Trim().TrimEnd('\') } | Select-Object -Unique
}

$want = New-Object System.Collections.Generic.List[String]
$want.Add("$env:SystemRoot\System32")
$want.Add("$env:SystemRoot\System32\Wbem")
$want.Add("$env:SystemRoot\System32\WindowsPowerShell\v1.0")
if ($env:SCOOP) { $want.Add((Join-Path $env:SCOOP 'shims')) }
$want.Add("$env:USERPROFILE\scoop\shims")
$want.Add("$env:APPDATA\npm")
$want.Add("$env:USERPROFILE\scoop\apps\nodejs-lts\current\bin")

$uFixed = Normalize ($want + ($u -split ';'))
[Environment]::SetEnvironmentVariable('Path', ($uFixed -join ';'), 'User')
Write-Host "✓ Updated User PATH (size: $($uFixed.Count) entries)"

if ($UpdateMachine) {
  try {
    $mFixed = Normalize ($want + ($m -split ';'))
    [Environment]::SetEnvironmentVariable('Path', ($mFixed -join ';'), 'Machine')
    Write-Host "✓ Updated Machine PATH (size: $($mFixed.Count) entries)"
  } catch {
    Write-Host "⚠ Failed to update Machine PATH (run elevated). User PATH already fixed."
  }
}
Write-Host "✓ Done. Restart terminals (or log off/on) to apply PATH changes."
