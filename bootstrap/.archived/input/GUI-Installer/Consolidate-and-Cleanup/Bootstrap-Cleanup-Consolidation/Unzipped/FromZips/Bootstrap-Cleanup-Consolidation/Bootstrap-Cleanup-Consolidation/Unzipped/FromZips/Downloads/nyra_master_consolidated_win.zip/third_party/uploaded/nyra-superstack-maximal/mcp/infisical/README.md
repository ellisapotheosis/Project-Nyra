# infisical MCP

Stub docs: configure credentials & endpoints for `infisical` server.
