Start-Process -NoNewWindow "cloudflared.exe" -ArgumentList "tunnel run gpu-agent"
