# Apotheosis Power-Ups — Plus Pack
Date: 2025-08-20T06:47:28.908833Z

## What's inside
- Meilisearch index tuning for conversation search
- Scripts to apply settings (Linux/macOS and Windows)
- Langfuse nightly backups to S3 (Postgres + ClickHouse)
- Cron example
- Notion CSV with prompt taxonomy
- Open WebUI prompt pack for slash commands

## Quick start
1) Meilisearch settings
   export MEILI_HOST=http://localhost:7700
   export MEILI_API_KEY=MASTER_OR_ADMIN_KEY
   ./meili/apply_settings.sh history

2) Langfuse backups
   export PGHOST=localhost PGUSER=langfuse PGDATABASE=langfuse PGPASSWORD=changeme
   export CLICKHOUSE_URL=http://localhost:8123 CLICKHOUSE_USER=default CLICKHOUSE_PASSWORD=changeme
   export S3_URL=https://s3.amazonaws.com/YOUR_BUCKET/langfuse/$(date +%F)
   export AWS_ACCESS_KEY_ID=AKIA... AWS_SECRET_ACCESS_KEY=...
   ./langfuse/backup_to_s3.sh

3) Notion
   Import notion_prompt_taxonomy.csv as a database

4) Open WebUI
   Workspace → Prompts → Import → openwebui_prompts.json
