# Claude-Flow Runbook (Operator)

This doc mirrors the `prompts/claude_flow_prompt.txt` that you can paste into Claude-Flow.
It references the project's official CLI patterns for **swarm** vs **hive-mind**.

## 0) Preconditions

- Node 18+, `npm`
- Claude Code installed globally: `npm i -g @anthropic-ai/claude-code`
- (Optional) VS Code with Kilo Code installed

## 1) Initialize Claude-Flow and check commands

```bash
npx claude-flow@alpha init --force
npx claude-flow@alpha --help
```

## 2) Quick Swarm smoke test

```bash
npx claude-flow@alpha swarm "say hello to Apotheosis" --claude
```

## 3) Hive-Mind for persistent sessions

```bash
# Interactive wizard
npx claude-flow@alpha hive-mind wizard
# Spawn a named hive for orchestrator wiring
npx claude-flow@alpha hive-mind spawn "wire orchestrator" --namespace orchestrator --claude
```

## 4) Point Claude-Flow at this repo and kick tasks

Inside the repo root:

```bash
# sanity: list sessions & memory
npx claude-flow@alpha hive-mind status
npx claude-flow@alpha memory stats

# now delegate
npx claude-flow@alpha swarm "Read README.md and CLAUDE_FLOW_RUNBOOK.md. Prepare to: 
- start AutoGen host on orchestrator node
- start gRPC workers on each LAN node from scripts/start_autogen_worker.py
- validate .env -> config/*
- run src/orchestrator/controller.py with --plan-only then full"
```

## 5) MCP tooling

- Claude-Flow auto-configures MCP hooks on `init`. Still, ensure VS Code (Kilo) MCP servers are enabled (Archon, etc.).
- When invoking risky tools (file write/exec), require approval.

## 6) Done

When the hive completes:
- Artifacts should be committed to a new branch with a short report.
