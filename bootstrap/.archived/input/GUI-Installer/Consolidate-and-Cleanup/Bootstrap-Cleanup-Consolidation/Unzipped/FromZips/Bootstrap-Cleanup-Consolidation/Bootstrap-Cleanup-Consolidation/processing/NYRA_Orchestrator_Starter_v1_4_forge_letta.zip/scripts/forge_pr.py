#!/usr/bin/env python3
import os, argparse, json, time
from nyra_orchestrator.clients.openhands_cli import generate_patch
from nyra_orchestrator.clients.github_pr import ensure_branch, push_all, create_pr

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", required=True, help="Describe the change (used for PR title/body).")
    ap.add_argument("--repo_dir", default=".")
    ap.add_argument("--branch", default=None)
    a = ap.parse_args()
    repo = os.getenv("GITHUB_REPO")
    base = os.getenv("GITHUB_DEFAULT_BRANCH","main")
    if not repo: raise SystemExit("Set GITHUB_REPO, e.g., ellisapotheosis/Project-Nyra")
    branch = a.branch or f"nyra/{int(time.time())}"
    ensure_branch(repo, base, branch)
    patch = generate_patch(a.task, workdir=a.repo_dir)
    # Apply patch if openhands produced it; otherwise rely on current git changes
    # (For real use, parse patch and apply). Here we assume files changed in repo_dir.
    push_all(a.repo_dir, branch)
    pr = create_pr(repo, head=branch.split('/')[-1], base=base, title=f"NYRA: {a.task}", body=f"Automated PR\n\n````diff\n{patch[:5000]}\n````")
    print(json.dumps(pr, indent=2))
