#!/usr/bin/env bash
set -e
CMD=${1:-status}
start_core(){ nohup uvicorn core.app:app --host 0.0.0.0 --port 8000 >/tmp/nyra.log 2>&1 & }
start_tunnel(){ nohup cloudflared tunnel run nyra-tunnel >/tmp/cloudflared.log 2>&1 & }
stop_port(){ lsof -ti :$1 | xargs -r kill -9 || true; }
case "$CMD" in
  up) start_core; start_tunnel ;;
  down) stop_port 8000 ;;
  status) ss -lntp | grep -E ':8000|:3000|:4000|:6333' || true ;;
  *) echo "Usage: ./nyractl.sh [up|down|status]" ;;
esac
