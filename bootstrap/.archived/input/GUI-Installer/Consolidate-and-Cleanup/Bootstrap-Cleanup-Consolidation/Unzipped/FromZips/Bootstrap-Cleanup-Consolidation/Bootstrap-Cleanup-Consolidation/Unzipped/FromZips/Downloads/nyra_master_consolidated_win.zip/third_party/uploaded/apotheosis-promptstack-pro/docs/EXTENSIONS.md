# Browser Extensions

## AI Prompt Genius (open-source)
- Organize/search prompts, import/export JSON, local-first storage.
- Chrome Web Store: search "AI Prompt Genius"
- Source: benf2004/ChatGPT-Prompt-Genius

## Tab Session Manager (open-source)
- Save/restore windows & tab groups, autosave, tags, export, sorting.
- Chrome Web Store: search "Tab Session Manager"
- Source: sienori/Tab-Session-Manager

## Suggested setup
- Create 'Apotheosis' workspace sessions per project (research, writing, code).
- Name sessions with a prefix like `apo/physics/*` and tags for fast recall.
