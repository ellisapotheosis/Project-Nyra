# activepieces MCP

Stub docs: configure credentials & endpoints for `activepieces` server.
