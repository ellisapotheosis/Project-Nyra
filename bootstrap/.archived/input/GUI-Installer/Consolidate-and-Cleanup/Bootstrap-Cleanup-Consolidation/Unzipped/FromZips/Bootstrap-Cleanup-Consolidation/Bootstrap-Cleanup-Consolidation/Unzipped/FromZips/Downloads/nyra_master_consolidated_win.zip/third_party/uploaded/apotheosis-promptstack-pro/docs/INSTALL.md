# Apotheosis PromptStack — Quickstart

## 0) Requirements
- Docker + Docker Compose
- ~6 GB free disk space (ClickHouse/Meilisearch snapshots can grow)
- Optional: Chrome for extensions

## 1) Clone & Configure
```bash
cp .env.example .env
# Edit .env and set secure secrets
```

## 2) Start the stack
```bash
docker compose --env-file ./.env up -d
```

Services:
- LibreChat: http://localhost:3080
- Open WebUI: http://localhost:3000
- LiteLLM Gateway: http://localhost:4000/v1
- Langfuse Console: http://localhost:3100

## 3) First-run setup
- Open WebUI → Admin → Settings → Connections → Add OpenAI-compatible connection:
  - API Base URL: `http://litellm:4000/v1` (inside docker) or `http://localhost:4000/v1` (from your host)
  - API Key: `sk-litellm-admin-key` (from .env)
- LibreChat already points at LiteLLM via `librechat.yaml`.
- Import the prompt seeds in `prompts/openwebui_prompts.json` via Open WebUI → Prompts.

## 4) Local models
```bash
# examples:
ollama pull llama3.1:8b
ollama pull qwen2.5:7b
ollama pull deepseek-r1:8b
```
These are pre-listed in `litellm/config.yaml` and will appear in UIs via LiteLLM.

## 5) Prompt evals (promptfoo)
```bash
cd promptfoo
# Requires Node/npm: npm i -g promptfoo
promptfoo eval -c promptfooconfig.yaml
promptfoo view
```

## 6) Chrome add-ons (optional but recommended)
- AI Prompt Genius (prompt library & import/export)
- Tab Session Manager (save/sort workspaces & tab groups)

## 7) Stop / remove
```bash
docker compose down
# keep volumes; add -v to remove all data
```
