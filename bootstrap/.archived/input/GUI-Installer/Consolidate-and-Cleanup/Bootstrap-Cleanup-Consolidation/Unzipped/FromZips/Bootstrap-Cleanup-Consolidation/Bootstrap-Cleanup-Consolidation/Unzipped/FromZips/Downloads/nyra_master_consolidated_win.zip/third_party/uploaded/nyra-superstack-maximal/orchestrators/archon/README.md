Archon (MCP) acts as a knowledge/task center for coding assistants and research agents. Configure as an MCP server and group into MetaMCP channels.
