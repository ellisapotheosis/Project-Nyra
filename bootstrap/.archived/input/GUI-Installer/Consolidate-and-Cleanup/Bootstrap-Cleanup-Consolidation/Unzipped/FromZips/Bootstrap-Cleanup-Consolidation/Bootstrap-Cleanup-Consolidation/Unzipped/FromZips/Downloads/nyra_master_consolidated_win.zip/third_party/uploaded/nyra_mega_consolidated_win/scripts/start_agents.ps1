param()
$ErrorActionPreference = 'Stop'
function Start-Agent($Path, $Args) {
  if (Test-Path $Path) {
    Write-Host "Starting: $Path $Args"
    Start-Process pwsh -ArgumentList "-NoExit","-File",$Path,$Args -WindowStyle Minimized
  } else {
    Write-Host "Skip (missing): $Path"
  }
}
Start-Agent ".\services\agents\deepcode\run.ps1" ""
Start-Agent ".\services\runners\openhands\run.ps1" ""
Start-Agent ".\services\agents\swe-agent\run.ps1" ""
