from fastapi import FastAPI
from fastapi.responses import JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import os
import httpx
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

# CORS for dashboard and external callers
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve the dashboard at /ui
if os.path.isdir("dashboard"):
    app.mount("/ui", StaticFiles(directory="dashboard", html=True), name="ui")

OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")


class Prompt(BaseModel):
    text: str
    model: str | None = None

@app.get("/")
async def root():
    return {"message": "NYRA Agent Control Center Online"}

@app.post("/ollama")
async def query_ollama(prompt: Prompt):
    payload = {"prompt": prompt.text}
    if prompt.model:
        payload["model"] = prompt.model
    async with httpx.AsyncClient() as client:
        res = await client.post(f"{OLLAMA_BASE_URL}/api/generate", json=payload, timeout=120)
    return res.json()

@app.post("/openai")
async def query_openai(prompt: Prompt):
    headers = {"Authorization": f"Bearer {OPENAI_API_KEY}"}
    payload = {
        "model": "gpt-4o-mini",
        "messages": [{"role": "user", "content": prompt.text}]
    }
    async with httpx.AsyncClient() as client:
        res = await client.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload, timeout=120)
    return res.json()

@app.post("/anthropic")
async def query_anthropic(prompt: Prompt):
    headers = {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "claude-3-5-sonnet-20240620",
        "max_tokens": 512,
        "messages": [{"role": "user", "content": prompt.text}],
    }
    async with httpx.AsyncClient() as client:
        res = await client.post("https://api.anthropic.com/v1/messages", headers=headers, json=payload, timeout=120)
    return res.json()

@app.get("/wake")
async def wake():
    return {"status": "GPU tunnel confirmed alive"}