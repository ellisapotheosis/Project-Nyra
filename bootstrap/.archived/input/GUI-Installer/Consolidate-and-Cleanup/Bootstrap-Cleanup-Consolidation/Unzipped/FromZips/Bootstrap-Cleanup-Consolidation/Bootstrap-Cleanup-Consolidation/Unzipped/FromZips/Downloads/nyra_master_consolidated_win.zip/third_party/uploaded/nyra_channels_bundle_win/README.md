# NYRA Channels Bundle (Windows)

This bundle gives you **ready-made MCP “channel” configs** grouped by function (dev, memory, research, security, etc.), plus **merged configs** for **Claude Desktop**, **VS Code**, and **MCPO (for Open WebUI)** — and **PowerShell scripts** to install and run them quickly on Windows.

> TL;DR: fill in `scripts/env.template.ps1`, run `scripts/install-mcp-config.ps1`, then `scripts/start-mcpo.ps1` and add the MCPO endpoints into Open WebUI Tools.

## What’s inside

```
mcp/
  channels/
    dev.build.yaml          # filesystem, git, github, browser-use
    dev.scaffold.yaml       # codanna (code understand), markdown tooling
    ops.desktop.yaml        # time, fetch, shell
    security.secrets.yaml   # bitwarden, infisical
    memory.core.yaml        # qdrant (vector), graphiti (KG), mem0
    research.yaml           # browser-use, context7
    inception.yaml          # mcp-inception (guarded)

config/
  claude/claude_desktop_config.json  # merged "all channels" for Claude Desktop
  vscode/mcp.json                    # merged config for VS Code MCP
  mcpo/config.json                   # merged config for MCPO (Open WebUI)

scripts/
  env.template.ps1         # fill in and dot-source to export env vars
  install-mcp-config.ps1   # copies configs to the right places
  start-mcpo.ps1           # runs MCPO with hot-reload
```

## Mermaid: relationships (high level)

```mermaid
flowchart TD
  subgraph UI
    OWUI[Open WebUI] --- Lobe[LobeChat]
    VS[VS Code] --- Claude[Claude Desktop]
  end

  subgraph Proxy
    MCPO[[MCPO OpenAPI Proxy]]
    MetaMCP[[MetaMCP Aggregator]]
  end

  subgraph Channels
    Dev[dev.build] --- Ops[ops.desktop]
    Sec[security.secrets] --- Res[research]
    Mem[memory.core] --- Incp[inception]
    Scaf[dev.scaffold]
  end

  UI -->|HTTP Tools| MCPO
  UI -->|MCP (stdlib)| Claude
  Claude -->|mcpServers| Channels
  VS -->|mcp.json| Channels

  MCPO -->|OpenAPI per tool| Channels

  Mem -->|Qdrant| QD[(Qdrant 6333)]
  Mem -->|Graphiti| NEO[(Neo4j 7687)]
  Res -->|Context7| WWW[(Docs/APIs)]
  Sec -->|Bitwarden/Infisical| Vault[(Secrets)]
```

---

### Notes

- **MCPO** converts MCP servers into **OpenAPI endpoints** consumable by Open WebUI (and others). Config format follows the standard Claude Desktop `mcpServers` JSON.
- **Security**: Secrets MCPs are **local-only**. Don’t expose them over the network.
- **Graphiti** expects **Neo4j** running. Qdrant should be running for the vector memory server.
