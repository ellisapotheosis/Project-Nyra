# Apotheosis Orchestrator Starter

A pragmatic scaffold that lets you stitch together **LangGraph + AutoGen (gRPC workers) + ArchGW + Agent Zero + Archon (MCP)** and play nicely with **Kilo Code** in VS Code — while keeping room to slot in **Ollama** nodes and **AnythingLLM** on your LAN.

This is intentionally minimal and opinionated: one repo you can drop into your workspace and evolve.

---

## What you get

- **Config-first** layout (`config/*.yaml`) for nodes, models, gateways, and MCP.
- **LangGraph** controller with clean handoffs to specialized adapters (SwarmZero, AnythingLLM, MCP tools).
- **AutoGen** scripts to start a **gRPC host** and **workers** — one per LAN node — so your agents can live on multiple PCs.
- **Claude-Flow runbook + prompt** to let Claude orchestrate the initial wiring for you.
- Ready to be used from **Kilo Code** / VS Code once your MCP stack is connected.

> ⚠️ Heads-up: this is a scaffold, not a SaaS. Expect to tweak.

---

## Before you begin

1. **Install prerequisites**
   - Python 3.11+ and `venv`
   - Node 18+
   - Docker (for AnythingLLM / gateways, optional)

2. **Clone this repo and copy env**
   ```bash
   cp .env.example .env
   # edit keys/URLs
   ```

3. **Install Python deps**
   ```bash
   python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   ```

4. **(Optional) Install LangGraph extras**
   ```bash
   pip install "langgraph>=0.2.0"
   ```

5. **(Optional) AnythingLLM (Docker)**
   - Quickstart: run their docker image and visit `http://localhost:3001` to get an API key.
   - Docs: see `links` below.

---

## LAN model servers via Ollama (3 PCs)

You said you have **three PCs on the same LAN**. On each machine where Ollama runs, bind to all interfaces and open the firewall for port `11434`.

- Official FAQ shows how to set `OLLAMA_HOST` as an environment variable on Windows/macOS/Linux.  
- Many guides demonstrate using `0.0.0.0:11434` to expose to the network.

> ⚠️ Security: exposing to LAN means any host on that network can hit your models. Use firewalls, proper subnets, or reverse proxies with auth.

Update `config/ollama.yaml` and `.env` to list your nodes.

---

## Start the distributed AutoGen runtime

One machine runs the **host**; each node runs a **worker**.

- Host:
  ```bash
  source .venv/bin/activate
  python scripts/start_autogen_host.py --host 0.0.0.0:50051
  ```

- Worker (on each PC):
  ```bash
  source .venv/bin/activate
  python scripts/start_autogen_worker.py --host <HOST_IP>:50051 --name <pc-name>
  ```

> These use AutoGen’s experimental gRPC runtime. If you see connection issues, check the docs linked below and ensure `pip install "autogen-ext[grpc]"` is installed.

---

## Run the orchestrator (LangGraph)

From the **controller**:
```bash
source .venv/bin/activate
python src/orchestrator/controller.py --task "Scaffold a Next.js API with auth" --plan-only
```

You can set `--use-swarmzero` / `--use-anythingllm` / `--use-mcp` to exercise adapters, or edit `config/orchestrator.yaml` to set defaults.

---

## Use with Claude-Flow + Kilo Code

- See `CLAUDE_FLOW_RUNBOOK.md` and `prompts/claude_flow_prompt.txt` for a ready-to-go instruction set that Claude can execute.
- In **VS Code**, install **Kilo Code** and enable MCP servers (Archon, any others you like).

---

## Links (sources)

- **AutoGen** — distributed runtime & gRPC host/worker: official docs.  
- **LangGraph** — multi-agent & handoffs; resilient agent graphs.  
- **SwarmZero** — SDK + REST `/api/v1/chat` example.  
- **Ollama** — binding `OLLAMA_HOST` and exposing on LAN; official FAQ.  
- **AnythingLLM** — Docker setup & API docs.  
- **Arch Gateway (archgw)** — smart edge proxy for agents.  
- **Archon (MCP)** — MCP server/command center for coding assistants.
- **Kilo Code** — VS Code agent with MCP marketplace.

See `CLAUDE_FLOW_RUNBOOK.md` for direct command snippets.

---

## Folder map

```
config/
  nodes.yaml              # your three PCs + roles
  ollama.yaml             # model endpoints per node
  orchestrator.yaml       # routing & feature flags
  archgw.yaml             # (placeholder) arch gateway config
  archon.json             # (placeholder) MCP endpoints / tokens
  swarmzero.yaml          # base URL + auth
prompts/
  claude_flow_prompt.txt  # prompt for Claude-Flow to run the setup
scripts/
  bootstrap.sh
  start_autogen_host.py
  start_autogen_worker.py
  run_controller.sh
src/
  orchestrator/controller.py
  adapters/swarmzero_client.py
  adapters/anythingllm_client.py
  adapters/mcp_notes.md   # notes/pointers for MCP usage
```

---

## Troubleshooting

- **Workers won't register**: double-check host/worker versions, firewall, and that you installed `autogen-ext[grpc]`. The gRPC runtime is **experimental** — some rough edges are normal.
- **MCP tools feel dangerous**: lock them behind **ArchGW** or an MCP gateway, whitelist allowed tools, and prefer **SSE/HTTP** MCP over **STDIO** where possible.
- **LAN model servers**: if a host can’t reach an Ollama node, confirm the node’s firewall and that `OLLAMA_HOST=0.0.0.0:11434` was set correctly.

---

## License

MIT for this scaffold. You are responsible for the licenses of third‑party tools you run.
