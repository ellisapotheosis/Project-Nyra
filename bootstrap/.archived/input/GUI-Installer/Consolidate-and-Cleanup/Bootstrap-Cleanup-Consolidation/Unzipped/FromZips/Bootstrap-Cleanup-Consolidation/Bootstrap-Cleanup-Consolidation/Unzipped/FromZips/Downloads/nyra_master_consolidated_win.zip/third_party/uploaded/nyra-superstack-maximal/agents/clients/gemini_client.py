# Placeholder; prefer official Google SDKs
def chat(prompt:str):
    return {"model":"gemini-1.5-pro","output":"<response>"}
