| Host | Type | Value | Purpose |
|------|------|-------|---------|
| @    | A/CNAME | Wix-provided | Keep main site |
| ai   | CNAME | <your-tunnel>.cfargotunnel.com | UI |
| api  | CNAME | <app>.koyeb.app | Public API |
| mcp  | CNAME | <your-tunnel>.cfargotunnel.com | MCP endpoints |
