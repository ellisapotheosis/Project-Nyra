# Agent Setup Prompt (Claude-Flow / Claude Code / Any)

You are my **stack setup agent**. Apply the following plan precisely. Assume **Windows 11** with **PowerShell**. If a step fails, **self-correct** and continue.

## Goals
- Register all **MCP channel bundles** (dev, memory, research, secrets, ops, scaffold, inception).
- Wire the same MCP servers into **Claude Desktop**, **VS Code**, and **MCPO** (for Open WebUI).
- Bring up **Qdrant** and **Neo4j** (for Graphiti) via Docker.
- Verify end-to-end tool calls from both **Claude Desktop** and **Open WebUI**.

## Constraints
- DO NOT expose secrets MCPs outside localhost.
- Prefer `uvx` for Python-based MCP servers. Prefer `npx -y` for Node-based servers.
- Use the environment variables from `scripts/env.ps1` only (no hardcoded secrets).

## Procedure
1. `pwsh` — dot-source env:
   ```powershell
   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
   . .\scripts\env.ps1
   ```
2. Install configs:
   ```powershell
   .\scripts\install-mcp-config.ps1 -Target all
   ```
3. Start data stores (skip if running):
   ```powershell
   docker ps | findstr qdrant || docker run -d --name qdrant -p 6333:6333 -v qdrant:/qdrant/storage qdrant/qdrant
   docker ps | findstr neo4j   || docker run -d --name neo4j -p 7474:7474 -p 7687:7687 -e NEO4J_AUTH=neo4j/password neo4j:5.26
   ```
4. Launch MCPO:
   ```powershell
   .\scripts\start-mcpo.ps1 -Port 8000 -ApiKey "top-secret"
   ```
5. In **Open WebUI** UI, add these tool servers:
   - `http://localhost:8000/time`
   - `http://localhost:8000/fetch`
   - `http://localhost:8000/browser-use`
   - `http://localhost:8000/qdrant`
   - `http://localhost:8000/graphiti`
   - `http://localhost:8000/context7`
6. Validate:
   - Claude Desktop → list tools; call `time` and `fetch`.
   - Open WebUI → call `/time` in a test chat; confirm response.
7. Report a short **status summary** including any errors and suggested fixes.
