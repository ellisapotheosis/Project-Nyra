# Architecture

**North–South path**: UI (Open WebUI / LobeChat) → Gateway (LiteLLM / ArchGW) → Orchestrators (AG2, LangGraph, CrewAI, PraisonAI, AgentZero, Flow‑Nexus/Claude‑Flow) → Agents (OpenHands, HKUD/DeepCode, SmolAgents, PocketFlow) → Tools (MCP mesh via MetaMCP/MCPO) → Memory (Letta, Zep, memOS) → RAG (Qdrant + Graphiti + FalkorDB).

**East–West mesh**: MCP servers grouped into **MetaMCP channels** per agent/task type; surfaced to UIs via **MCPO** when needed.

**Observability**: OTEL (OpenLIT) → Prometheus/Loki → Grafana dashboards.
