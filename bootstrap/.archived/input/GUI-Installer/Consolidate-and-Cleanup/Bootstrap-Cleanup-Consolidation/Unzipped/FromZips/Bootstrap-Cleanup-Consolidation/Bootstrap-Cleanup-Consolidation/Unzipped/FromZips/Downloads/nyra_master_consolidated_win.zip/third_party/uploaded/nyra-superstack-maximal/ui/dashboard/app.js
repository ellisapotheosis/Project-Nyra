async function call(path){
  const prompt = document.getElementById('prompt').value;
  const model = document.getElementById('model').value || 'openai/gpt-4o';
  const res = await fetch('http://localhost:8000/chat', {
    method: 'POST',
    headers: {'Content-Type':'application/json','X-API-Key':(localStorage.getItem('NYRA_KEY')||'dev-key')},
    body: JSON.stringify({model, messages:[{role:'user', content: prompt}]})
  });
  const data = await res.json();
  document.getElementById('out').textContent = JSON.stringify(data,null,2);
}
