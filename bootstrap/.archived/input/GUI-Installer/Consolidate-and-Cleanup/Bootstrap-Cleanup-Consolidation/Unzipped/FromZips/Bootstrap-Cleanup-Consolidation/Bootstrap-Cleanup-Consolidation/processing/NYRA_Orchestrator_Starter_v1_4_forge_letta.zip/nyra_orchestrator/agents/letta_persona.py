import os, json, time
PERSONA_FILE = "runs/memory/letta_persona.json"

def load_persona():
    if os.path.exists(PERSONA_FILE):
        return json.load(open(PERSONA_FILE, encoding="utf-8"))
    return {"id":"letta_default","traits":["precise","decisive","builder"],"goals":[],"history":[]}

def save_persona(p):
    os.makedirs(os.path.dirname(PERSONA_FILE), exist_ok=True)
    json.dump(p, open(PERSONA_FILE,"w",encoding="utf-8"), ensure_ascii=False, indent=2)

def remember(event: str):
    p = load_persona()
    p.setdefault("history", []).append({"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ"), "event": event})
    save_persona(p)

# Optional HTTP stub (replace with real Letta SDK when available)
def letta_upsert(memory: dict):
    # Placeholder for Letta API
    remember(f"Letta upsert: {memory.get('summary','')}")
    return True
