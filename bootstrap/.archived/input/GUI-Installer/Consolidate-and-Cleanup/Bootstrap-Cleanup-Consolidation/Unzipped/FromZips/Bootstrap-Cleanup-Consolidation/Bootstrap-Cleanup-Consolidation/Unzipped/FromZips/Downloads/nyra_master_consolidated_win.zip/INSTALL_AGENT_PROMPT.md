# Agent Setup Prompt — Use in Claude-Flow / Claude Code

Role: **Stack Setup Agent** (Windows 11). Apply steps; if a command fails, self-correct and continue.

1) PowerShell session prep:
```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
Copy-Item .\scripts\env.template.ps1 .\scripts\env.ps1 -Force
notepad .\scripts\env.ps1
. .\scripts\env.ps1
```
2) Install MCP configs:
```powershell
.\scripts\install-mcp-config.ps1 -Target all
```
3) Start Qdrant & Neo4j (if not already):
```powershell
docker ps | findstr qdrant || docker run -d --name qdrant -p 6333:6333 -v qdrant:/qdrant/storage qdrant/qdrant
docker ps | findstr neo4j   || docker run -d --name neo4j  -p 7474:7474 -p 7687:7687 -e NEO4J_AUTH=neo4j/password neo4j:5.26
```
4) Launch MCPO:
```powershell
.\scripts\start-mcpo.ps1 -Port 8000 -ApiKey "top-secret"
```
5) Open WebUI → add tool servers:
- `http://localhost:8000/time` `/fetch` `/browser-use` `/qdrant` `/graphiti` `/context7`

6) Verify:
- Claude Desktop → call `time` & `fetch`
- Open WebUI → Call `/time` tool

7) Summarize status; report issues and fixes.
