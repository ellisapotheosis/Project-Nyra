# NYRA Setup Bundle (AgentZero + Claude + CUA)
This bundle bootstraps your orchestrator (AgentZero), Claude Desktop cleanup flow, Nyra Voice UI, and memory prep.

## Quick Start (Windows)
1) Edit `.env` with your temp keys.
2) Double-click `bootstrap.ps1` (or run in PowerShell).
3) Open `nyra_ui/index.html` in your browser for the voice panel.

## Quick Start (Linux/macOS)
```
chmod +x bootstrap.sh
./bootstrap.sh
```

## Claude Memory Cleanup
Drop `.md` / `.txt` files into `notion/`, then run:
```
python claude_cleanup.py
```
Outputs chunks to `memory/cleaned/*.jsonl` (vector-ready).

## Notes
- `launch_orchestrator.py` is a stub for your orchestrator integration.
- Replace with AgentZero runtime when ready.
- Nyra UI expects Voicemod Control API at `localhost:59125`.
