
Write-Host "NYRA_OMP_CONFIG=$env:NYRA_OMP_CONFIG"
"{0} exists: {1}" -f $env:NYRA_OMP_CONFIG, (Test-Path $env:NYRA_OMP_CONFIG) | Write-Host
"{0} fragment: {1}" -f 'WT fragment', (Test-Path "$env:LOCALAPPDATA\Microsoft\Windows Terminal\Fragments\Nyra\nyra.json") | Write-Host
try { "OMP: $(oh-my-posh --version)" | Write-Host } catch {}
try { $m=Get-Module PSReadLine -ListAvailable | Sort-Object Version -Descending | Select -First 1; "PSReadLine: $($m.Version)" | Write-Host } catch {}
