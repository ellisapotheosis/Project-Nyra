param(
  [ValidateSet("claude","vscode","mcpo","all")]
  [string]$Target = "all"
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Resolve-Path (Join-Path $here "..")

# Merge files are pre-generated under config/*
$claudeCfg = Join-Path $root "config/claude/claude_desktop_config.json"
$vscodeCfg = Join-Path $root "config/vscode/mcp.json"
$mcpoCfg   = Join-Path $root "config/mcpo/config.json"

Write-Host "Installing MCP configs for target: $Target`n" -ForegroundColor Cyan

if ($Target -eq "claude" -or $Target -eq "all") {
  $dst = Join-Path $env:APPDATA "Claude/claude_desktop_config.json"
  New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
  Copy-Item $claudeCfg $dst -Force
  Write-Host "✔ Wrote Claude Desktop MCP config -> $dst"
}

if ($Target -eq "vscode" -or $Target -eq "all") {
  $dstDir = Join-Path $env:USERPROFILE ".vscode"
  New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
  $dst = Join-Path $dstDir "mcp.json"
  Copy-Item $vscodeCfg $dst -Force
  Write-Host "✔ Wrote VS Code MCP config -> $dst"
}

if ($Target -eq "mcpo" -or $Target -eq "all") {
  $dst = Join-Path $root "config\mcpo\config.json"
  Copy-Item $mcpoCfg $dst -Force
  Write-Host "✔ Prepared MCPO config -> $dst"
}

Write-Host "`nDone. Restart clients (Claude/VS Code) to load servers." -ForegroundColor Green
