import requests
def ollama_chat(prompt:str, host="http://localhost:11434"):
    return requests.post(f"{host}/api/generate", json={"model":"llama3","prompt":prompt}).json()
