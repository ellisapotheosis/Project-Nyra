# Windows 11 Setup

1) Install Docker Desktop for Windows (with WSL2 backend) and ensure `docker compose version` works.
2) In PowerShell:
```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
Unblock-File .\scripts\*.ps1
Copy-Item .\config\.env.example .\.env -Force
notepad .\.env
.\scripts\bootstrap.ps1
.\scripts\up.ps1 all
```
To stop: `.\scripts\down.ps1`
