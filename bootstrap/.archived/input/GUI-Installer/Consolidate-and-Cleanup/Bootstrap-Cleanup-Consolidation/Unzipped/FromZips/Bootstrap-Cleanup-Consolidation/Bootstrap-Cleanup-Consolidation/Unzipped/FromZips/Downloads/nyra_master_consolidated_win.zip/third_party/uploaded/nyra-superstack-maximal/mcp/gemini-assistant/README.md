# gemini-assistant MCP

Stub docs: configure credentials & endpoints for `gemini-assistant` server.
