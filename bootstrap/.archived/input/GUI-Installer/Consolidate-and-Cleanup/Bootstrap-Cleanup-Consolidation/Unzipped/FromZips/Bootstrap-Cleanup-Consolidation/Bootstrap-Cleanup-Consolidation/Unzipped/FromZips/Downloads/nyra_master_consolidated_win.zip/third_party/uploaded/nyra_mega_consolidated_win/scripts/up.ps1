param(
  [ValidateSet('core','orchestrators','obs','all')]
  [string]$Profile = 'core'
)
$ErrorActionPreference = 'Stop'
switch ($Profile) {
  'core' { docker compose -f .\infra\docker-compose.core.yml up -d }
  'orchestrators' { docker compose -f .\infra\docker-compose.orchestrators.yml up -d --build }
  'obs' { docker compose -f .\infra\docker-compose.observability.yml up -d }
  'all' {
    docker compose -f .\infra\docker-compose.core.yml up -d
    docker compose -f .\infra\docker-compose.orchestrators.yml up -d --build
    docker compose -f .\infra\docker-compose.observability.yml up -d
  }
}
