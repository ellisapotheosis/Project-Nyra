from typing import TypedDict
from langgraph.graph import StateGraph, END

class S(TypedDict):
    question: str
    answer: str

def llm_node(state:S):
    state["answer"] = f"Echo: {state['question']}"
    return state

graph = StateGraph(S)
graph.add_node("llm", llm_node)
graph.set_entry_point("llm")
graph.add_edge("llm", END)
app = graph.compile()
