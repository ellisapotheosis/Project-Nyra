# Notion Instructions / CUA Prompts

## Setup
- Import this README and config files into Notion.
- Tag with `#NYRA` `#Agent` `#CUA`.

## Prompts (Claude / AgentZero)
1. **Memory Loader**
   - "Ingest all docs from `notion/` and produce chunked JSONL in `memory/cleaned/` using 1,600‑token windows."
2. **Dev Orchestrator**
   - "Plan the task DAG for Nyra: Voice UI, CRM integration, Bonzo-flow emulation, and quoting pipeline. Output a step-by-step schedule."
3. **CUA Voice**
   - "Bind Voicemod TTS to clipboard watcher with ctrl+v hotkey. Confirm status and speak any new text."
