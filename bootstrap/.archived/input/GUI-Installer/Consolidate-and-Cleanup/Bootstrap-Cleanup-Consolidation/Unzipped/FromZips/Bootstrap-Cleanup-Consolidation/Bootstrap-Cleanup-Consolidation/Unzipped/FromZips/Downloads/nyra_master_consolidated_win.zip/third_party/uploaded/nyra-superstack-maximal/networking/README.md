Use Cloudflare Tunnel for clean HTTPS on subdomains (keep Wix root untouched). Or use ngrok for dev.
