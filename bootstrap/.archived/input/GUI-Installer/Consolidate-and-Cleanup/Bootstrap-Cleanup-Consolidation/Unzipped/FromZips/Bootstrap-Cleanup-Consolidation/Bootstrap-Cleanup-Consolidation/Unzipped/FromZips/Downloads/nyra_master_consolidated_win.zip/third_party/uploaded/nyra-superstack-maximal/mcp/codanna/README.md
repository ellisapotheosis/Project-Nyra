# codanna MCP

Stub docs: configure credentials & endpoints for `codanna` server.
