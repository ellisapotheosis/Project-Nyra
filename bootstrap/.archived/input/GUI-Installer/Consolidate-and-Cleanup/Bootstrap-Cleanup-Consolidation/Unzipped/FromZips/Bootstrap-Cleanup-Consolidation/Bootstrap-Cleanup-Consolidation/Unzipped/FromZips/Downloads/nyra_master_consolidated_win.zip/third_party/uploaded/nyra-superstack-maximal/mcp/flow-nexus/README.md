# flow-nexus MCP

Stub docs: configure credentials & endpoints for `flow-nexus` server.
