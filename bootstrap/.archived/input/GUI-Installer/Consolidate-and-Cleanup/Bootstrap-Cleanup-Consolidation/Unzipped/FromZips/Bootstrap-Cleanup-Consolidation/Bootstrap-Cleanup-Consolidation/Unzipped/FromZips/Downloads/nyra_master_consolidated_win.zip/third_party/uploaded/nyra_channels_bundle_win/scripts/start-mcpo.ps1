param(
  [int]$Port = 8000,
  [string]$ApiKey = "top-secret"
)
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Resolve-Path (Join-Path $here "..")
$configPath = Join-Path $root "config\mcpo\config.json"

# Ensure uv is available; fallback to python -m pip when needed
function Test-Command { param([string]$Name) $null -ne (Get-Command $Name -ErrorAction SilentlyContinue) }

if (-not (Test-Command "uvx")) {
  Write-Host "uvx not found; installing uv via pipx..." -ForegroundColor Yellow
  if (-not (Test-Command "pipx")) { python -m pip install --user pipx; python -m pipx ensurepath }
  pipx install uv
}

if (-not (Test-Command "mcpo")) {
  Write-Host "Installing mcpo..." -ForegroundColor Yellow
  python -m pip install --user mcpo
}

Write-Host "Starting MCPO on port $Port with hot-reload..." -ForegroundColor Cyan
$env:MCPO_API_KEY = $ApiKey
uvx mcpo --config $configPath --hot-reload --port $Port
