`pip install praisonai` — create YAML recipes that wire agents/roles/tools succinctly.
