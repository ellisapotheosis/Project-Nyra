param([switch]$ShowOnly)
$ErrorActionPreference='Stop'

function Print-Path($label, $path) {
  Write-Host "$label"
  foreach($p in ($path -split ';' | Where-Object { $_ -and (Test-Path $_) } )){ "  $p" }
}

$userPath = (Get-ItemProperty -Path "HKCU:\Environment" -Name PSModulePath -ErrorAction SilentlyContinue).PSModulePath
if (-not $userPath) { $userPath = "" }

$homeModules = Join-Path $HOME "Documents\PowerShell\Modules"
$oneDriveModules = Join-Path $HOME "OneDrive\Documents\PowerShell\Modules"

$uParts = @()
$uParts += "$env:ProgramFiles\WindowsPowerShell\Modules"
$uParts += "$env:WINDIR\System32\WindowsPowerShell\v1.0\Modules"
$uParts += "$env:ProgramFiles\PowerShell\7\Modules"
$uParts += "$env:ProgramFiles\PowerShell\7-preview\Modules"
$uParts += $homeModules
$uParts += $oneDriveModules

$uFixed = ($uParts + ($userPath -split ';')) | Where-Object { $_ } | Select-Object -Unique -ExcludeNull
if ($ShowOnly) { Print-Path "Current PSModulePath (User):" $userPath; return }
Set-ItemProperty -Path "HKCU:\Environment" -Name PSModulePath -Value ($uFixed -join ';')
Write-Host "✓ Updated User PSModulePath. Restart shells to apply."
