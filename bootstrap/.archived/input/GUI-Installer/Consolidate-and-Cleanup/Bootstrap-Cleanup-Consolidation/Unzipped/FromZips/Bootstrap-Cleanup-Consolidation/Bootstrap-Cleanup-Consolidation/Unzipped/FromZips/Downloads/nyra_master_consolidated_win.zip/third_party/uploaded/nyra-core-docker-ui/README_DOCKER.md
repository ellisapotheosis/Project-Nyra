# NYRA Docker + Compose

## Build & Run
```bash
docker compose up -d --build
```

- Web API: http://localhost:7860
- Dashboard UI: http://localhost:7860/ui
- Ollama API: http://localhost:11434

### GPU on Linux / WSL2
Ensure NVIDIA Container Toolkit is installed, then add `--gpus all` or use the compose `devices` reservation as provided.

## Cloudflared in Compose
Mount your credentials into `./cloudflared` so the container can run:
```
cloudflared tunnel create gpu-agent
# This produces a credentials file. Place it at ./cloudflared/gpu-agent.json
```
Then add the DNS CNAME in Cloudflare to the printed `*.cfargotunnel.com` target.
