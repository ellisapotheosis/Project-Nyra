
pwsh -NoProfile -Command "Install-Module -Name PSReadLine -Scope CurrentUser -Force"
Remove-Item "$env:LOCALAPPDATA\oh-my-posh\init*.ps1" -Force -ErrorAction SilentlyContinue
