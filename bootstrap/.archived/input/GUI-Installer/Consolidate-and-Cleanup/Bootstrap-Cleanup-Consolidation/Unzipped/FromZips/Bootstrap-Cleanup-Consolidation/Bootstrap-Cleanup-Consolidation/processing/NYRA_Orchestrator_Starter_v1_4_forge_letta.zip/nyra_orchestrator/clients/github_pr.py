import os, requests, subprocess, time, json, base64, random, string
API = "https://api.github.com"

def _headers():
    tok = os.getenv("GITHUB_TOKEN")
    if not tok: raise RuntimeError("GITHUB_TOKEN is not set")
    return {"Authorization": f"token {tok}", "Accept": "application/vnd.github+json"}

def ensure_branch(repo: str, base: str, new_branch: str):
    # get base sha
    r = requests.get(f"{API}/repos/{repo}/git/ref/heads/{base}", headers=_headers()); r.raise_for_status()
    sha = r.json()["object"]["sha"]
    # create ref
    r = requests.post(f"{API}/repos/{repo}/git/refs", headers=_headers(), json={"ref": f"refs/heads/{new_branch}","sha": sha})
    if r.status_code not in (200,201,422): r.raise_for_status()  # 422 = already exists

def push_all(repo_dir: str, branch: str):
    subprocess.check_call(["git","add","-A"], cwd=repo_dir)
    subprocess.check_call(["git","commit","-m","nyra: automated changes"], cwd=repo_dir)
    subprocess.check_call(["git","push","origin", branch], cwd=repo_dir)

def create_pr(repo: str, head: str, base: str, title: str, body: str):
    r = requests.post(f"{API}/repos/{repo}/pulls", headers=_headers(), json={"title":title,"head":head,"base":base,"body":body})
    r.raise_for_status()
    return r.json()
