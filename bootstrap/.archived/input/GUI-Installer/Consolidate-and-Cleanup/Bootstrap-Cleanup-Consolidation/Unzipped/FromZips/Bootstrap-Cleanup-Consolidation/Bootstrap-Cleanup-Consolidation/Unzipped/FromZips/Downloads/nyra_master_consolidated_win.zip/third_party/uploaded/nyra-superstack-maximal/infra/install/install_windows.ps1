winget install Python.Python.3.11 -s winget --silent
winget install OpenJS.NodeJS.LTS -s winget --silent
winget install Cloudflare.Cloudflared -s winget --silent
pip install --upgrade pip
pip install fastapi uvicorn litellm
