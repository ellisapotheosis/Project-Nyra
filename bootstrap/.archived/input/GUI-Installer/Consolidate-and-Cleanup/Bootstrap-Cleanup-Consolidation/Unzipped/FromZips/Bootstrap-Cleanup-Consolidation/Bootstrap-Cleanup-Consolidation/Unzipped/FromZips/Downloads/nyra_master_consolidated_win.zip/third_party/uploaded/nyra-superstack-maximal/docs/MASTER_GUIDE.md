# MASTER GUIDE

- Architecture: `docs/ARCHITECTURE.md`
- Security: `docs/SECURITY.md`
- Runbook: `docs/RUNBOOK.md`
- ADRs: `docs/ADR.md`
- Roadmap: `docs/ROADMAP.md`

## Subsystems
- Core API/App: `core/`
- Orchestrators: `orchestrators/`
- Agents: `agents/`
- Memory & RAG: `memory/`, `rag/`
- MCP servers: `mcp/`
- UI: `ui/`
- Gateways/Routers: `gateways/`
- Observability/Evals: `observability/`
- Networking/DNS/Tunnels: `networking/`
- Infra (Docker/K8s/IaC): `infra/`
- Deploy: `deploy/`
- Scripts/ops: `scripts/`
