# github MCP

Stub docs: configure credentials & endpoints for `github` server.
