param()
$ErrorActionPreference = 'Stop'
if (-not (Test-Path ".\.env")) {
  Copy-Item .\config\.env.example .\.env -Force
  Write-Host "Created .env from example."
}
$dirs = @(
  ".\.data\open-webui",".\.data\lobechat",".\.data\dify",
  ".\.data\flowise",".\.data\n8n",".\.data\qdrant",
  ".\.data\falkordb",".\.data\metamcp",".\.data\archon",
  ".\.data\archgw",".\.data\langfuse"
)
foreach ($d in $dirs) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
Write-Host "Bootstrap complete."
