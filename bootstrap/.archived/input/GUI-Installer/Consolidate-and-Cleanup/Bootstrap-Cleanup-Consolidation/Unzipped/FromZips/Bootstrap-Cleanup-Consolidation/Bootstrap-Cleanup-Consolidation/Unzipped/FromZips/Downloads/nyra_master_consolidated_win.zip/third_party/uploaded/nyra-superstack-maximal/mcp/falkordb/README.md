# falkordb MCP

Stub docs: configure credentials & endpoints for `falkordb` server.
