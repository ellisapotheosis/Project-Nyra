# Promptfoo Quickstart
npm i -g promptfoo
promptfoo eval -c promptfooconfig.yaml
promptfoo view
