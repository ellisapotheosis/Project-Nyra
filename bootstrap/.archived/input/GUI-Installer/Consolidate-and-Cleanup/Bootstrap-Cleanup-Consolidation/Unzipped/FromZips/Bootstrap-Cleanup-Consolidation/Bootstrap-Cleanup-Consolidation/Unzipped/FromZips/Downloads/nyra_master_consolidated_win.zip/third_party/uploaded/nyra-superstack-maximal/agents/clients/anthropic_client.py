import os, requests
def chat(messages, model="claude-3-opus-20240229"):
    k = os.getenv("ANTHROPIC_API_KEY","")
    return requests.post("https://api.anthropic.com/v1/messages",
        headers={"x-api-key":k,"anthropic-version":"2023-06-01","Content-Type":"application/json"},
        json={"model":model,"messages":messages}).json()
