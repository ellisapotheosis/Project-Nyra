from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import os
import httpx
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")


class Prompt(BaseModel):
    text: str

@app.get("/")
async def root():
    return {"message": "NYRA Agent Control Center Online"}

@app.post("/ollama")
async def query_ollama(prompt: Prompt):
    async with httpx.AsyncClient() as client:
        res = await client.post(f"{OLLAMA_BASE_URL}/api/generate", json={"prompt": prompt.text})
    return res.json()

@app.post("/openai")
async def query_openai(prompt: Prompt):
    headers = {"Authorization": f"Bearer {OPENAI_API_KEY}"}
    payload = {
        "model": "gpt-4",
        "messages": [{"role": "user", "content": prompt.text}]
    }
    async with httpx.AsyncClient() as client:
        res = await client.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload)
    return res.json()

@app.post("/anthropic")
async def query_anthropic(prompt: Prompt):
    headers = {
        "x-api-key": ANTHROPIC_API_KEY,
        "Content-Type": "application/json"
    }
    payload = {
        "model": "claude-3-opus-20240229",
        "messages": [{"role": "user", "content": prompt.text}],
        "max_tokens": 512
    }
    async with httpx.AsyncClient() as client:
        res = await client.post("https://api.anthropic.com/v1/messages", headers=headers, json=payload)
    return res.json()

@app.post("/wake")
async def wake():
    return {"status": "GPU tunnel confirmed alive"}