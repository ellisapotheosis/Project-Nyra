Write-Host 'OpenHands MCP mode placeholder'
