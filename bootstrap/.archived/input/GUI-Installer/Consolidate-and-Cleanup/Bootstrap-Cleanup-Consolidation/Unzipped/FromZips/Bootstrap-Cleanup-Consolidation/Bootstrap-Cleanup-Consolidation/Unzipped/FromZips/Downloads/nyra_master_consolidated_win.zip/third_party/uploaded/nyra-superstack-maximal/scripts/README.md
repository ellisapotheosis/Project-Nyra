Helper scripts for day-to-day operations.
