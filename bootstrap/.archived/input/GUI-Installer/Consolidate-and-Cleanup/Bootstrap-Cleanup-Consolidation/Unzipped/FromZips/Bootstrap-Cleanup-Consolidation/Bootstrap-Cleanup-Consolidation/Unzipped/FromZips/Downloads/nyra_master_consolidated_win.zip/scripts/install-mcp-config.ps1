param([ValidateSet('claude','vscode','mcpo','all')][string]$Target='all')
$ErrorActionPreference='Stop'
$root = Resolve-Path (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "..")
$claudeCfg = Join-Path $root "config\claude\claude_desktop_config.json"
$vscodeCfg = Join-Path $root "config\vscode\mcp.json"
$mcpoCfg   = Join-Path $root "config\mcpo\config.json"

if ($Target -in @('claude','all')) {
  $dst = Join-Path $env:APPDATA "Claude\claude_desktop_config.json"
  New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
  Copy-Item $claudeCfg $dst -Force
  Write-Host "✔ Claude Desktop MCP config -> $dst"
}
if ($Target -in @('vscode','all')) {
  $dstDir = Join-Path $env:USERPROFILE ".vscode"
  New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
  Copy-Item $vscodeCfg (Join-Path $dstDir "mcp.json") -Force
  Write-Host "✔ VS Code MCP config -> $dstDir\mcp.json"
}
if ($Target -in @('mcpo','all')) {
  Copy-Item $mcpoCfg (Join-Path $root "config\mcpo\config.json") -Force
  Write-Host "✔ MCPO config prepared."
}
