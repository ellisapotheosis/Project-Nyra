import argparse, os, yaml
from dataclasses import dataclass
from typing import Dict, Any

# Minimal LangGraph usage without heavy dependencies at runtime in this stub.
try:
    from langgraph.graph import Graph
except Exception as e:
    Graph = None

from src.adapters.swarmzero_client import call_swarmzero
from src.adapters.anythingllm_client import ask_anythingllm

@dataclass
class State:
    task: str
    plan: str = ""
    result: str = ""

def plan_node(state: State) -> State:
    state.plan = f"Plan: break task '{state.task}' into research -> build -> summarize."
    return state

def research_node(state: State) -> State:
    state.result += "\n[research] placeholder"
    return state

def dev_node(state: State, use_swarmzero: bool) -> State:
    if use_swarmzero:
        out = call_swarmzero("Implement: " + state.task)
        state.result += f"\n[swarmzero] {out[:200]}..."
    else:
        state.result += "\n[dev] (no swarm)"
    return state

def summarize_node(state: State) -> State:
    state.result += "\n[summary] done."
    return state

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", required=True)
    ap.add_argument("--plan-only", action="store_true")
    ap.add_argument("--use-swarmzero", action="store_true")
    ap.add_argument("--use-anythingllm", action="store_true")
    args = ap.parse_args()

    cfg = {}
    if os.path.exists("config/orchestrator.yaml"):
        with open("config/orchestrator.yaml") as f:
            cfg = yaml.safe_load(f)
    use_swarm = args.use_swarmzero or cfg.get("routing", {}).get("use_swarmzero", False)
    use_rag = args.use_anythingllm or cfg.get("routing", {}).get("use_anythingllm", False)

    state = State(task=args.task)
    state = plan_node(state)
    if args.plan_only:
        print(state.plan)
        return

    state = research_node(state)
    if use_rag:
        rag = ask_anythingllm("Background research for: " + state.task)
        state.result += f"\n[anythingllm] {rag[:200]}..."

    state = dev_node(state, use_swarm)
    state = summarize_node(state)

    print(state.result)

if __name__ == "__main__":
    main()
