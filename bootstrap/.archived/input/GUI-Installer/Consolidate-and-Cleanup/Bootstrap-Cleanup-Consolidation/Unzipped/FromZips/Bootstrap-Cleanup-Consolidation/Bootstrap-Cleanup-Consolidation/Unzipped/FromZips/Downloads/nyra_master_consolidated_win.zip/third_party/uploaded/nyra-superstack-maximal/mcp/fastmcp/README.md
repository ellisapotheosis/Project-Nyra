# fastmcp MCP

Stub docs: configure credentials & endpoints for `fastmcp` server.
