# Minimal AG2-like duo (router call placeholder)
# pip install litellm
from litellm import completion
def duo_chat(prompt:str):
    res = completion(model="openai/gpt-4o", messages=[{"role":"user","content":prompt}])
    return res["choices"][0]["message"]["content"]
