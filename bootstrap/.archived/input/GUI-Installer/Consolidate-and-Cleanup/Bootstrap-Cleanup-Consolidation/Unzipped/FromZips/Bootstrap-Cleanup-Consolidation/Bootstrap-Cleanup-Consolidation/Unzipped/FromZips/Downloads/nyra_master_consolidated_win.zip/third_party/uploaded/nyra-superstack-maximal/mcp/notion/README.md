# notion MCP

Stub docs: configure credentials & endpoints for `notion` server.
