print('A2A host placeholder')
