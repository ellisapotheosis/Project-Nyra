import os, requests
def chat(messages, model="gpt-4o"):
    k = os.getenv("OPENAI_API_KEY","")
    return requests.post("https://api.openai.com/v1/chat/completions",
        headers={"Authorization":f"Bearer {k}"},
        json={"model":model,"messages":messages}).json()
