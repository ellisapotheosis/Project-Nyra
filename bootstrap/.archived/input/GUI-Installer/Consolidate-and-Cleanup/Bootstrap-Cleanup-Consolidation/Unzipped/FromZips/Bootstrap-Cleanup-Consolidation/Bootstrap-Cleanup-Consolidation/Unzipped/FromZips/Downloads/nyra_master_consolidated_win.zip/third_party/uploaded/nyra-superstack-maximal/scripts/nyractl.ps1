param([string]$cmd="status")
function Start-Core { Start-Process -NoNewWindow "uvicorn" -ArgumentList "core.app:app --host 0.0.0.0 --port 8000" }
function Start-Tunnel { Start-Process -NoNewWindow "cloudflared.exe" -ArgumentList "tunnel run nyra-tunnel" }
function Stop-Port($p){ Get-Process -Id (Get-NetTCPConnection -LocalPort $p -ErrorAction SilentlyContinue).OwningProcess -ErrorAction SilentlyContinue | Stop-Process -Force }
switch($cmd){
  "up" { Start-Core; Start-Tunnel }
  "down" { Stop-Port 8000 }
  "status" { netstat -ano | findstr ":8000" }
  default { Write-Host "Usage: .\nyractl.ps1 [up|down|status]" }
}
