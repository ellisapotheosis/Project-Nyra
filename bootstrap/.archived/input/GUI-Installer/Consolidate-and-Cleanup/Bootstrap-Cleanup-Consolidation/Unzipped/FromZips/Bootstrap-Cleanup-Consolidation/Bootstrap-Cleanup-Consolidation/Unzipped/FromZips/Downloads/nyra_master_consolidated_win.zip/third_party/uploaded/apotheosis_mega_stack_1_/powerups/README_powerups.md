# Power-Ups
Date: 2025-08-20T07:05:30.473160Z

- Meilisearch index tuning + apply scripts (Linux/macOS + Windows)
- Langfuse backups to S3 (Postgres `pg_dump` + ClickHouse `BACKUP TO S3`)
- Mongo & Meili local backup helpers
- Notion CSV taxonomy
- Open WebUI prompts pack (slash commands)
