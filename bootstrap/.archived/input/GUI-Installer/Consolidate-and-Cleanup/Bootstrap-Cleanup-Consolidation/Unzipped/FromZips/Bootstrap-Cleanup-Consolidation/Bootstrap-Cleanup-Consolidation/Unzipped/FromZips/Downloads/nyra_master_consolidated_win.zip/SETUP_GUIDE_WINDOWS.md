# Setup Guide — Windows 11

## 0) Prereqs
- Docker Desktop (Compose v2), PowerShell 7+, Node.js (for npx), Python 3.11+ (for uvx)
- Optional: `pipx install uv` (script will install if missing)

## 1) Environment
```powershell
Copy-Item .\config\.env.example .\.env -Force
notepad .\.env
```

## 2) Bootstrap folders
```powershell
.\scripts\bootstrap.ps1
```

## 3) Bring up stacks
```powershell
# all core + orchestrators + observability
.\scripts\up.ps1 all
# or one by one:
.\scripts\up.ps1 core
.\scripts\up.ps1 orchestrators
.\scripts\up.ps1 obs
```

## 4) MCP channels & MCPO for Open WebUI
```powershell
Copy-Item .\scripts\env.template.ps1 .\scripts\env.ps1 -Force
notepad .\scripts\env.ps1
. .\scripts\env.ps1
.\scripts\install-mcp-config.ps1 -Target all
.\scripts\start-mcpo.ps1 -Port 8000 -ApiKey "top-secret"
```
- Open WebUI → Settings → Tools → Add:
  - `http://localhost:8000/time`
  - `http://localhost:8000/fetch`
  - `http://localhost:8000/browser-use`
  - `http://localhost:8000/qdrant`
  - `http://localhost:8000/graphiti`
  - `http://localhost:8000/context7`

## 5) Claude-Flow & Archon
- Point Claude-Flow at **MetaMCP/MCPO** tools; attach **Archon MCP** as brain tools; use **Claude Code** terminals for file/git/shell.
- Use the **Hot-Potato** loops described in `diagrams/architecture.md`.

## 6) Stop & clean
```powershell
.\scripts\down.ps1
```
