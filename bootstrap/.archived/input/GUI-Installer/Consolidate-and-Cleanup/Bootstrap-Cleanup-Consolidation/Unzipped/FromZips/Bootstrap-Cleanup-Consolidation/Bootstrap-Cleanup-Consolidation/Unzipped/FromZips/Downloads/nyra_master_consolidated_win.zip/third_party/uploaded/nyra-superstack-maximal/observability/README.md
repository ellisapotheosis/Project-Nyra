OTEL traces → OpenLIT exporter (add in apps) → Prometheus metrics, Loki logs → Grafana dashboards.
