# Architecture (Mermaid)

```mermaid
flowchart LR
  subgraph UI
    OW(Open WebUI):::ui
    LC(LobeChat):::ui
    DFY(Dify):::ui
  end
  subgraph Glue
    MCPO(MCPO OpenAPI<->MCP):::mcp
    MetaMCP(MetaMCP Aggregator):::mcp
  end
  OW -- OpenAPI Tools --> MCPO
  LC -- Plugins/MCP --> MCPO
  DFY -- OpenAI API --> GW(ArchGW)
  MCPO <---> MetaMCP

  subgraph Orchestration
    CF(Claude-Flow HiveMind):::orch
    ARCHON(Archon MCP):::orch
    LG(LangGraph App):::orch
    AG2(AG2 Runtime):::orch
    PRAI(PraisonAI):::orch
    A2A(Agent2Agent Host):::orch
  end
  MetaMCP -. MCP .-> CF & ARCHON & LG & AG2 & PRAI
  A2A <-- JSON-RPC/SSE --> CF & AG2 & LG & ARCHON

  subgraph Memory Mesh
    QD(Qdrant):::mem
    NEO(Neo4j):::mem
    GRA(Graphiti MCP):::mem
    MEM0(Mem0/OpenMemory):::mem
  end

  ARCHON --- NEO
  LG --- QD
  CF --- MEM0

  classDef ui fill:#cce,stroke:#336;
  classDef mcp fill:#ffd,stroke:#aa8;
  classDef orch fill:#efe,stroke:#494;
  classDef mem fill:#fce,stroke:#a48;
```

```mermaid
sequenceDiagram
  participant User
  participant OW as Open WebUI
  participant MCPO
  participant CF as Claude-Flow
  participant ARCHON as Archon
  participant DC as DeepCode
  participant SWE as SWE-Agent
  participant OH as OpenHands

  User->>OW: "Build service X"
  OW->>MCPO: call(tool=codanna.analyze)
  OW->>CF: Route orchestration request
  CF->>ARCHON: spawn pocket/smol agents
  ARCHON->>DC: delegate core build
  DC-->>OH: scaffold repo + run commands
  OH-->>SWE: repair & test
  SWE-->>CF: PR + diff
  CF-->>OW: artifacts + summary
```
