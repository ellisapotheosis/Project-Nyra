# NYRA Core – Multi-Agent Orchestration Stack

This repo powers your AI control system across:
- Hosted agents (OpenAI, Anthropic, Koyeb)
- Local GPU models (Ollama, AnythingLLM, LM Studio)
- Cloudflare Tunnel for public secure access
- Subdomain routing under `ratehunter.net`

## 🧠 Components

### agents/
- `ollama_client.py`: Local GPU model runner
- `openai_connector.py`: Cloud agent API wrapper

### orchestrator/
- `crewai_bridge.py`: Handles CrewAI-based flows
- `autogen_runner.py`: Task loop w/ subagents
- `langgraph_mesh.py`: Memory & sequence control

### root files
- `app.py`: FastAPI web control panel (localhost + cloud)
- `config.env`: Secrets loaded by `dotenv`
- `Procfile`: Required for Koyeb deployment
- `start_local.sh` / `start_local.bat`: Launch agents + web
- `.env.example`: Template for your secrets
- `.gitignore`: Excludes `.env`, logs, `.cloudflared/`

## 🌐 Domain Routing

In Cloudflare DNS (for `ratehunter.net`), create:

| Type | Name | Value (Target) |
|------|------|----------------|
| CNAME | `gpu` | `gpu-agent.<uuid>.cfargotunnel.com` |
| CNAME | `ai` | `your-koyeb-app.koyeb.app` |
| A or CNAME | `api` | `your-fastapi-app.koyeb.app` |

## 🚀 Quickstart

```bash
# Run local Ollama or AnythingLLM
ollama serve &

# Start Cloudflare tunnel
cloudflared tunnel run gpu-agent

# Start orchestrator & agents
uvicorn app:app --reload --host 0.0.0.0 --port 7860
```

## 🛡️ Secrets
Copy `.env.example` → `.env` and fill in:
```
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=...
OLLAMA_BASE_URL=http://localhost:11434
```

## 🔄 GitHub Auto Deploy
This repo includes a GitHub Action to:
- Ping your local GPU tunnel
- Deploy hosted orchestrator to Koyeb

> You are now controlling both hosted and local AI agents under a single domain.
> Add more subdomains or agent branches as needed.
