Write-Host 'Codanna MCP client placeholder'
