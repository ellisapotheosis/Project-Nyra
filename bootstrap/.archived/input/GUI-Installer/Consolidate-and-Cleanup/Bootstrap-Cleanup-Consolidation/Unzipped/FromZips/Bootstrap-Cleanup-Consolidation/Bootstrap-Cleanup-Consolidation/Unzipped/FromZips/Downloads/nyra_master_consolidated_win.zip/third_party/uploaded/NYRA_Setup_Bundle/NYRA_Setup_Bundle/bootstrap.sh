#!/usr/bin/env bash
echo "🌌 [NYRA BOOTSTRAP] Preparing AgentZero & Claude Desktop..."

if ! command -v python3 >/dev/null 2>&1; then
  echo "❌ Python 3.11+ is required"; exit 1
fi

python3 -m venv venv
source venv/bin/activate

echo "📦 Installing requirements..."
pip install --upgrade pip
pip install -r requirements.txt

echo "🔗 Starting AgentZero Orchestrator..."
python launch_orchestrator.py --agent configs/agentzero_config.json
