# Architectural Decision Records (ADR)

## ADR-001: Hybrid Local + Cloud
- Decision: Run inference locally (3090/5090) while orchestrating via Koyeb.
- Status: Accepted

## ADR-002: Cloudflare Tunnels for Secure Exposure
- Decision: Expose local Ollama/AnythingLLM via Cloudflare Tunnel with domain subrouting.
- Status: Accepted

## ADR-003: Subdomain Partitioning
- gpu.ratehunter.net → local Ollama/AnythingLLM
- ai.ratehunter.net → control panel
- api.ratehunter.net → orchestrator endpoints
- Status: Accepted

## ADR-004: Multi-Agent Frameworks
- CrewAI for structured task assignment
- AutoGen for dialogue orchestration
- LangGraph for state + memory
- Status: Accepted
