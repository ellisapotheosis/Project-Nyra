# qdrant MCP

Stub docs: configure credentials & endpoints for `qdrant` server.
