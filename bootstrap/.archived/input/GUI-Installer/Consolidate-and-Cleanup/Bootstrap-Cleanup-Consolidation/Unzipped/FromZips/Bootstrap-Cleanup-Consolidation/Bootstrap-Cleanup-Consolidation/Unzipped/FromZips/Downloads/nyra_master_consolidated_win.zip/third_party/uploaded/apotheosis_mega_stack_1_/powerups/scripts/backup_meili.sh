#!/usr/bin/env bash
set -euo pipefail
: "${MEILI_API_KEY:?MEILI_API_KEY not set}"
MEILI_HOST="${MEILI_HOST:-http://localhost:7700}"
OUT_DIR="${OUT_DIR:-./backups/meili}"
mkdir -p "$OUT_DIR"
echo "[meili] requesting snapshot..."
curl -s -X POST "$MEILI_HOST/snapshots" -H "X-Meili-API-Key: $MEILI_API_KEY" >/dev/null
echo "[meili] waiting 10s for snapshot finalize..."
sleep 10
TS=$(date +%Y%m%d_%H%M%S)
tar -czf "$OUT_DIR/meili_snapshot_$TS.tgz" -C ./ ../meili_data . || echo "If meili_data not mapped outside, docker cp from container"
echo "[meili] snapshot saved to $OUT_DIR/meili_snapshot_$TS.tgz"
