param([int]$Port=8000,[string]$ApiKey="top-secret")
$ErrorActionPreference='Stop'
function Test-Cmd { param($n) $null -ne (Get-Command $n -ErrorAction SilentlyContinue) }
if (-not (Test-Cmd "uvx")) {
  Write-Host "Installing uv via pipx..." -ForegroundColor Yellow
  if (-not (Test-Cmd "pipx")) { python -m pip install --user pipx; python -m pipx ensurepath }
  pipx install uv | Out-Null
}
$root = Resolve-Path (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "..")
$configPath = Join-Path $root "config\mcpo\config.json"
$env:MCPO_API_KEY = $ApiKey
Write-Host "Starting MCPO on port $Port with hot reload..." -ForegroundColor Cyan
uvx mcpo --config $configPath --port $Port --hot-reload
