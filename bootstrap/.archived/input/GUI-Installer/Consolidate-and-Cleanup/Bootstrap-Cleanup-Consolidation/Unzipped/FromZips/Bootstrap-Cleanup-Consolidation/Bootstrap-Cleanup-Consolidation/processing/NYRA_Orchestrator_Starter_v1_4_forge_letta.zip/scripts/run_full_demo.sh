#!/usr/bin/env bash
set -e
python scripts/run_orchestrator.py --task "$1"
python scripts/forge_pr.py --task "$1" --repo_dir "${2:-.}"
