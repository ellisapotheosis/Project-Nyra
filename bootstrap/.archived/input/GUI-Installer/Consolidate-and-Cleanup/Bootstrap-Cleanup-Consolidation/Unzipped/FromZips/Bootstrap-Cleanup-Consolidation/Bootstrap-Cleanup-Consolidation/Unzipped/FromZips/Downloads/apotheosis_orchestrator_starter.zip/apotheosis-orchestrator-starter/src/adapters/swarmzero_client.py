import os, httpx, json

def call_swarmzero(prompt: str) -> str:
    base = os.environ.get("SWARMZERO_BASE_URL", "http://localhost:8000")
    url = f"{base}/api/v1/chat"
    try:
        # Minimal payload based on SwarmZero README example
        files = {
            "user_id": (None, "apotheosis"),
            "session_id": (None, "setup"),
            "chat_data": (None, json.dumps({"messages": [{"role":"user","content": prompt}]}))
        }
        r = httpx.post(url, files=files, timeout=120)
        r.raise_for_status()
        return r.text
    except Exception as e:
        return f"error calling SwarmZero: {e}"
