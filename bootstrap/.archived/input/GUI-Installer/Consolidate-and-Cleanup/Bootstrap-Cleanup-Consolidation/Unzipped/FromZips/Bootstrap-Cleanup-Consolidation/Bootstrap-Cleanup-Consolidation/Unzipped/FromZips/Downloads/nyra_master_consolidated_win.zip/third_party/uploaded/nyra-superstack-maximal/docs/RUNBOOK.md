# Runbook

## 0) Bootstrap
```bash
cp .env.example .env
make base
```

## 1) Bring up UIs, RAG, Observability
```bash
make ui
make rag
make obs
```

## 2) Smoke test
- Open WebUI → http://localhost:3000
- LobeChat → http://localhost:3210
- LiteLLM → http://localhost:4000/v1/models
- Grafana → http://localhost:3001
- Qdrant → http://localhost:6333/metrics

## 3) MCP packs
```bash
make mcp
```

## 4) Exposure (dev only)
- Cloudflare: `cloudflared tunnel run <tunnel>`
- Ngrok: `ngrok http 3000` then CNAME your subdomain to the static ngrok domain
