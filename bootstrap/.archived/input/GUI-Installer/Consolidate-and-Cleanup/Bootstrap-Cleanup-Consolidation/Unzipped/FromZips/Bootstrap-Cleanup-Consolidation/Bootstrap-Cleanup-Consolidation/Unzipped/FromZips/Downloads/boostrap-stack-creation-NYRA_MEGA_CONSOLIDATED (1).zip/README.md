# NYRA-MEGA CONSOLIDATED

**Sources merged:** apotheosis-stack, nyra-starter, apotheosis-monorepo, claude-flow-pack, APOTHEOSIS_GODMODE_MONOREPO,
NYRA_Orchestrator_Starter_v1_4_forge_letta, nyra-fix-pack, apotheosis_orchestrator_starter, nyra-superstack-v2, nyra-bootstrap-pack.

**Priority**
- Memory: `nyra-starter` → /memory
- Experimental: memOS / memorytensor → /memory_experimental
- Orchestration: `apotheosis-stack` (A2A) → /apps/a2a_*
- Claude-flow pack → /integrations/claude-flow
- Other memory → /deprecated/memory

Check `compose/_collected/` for all docker-compose variants recovered.
