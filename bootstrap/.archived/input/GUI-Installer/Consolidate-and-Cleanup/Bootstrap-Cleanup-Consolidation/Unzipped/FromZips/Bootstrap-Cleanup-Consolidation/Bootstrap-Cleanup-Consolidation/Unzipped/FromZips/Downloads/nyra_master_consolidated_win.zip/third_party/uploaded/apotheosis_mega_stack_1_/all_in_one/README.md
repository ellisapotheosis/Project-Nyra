# Apotheosis — All-in-One Stack
Date: 2025-08-20T07:05:30.471311Z

## Services (localhost)
- LibreChat: http://localhost:3080
- Open WebUI: http://localhost:3000
- LiteLLM API: http://localhost:4000/v1
- Meilisearch: http://localhost:7700
- Langfuse: http://localhost:3100
- Ollama: http://localhost:11434

## Start
```bash
cp .env.example .env
# Edit .env to set strong secrets
docker compose --env-file ./.env up -d
# Pull local models
docker exec -it $(docker ps -qf name=ollama) ollama pull llama3.1:8b
docker exec -it $(docker ps -qf name=ollama) ollama pull qwen2.5:7b
docker exec -it $(docker ps -qf name=ollama) ollama pull deepseek-r1:8b
```
- Open WebUI: connected to Ollama via `OLLAMA_BASE_URL`. You can also add LiteLLM (`http://localhost:4000/v1`) in the UI.
- LibreChat: already points to LiteLLM; Meilisearch enabled via env.

## Stop
```bash
docker compose down
# add -v to prune volumes (removes data)
```
