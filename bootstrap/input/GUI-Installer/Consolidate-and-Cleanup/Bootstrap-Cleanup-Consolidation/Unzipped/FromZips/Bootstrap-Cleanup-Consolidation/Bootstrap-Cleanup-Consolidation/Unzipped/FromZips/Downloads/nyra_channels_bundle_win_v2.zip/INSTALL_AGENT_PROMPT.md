
# Agent Setup Prompt

- Load env: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned; . .\scripts\env.ps1`
- Install configs: `.\scripts\install-mcp-config.ps1 -Target all`
- Ensure Qdrant/Neo4j containers running (start if missing).
- Launch MCPO `.\scripts\start-mcpo.ps1 -Port 8000 -ApiKey top-secret`
- Validate: Invoke time/fetch in Claude Desktop and Open WebUI tool panel.
