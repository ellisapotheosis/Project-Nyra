
param(
  [int]$Port = 8000,
  [string]$ApiKey = "top-secret"
)
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Resolve-Path (Join-Path $here "..")
$configPath = Join-Path $root "config\mcpo\config.json"

# Try to run MCPO via uvx if available; else fall back to python -m mcpo
function Test-Command { param([string]$Name) $null -ne (Get-Command $Name -ErrorAction SilentlyContinue) }

$env:MCPO_API_KEY = $ApiKey

if (Test-Command "uvx") {
  uvx mcpo --config $configPath --port $Port --hot-reload
} else {
  python -m pip install --user mcpo | Out-Null
  python -m mcpo --config $configPath --port $Port --hot-reload
}
