
param(
  [ValidateSet("claude","vscode","mcpo","all")]
  [string]$Target = "all"
)
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Resolve-Path (Join-Path $here "..")
$claudeCfg = Join-Path $root "config\claude\claude_desktop_config.json"
$vscodeCfg = Join-Path $root "config\vscode\mcp.json"
$mcpoCfg   = Join-Path $root "config\mcpo\config.json"

if ($Target -eq "claude" -or $Target -eq "all") {
  $dst = Join-Path $env:APPDATA "Claude\claude_desktop_config.json"
  New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
  Copy-Item $claudeCfg $dst -Force
  Write-Host "✔ Claude Desktop MCP config -> $dst"
}
if ($Target -eq "vscode" -or $Target -eq "all") {
  $dstDir = Join-Path $env:USERPROFILE ".vscode"
  New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
  $dst = Join-Path $dstDir "mcp.json"
  Copy-Item $vscodeCfg $dst -Force
  Write-Host "✔ VS Code MCP config -> $dst"
}
if ($Target -eq "mcpo" -or $Target -eq "all") {
  $dst = Join-Path $root "config\mcpo\config.json"
  Copy-Item $mcpoCfg $dst -Force
  Write-Host "✔ MCPO config prepared -> $dst"
}
Write-Host "Done. Restart clients to load configs." -ForegroundColor Green
