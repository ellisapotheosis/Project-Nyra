# NYRA Channels Bundle (Windows v2)
See INSTALL_USER.md and INSTALL_AGENT_PROMPT.md
