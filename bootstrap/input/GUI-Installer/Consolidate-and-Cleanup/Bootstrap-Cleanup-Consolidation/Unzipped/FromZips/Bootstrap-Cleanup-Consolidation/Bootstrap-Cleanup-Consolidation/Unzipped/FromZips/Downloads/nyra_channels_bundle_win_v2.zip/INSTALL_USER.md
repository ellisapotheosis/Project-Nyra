
# Step-by-step (Windows)

1) `Copy-Item .\scripts\env.template.ps1 .\scripts\env.ps1 -Force` then edit & dot-source:
   ```powershell
   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
   . .\scripts\env.ps1
   ```
2) `.\scripts\install-mcp-config.ps1 -Target all`
3) (optional) Run stores:
   ```powershell
   docker run -d --name qdrant -p 6333:6333 -v qdrant:/qdrant/storage qdrant/qdrant
   docker run -d --name neo4j -p 7474:7474 -p 7687:7687 -e NEO4J_AUTH=neo4j/password neo4j:5.26
   ```
4) Start MCPO: `.\scripts\start-mcpo.ps1 -Port 8000 -ApiKey top-secret`
5) In Open WebUI → Tools → add: /time, /fetch, /browser-use, /qdrant, /graphiti, /context7
