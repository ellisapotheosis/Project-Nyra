# Notion Uploader Stub
# Set env vars: NOTION_TOKEN, NOTION_PARENT_PAGE
# Usage: python notion-uploader.py path/to/file.md
import os, sys, json, requests, pathlib
API = "https://api.notion.com/v1/pages"
NOTION_TOKEN = os.getenv("NOTION_TOKEN")
PARENT = os.getenv("NOTION_PARENT_PAGE")
NOTION_VERSION = "2022-06-28"
def main():
  if not NOTION_TOKEN or not PARENT:
    print("ERROR: Set NOTION_TOKEN and NOTION_PARENT_PAGE"); sys.exit(1)
  if len(sys.argv) < 2:
    print("Usage: python notion-uploader.py path/to/file.md"); sys.exit(1)
  path = pathlib.Path(sys.argv[1])
  if not path.exists(): print("ERROR: File not found:", path); sys.exit(1)
  content = path.read_text(encoding="utf-8")
  payload = {
    "parent": { "page_id": PARENT },
    "properties": { "title": { "title": [ { "type":"text", "text": { "content": path.name } } ] } },
    "children": [ { "object":"block", "type":"code", "code": { "language":"markdown", "rich_text":[ { "type":"text", "text": { "content": content } } ] } } ]
  }
  headers = { "Authorization": f"Bearer {NOTION_TOKEN}", "Content-Type":"application/json", "Notion-Version": NOTION_VERSION }
  r = requests.post(API, headers=headers, data=json.dumps(payload))
  if r.status_code >= 300: print("Upload failed:", r.status_code, r.text); sys.exit(1)
  print("Uploaded:", path.name)
if __name__ == "__main__": main()
