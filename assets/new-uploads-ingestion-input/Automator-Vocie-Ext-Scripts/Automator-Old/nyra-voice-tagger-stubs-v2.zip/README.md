# NYRA Voice Tagger + Stubs (v2)
- `nyra-voice-tagger-tampermonkey.user.js` — working tagger for ChatGPT (buttons, logs, CSV export, webhook).
- `nyra-voice-handler.ts` — SuperAGI voice bridge stub.
- `notion-uploader.py` — Upload `.md` into a Notion page as a code block.

## Install — Tampermonkey
1) Import `nyra-voice-tagger-tampermonkey.user.js` into Tampermonkey.
2) Open ChatGPT, find the floating panel. Add tags and optional webhook.
3) Click `＋Tag` near any file link, or `Tag Page` to log.
4) Use `Export CSV` to save your log.

## Notion CLI Upload
export NOTION_TOKEN=secret_xxx
export NOTION_PARENT_PAGE=<page_id>
python notion-uploader.py nyra-voice-connector.md
