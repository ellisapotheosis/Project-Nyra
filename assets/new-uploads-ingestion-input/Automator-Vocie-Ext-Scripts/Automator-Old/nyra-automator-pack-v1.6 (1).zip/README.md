# v1.6 quickstart
Import the .user.js files into Tampermonkey. Panel is centered & draggable.