<#
Reads export files from a folder and offers to install items per package manager.
Supported:
- Chocolatey: packages.config
- Winget: winget.json
- Scoop: scoop-manifest.json
- npm: npm_globals.txt
- yarn: yarn_globals.txt
- pip: requirements.txt
- conda: env.yml (creates env)
- PowerShell modules: psmodules.txt (Name[;Version] per line)
#>
param([string]$Folder="$HOME\PackageExports")

function Confirm($msg){ $r = Read-Host "$msg [y/N]"; return ($r -match '^(y|yes)$') }

function Install-Choco($f){
  if (-not (Get-Command choco -ErrorAction SilentlyContinue)) { Write-Warning "choco not installed"; return }
  choco install $f -y
}

function Install-Winget($f){
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { Write-Warning "winget not installed"; return }
  winget import -i $f
}

function Install-Scoop($f){
  if (-not (Get-Command scoop -ErrorAction SilentlyContinue)) { Write-Warning "scoop not installed"; return }
  scoop import $f
}

function Install-Npm($f){
  if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { Write-Warning "npm not installed"; return }
  $pkgs = Get-Content $f | Where-Object { $_ -match "^\s*[^@ \t]+" } | ForEach-Object { ($_ -replace "@\d.*$","").Trim() } | Select-Object -Unique
  foreach($p in $pkgs){ npm install -g $p }
}

function Install-Yarn($f){
  if (-not (Get-Command yarn -ErrorAction SilentlyContinue)) { Write-Warning "yarn not installed"; return }
  $pkgs = Get-Content $f | Select-String "info" | ForEach-Object { ($_ -split ' ')[-1] } | Select-Object -Unique
  foreach($p in $pkgs){ yarn global add $p }
}

function Install-Pip($f){
  if (-not (Get-Command pip -ErrorAction SilentlyContinue)) { Write-Warning "pip not installed"; return }
  pip install -r $f
}

function Install-Conda($f){
  $conda = (Get-Command conda -ErrorAction SilentlyContinue)
  if (-not $conda) { Write-Warning "conda not installed"; return }
  $name = (Select-String -Path $f -Pattern "^name:\s*(.+)$").Matches.Value -replace "^name:\s*",""
  if (-not $name) { $name = Read-Host "Conda env name" }
  conda env create -n $name -f $f
}

function Install-PSModules($f){
  $mods = Get-Content $f | Where-Object { $_ -and $_ -notmatch "^#" }
  foreach($m in $mods){
    $parts = $m.Split(';')
    if ($parts.Count -gt 1) {
      Install-Module -Name $parts[0] -RequiredVersion $parts[1] -Scope CurrentUser -Force -AllowClobber
    } else {
      Install-Module -Name $parts[0] -Scope CurrentUser -Force -AllowClobber
    }
  }
}

Write-Host "Reading exports from $Folder" -ForegroundColor Cyan
$map = @{
  "Chocolatey (packages.config)" = @{ Path = Join-Path $Folder "packages.config";   Fn = { Install-Choco $_ } }
  "Winget (winget.json)"         = @{ Path = Join-Path $Folder "winget.json";       Fn = { Install-Winget $_ } }
  "Scoop (scoop-manifest.json)"  = @{ Path = Join-Path $Folder "scoop-manifest.json"; Fn = { Install-Scoop $_ } }
  "npm (npm_globals.txt)"        = @{ Path = Join-Path $Folder "npm_globals.txt";   Fn = { Install-Npm $_ } }
  "yarn (yarn_globals.txt)"      = @{ Path = Join-Path $Folder "yarn_globals.txt";  Fn = { Install-Yarn $_ } }
  "pip (requirements.txt)"       = @{ Path = Join-Path $Folder "requirements.txt";  Fn = { Install-Pip $_ } }
  "conda (env.yml)"              = @{ Path = Join-Path $Folder "env.yml";           Fn = { Install-Conda $_ } }
  "PowerShell (psmodules.txt)"   = @{ Path = Join-Path $Folder "psmodules.txt";     Fn = { Install-PSModules $_ } }
}
foreach($k in $map.Keys){
  $p = $map[$k].Path
  if (Test-Path $p) {
    if (Confirm "Install from $k ?") {
      & $map[$k].Fn.Invoke($p)
    } else {
      Write-Host "Skipped $k"
    }
  } else {
    Write-Host "No file: $k"
  }
}
