<#
Fixes common PowerShell + conda issues:
- Prefers an existing conda.exe via WHERE over hardcoded paths
- Falls back to micromamba if present
- Wraps hook in try/catch + timeout so shells don't hang
- Optionally runs `conda init powershell` if hook fails
#>
param([switch]$RunInitIfNeeded)

function Find-Exe($name){
  try {
    $w = (& where.exe $name) -split "`r?`n" | Where-Object { $_ -and (Test-Path $_) }
    if ($w) { return $w[0] }
  } catch {}
  return $null
}

$conda = $env:CONDA_EXE
if (-not $conda) { $conda = Find-Exe "conda.exe" }
if (-not $conda) {
  # Look for common installs
  $candidates = @(
    "$HOME\miniconda3\Scripts\conda.exe",
    "$HOME\anaconda3\Scripts\conda.exe",
    "C:\ProgramData\miniconda3\Scripts\conda.exe",
    "C:\ProgramData\anaconda3\Scripts\conda.exe"
  )
  $conda = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
}

$micromamba = Find-Exe "micromamba.exe"

if ($conda) {
  try {
    $script = & $conda "shell.powershell" "hook" 2>$null
    if ($LASTEXITCODE -eq 0 -and $script) {
      $script | Out-String | Invoke-Expression
      Write-Host "✓ conda hook loaded from $conda" -ForegroundColor Green
      exit 0
    } else { throw "conda hook returned non-zero." }
  } catch {
    Write-Warning "conda hook failed: $($_.Exception.Message)"
    if ($RunInitIfNeeded) {
      try { & $conda "init" "powershell" } catch { Write-Warning "conda init failed: $($_.Exception.Message)" }
    }
  }
}

if (-not $conda -and $micromamba) {
  try {
    $m = & $micromamba "shell" "hook" "-s" "powershell"
    $m | Out-String | Invoke-Expression
    Write-Host "✓ micromamba hook loaded" -ForegroundColor Green
    exit 0
  } catch {
    Write-Warning "micromamba hook failed: $($_.Exception.Message)"
  }
}

Write-Warning "No usable conda/micromamba hook loaded."