# RTX5090 Add-on v3.4.1 — Conda fix + Install-from-Exports — 2025-09-01 03:53

**What you get**
- `Fix-Conda-Hook.ps1` — robust conda/micromamba hook loader
- `Docs/Profile-Patch.md` — copy/paste block to patch your PowerShell profile safely
- `Setup-From-Exports.ps1` — install apps/modules from export files (Chocolatey, Winget, Scoop, npm, yarn, pip, conda, PS modules)

**How to use**
1. Unzip to `C:\RTX5090_Addon_v3_4_1`.
2. Append the block in `Docs\Profile-Patch.md` to your `$PROFILE` (above PSReadLine section).
3. Place your export files in `~\PackageExports` and run:
   ```powershell
   Set-ExecutionPolicy Bypass -Scope Process -Force
   cd C:\RTX5090_Addon_v3_4_1\Scripts
   .\Setup-From-Exports.ps1 -Folder $HOME\PackageExports
   ```
