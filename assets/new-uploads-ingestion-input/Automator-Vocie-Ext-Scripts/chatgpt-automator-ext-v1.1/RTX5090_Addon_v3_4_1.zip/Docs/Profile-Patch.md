# Profile Patch — Conda fix and module autoload

Append the following **above** your PSReadLine section in your PowerShell profile (`$PROFILE`).

```powershell
# ---------- Conda/Micromamba (robust hook) ----------
try {
  $fix = Join-Path (Split-Path -Parent $PROFILE) "Scripts\System\Fix-Conda-Hook.ps1"
  if (Test-Path $fix) {
    & $fix | Out-Null
  } else {
    # Fallback minimal hook if addon not present
    $cx = $env:CONDA_EXE
    if (-not $cx) { try { $cx = (& where.exe conda.exe 2>$null) -split "`r?`n" | Select-Object -First 1 } catch {} }
    if ($cx) { (& $cx "shell.powershell" "hook") | Out-String | Invoke-Expression }
  }
} catch { Write-Verbose "Conda hook skipped: $($_.Exception.Message)" }
```

Optionally, to silence noisy modules (e.g., `docker-completions`) add:
```powershell
Import-Module docker-completions -ErrorAction SilentlyContinue | Out-Null
```
